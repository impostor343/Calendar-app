# College Companion — JSON & CSV Import Schema Documentation

College Companion supports three independent structured import modes plus full database backup/restore:
1. **Timetable Only (`TIMETABLE_ONLY`)**: Requires `subjects` and `timetableSlots`.
2. **Academic Calendar Only (`ACADEMIC_CALENDAR_ONLY`)**: Requires `calendarConfig` and/or `calendarEvents`.
3. **Combined Academic Schedule (`COMBINED_SCHEDULE`)**: Imports `calendarConfig`, `subjects`, `timetableSlots`, and `calendarEvents` together and generates all semester lecture instances while preserving any existing finalized attendance history.
4. **Full Database Backup & Restore (`FULL_BACKUP_RESTORE`)**: Includes all of the above plus `lectureInstances` and `bulkOperationsHistory`.

## 1. Root Object (`AcademicScheduleBundle`)

| Field | Type | Required | Description |
| :--- | :--- | :--- | :--- |
| `schemaVersion` | `Int` | Yes | Schema version identifier (`1`). |
| `exportTimestampEpochMillis` | `Long` | No | Epoch timestamp when exported (`0` if hand-authored). |
| `calendarConfig` | `AcademicCalendarConfig?` | Optional | Semester start/end dates and regular working weekdays. |
| `subjects` | `List<Subject>` | Optional | List of academic subjects and colour/threshold settings. |
| `timetableSlots` | `List<TimetableSlot>` | Optional | Recurring weekday lecture slots. |
| `calendarEvents` | `List<AcademicCalendarEvent>` | Optional | Holidays, exams, vacations, and special working day overrides. |
| `lectureInstances` | `List<LectureInstance>` | Optional | Concrete dated lecture records (used in full backup/restore). |
| `bulkOperationsHistory` | `List<BulkAbsenceOperationRecord>` | Optional | Audit trail of bulk absence operations for undo support. |

## 2. `AcademicCalendarConfig`

| Field | Type | Format / Values | Description |
| :--- | :--- | :--- | :--- |
| `semesterName` | `String` | e.g. `"Fall Semester 2026"` | Display name of the semester. |
| `semesterStartDate` | `String` | `YYYY-MM-DD` | Inclusive start date of the semester. |
| `semesterEndDate` | `String` | `YYYY-MM-DD` | Inclusive end date of the semester. |
| `workingDaysOfWeek` | `Set<Int>` | `1` (Mon) .. `7` (Sun) | Regular working weekdays (e.g. `[1, 2, 3, 4, 5]`). |

## 3. `Subject`

| Field | Type | Format / Values | Description |
| :--- | :--- | :--- | :--- |
| `id` | `String` | Unique slug, e.g. `"sub_ds"` | Primary key referenced by `TimetableSlot.subjectId`. |
| `code` | `String` | e.g. `"CS201"` | Course/subject code. |
| `name` | `String` | e.g. `"Data Structures"` | Full subject title. |
| `professor` | `String` | Free text | Instructor name. |
| `colorHex` | `String` | `#RRGGBB` | Subject accent colour across app and widgets. |
| `defaultRoom` | `String` | Free text | Default classroom number. |
| `defaultLab` | `String` | Free text | Default laboratory number. |
| `defaultBuilding` | `String` | Free text | Building name. |
| `defaultFloor` | `String` | Free text | Floor label. |
| `customRequiredPercentage` | `Double?` | `0.0` .. `100.0` | Per-subject minimum attendance requirement (falls back to global 70% if `null`). |
| `remindersEnabled` | `Boolean` | `true` / `false` | Whether lecture notifications are active for this subject. |

## 4. `TimetableSlot`

| Field | Type | Format / Values | Description |
| :--- | :--- | :--- | :--- |
| `id` | `String` | Unique ID | Slot identifier. |
| `subjectId` | `String` | Foreign key to `Subject.id` | Associated subject. |
| `dayOfWeek` | `Int` | `1` (Monday) .. `7` (Sunday) | ISO-8601 weekday number. |
| `startTime` | `String` | `HH:mm` (24-hour) | Lecture start time (`09:00`). |
| `endTime` | `String` | `HH:mm` (24-hour) | Lecture end time (`10:00`). Must be strictly after `startTime`. |
| `roomNumber` | `String` | Free text | Room override (uses subject default if blank). |
| `labNumber` | `String` | Free text | Laboratory override. |
| `building` | `String` | Free text | Building override. |
| `floor` | `String` | Free text | Floor override. |
| `professorOverride` | `String` | Free text | Professor override. |
| `lectureType` | `String` | `LECTURE`, `LAB`, `TUTORIAL`, `SEMINAR`, `WORKSHOP`, `EXTRA` | Session category. |
| `rotationPattern` | `String` | `EVERY_WEEK`, `ODD_WEEKS`, `EVEN_WEEKS`, `ROTATION_SET_A`, `ROTATION_SET_B` | Supports weekly and rotating schedules. |
| `isActive` | `Boolean` | `true` / `false` | Whether slot is active. |

## 5. `AcademicCalendarEvent`

| Field | Type | Format / Values | Description |
| :--- | :--- | :--- | :--- |
| `id` | `String` | Unique ID | Event identifier. |
| `title` | `String` | Free text | Holiday, exam, or override title. |
| `description` | `String` | Free text | Additional details. |
| `startDate` | `String` | `YYYY-MM-DD` | Start date (inclusive). |
| `endDate` | `String` | `YYYY-MM-DD` | End date (inclusive). |
| `eventType` | `String` | `HOLIDAY`, `NON_WORKING_DAY`, `SPECIAL_WORKING_SATURDAY`, `TIMETABLE_OVERRIDE_DAY`, `EXAMINATION`, `VACATION`, `SPECIAL_LECTURE`, `EVENT`, `ACADEMIC_DEADLINE` | Determines how `TimetableGenerator` maps lectures on this date range. |
| `followsDayOfWeek` | `Int?` | `1` .. `7` or `null` | When `eventType` is `SPECIAL_WORKING_SATURDAY` or `TIMETABLE_OVERRIDE_DAY`, specifies which weekday's timetable slots are generated on that date. |
| `rotationSetOverride` | `String?` | `ROTATION_SET_A`, `ROTATION_SET_B`, or `null` | Optional rotation override. |
