package com.collegecompanion.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.collegecompanion.domain.engine.TimetableGenerator
import com.collegecompanion.domain.model.AttendanceStatus
import com.collegecompanion.domain.model.LectureInstance
import com.collegecompanion.domain.model.LectureType
import com.collegecompanion.domain.model.RotationPattern
import com.collegecompanion.domain.model.Subject
import com.collegecompanion.domain.model.TimetableSlot
import com.collegecompanion.ui.theme.AttendanceRed
import com.collegecompanion.ui.theme.SubjectPalettePresets
import com.collegecompanion.ui.theme.parseHexColor
import com.collegecompanion.ui.viewmodel.AppUiState
import com.collegecompanion.ui.viewmodel.MainViewModel
import java.time.LocalDate
import java.util.UUID

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TimetableScreen(
    uiState: AppUiState,
    viewModel: MainViewModel
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedDayOfWeek by remember { mutableIntStateOf(uiState.currentDate.dayOfWeek.value) }
    var editingSubject by remember { mutableStateOf<Subject?>(null) }
    var showSubjectDialog by remember { mutableStateOf(false) }
    var editingSlot by remember { mutableStateOf<TimetableSlot?>(null) }
    var showSlotDialog by remember { mutableStateOf(false) }
    var showExtraLectureDialog by remember { mutableStateOf(false) }

    val subjectsById = remember(uiState.subjects) { uiState.subjects.associateBy { it.id } }

    Column(modifier = Modifier.fillMaxSize()) {
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            edgePadding = 16.dp
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Daily & Weekly Slots") })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Subjects (${uiState.subjects.size})") })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Extra / Rescheduled") })
        }

        // Overlap Warning Banner
        if (uiState.slotOverlapWarnings.isNotEmpty()) {
            Surface(
                color = AttendanceRed.copy(alpha = 0.14f),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = AttendanceRed)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Overlapping Timetable Warning (${uiState.slotOverlapWarnings.size})",
                            style = MaterialTheme.typography.labelLarge,
                            color = AttendanceRed,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    uiState.slotOverlapWarnings.forEach { warn ->
                        Text(
                            text = "• ${warn.dayOfWeekOrDate}: ${warn.firstLectureSummary} overlaps ${warn.secondLectureSummary} by ${warn.overlapMinutes} min",
                            style = MaterialTheme.typography.bodySmall,
                            color = AttendanceRed
                        )
                    }
                }
            }
        }

        when (selectedTab) {
            0 -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Weekday Selector Row
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items((1..7).toList()) { day ->
                            FilterChip(
                                selected = selectedDayOfWeek == day,
                                onClick = { selectedDayOfWeek = day },
                                label = { Text(TimetableGenerator.dayName(day).take(3)) }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${TimetableGenerator.dayName(selectedDayOfWeek)} Schedule",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Button(
                            onClick = {
                                editingSlot = null
                                showSlotDialog = true
                            }
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Slot")
                        }
                    }

                    val daySlots = uiState.timetableSlots
                        .filter { it.dayOfWeek == selectedDayOfWeek }
                        .sortedBy { it.startTime }

                    if (daySlots.isEmpty()) {
                        ElevatedCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(28.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("No recurring lectures configured for ${TimetableGenerator.dayName(selectedDayOfWeek)}.")
                            }
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            items(daySlots, key = { it.id }) { slot ->
                                val subject = subjectsById[slot.subjectId]
                                val color = parseHexColor(subject?.colorHex ?: "#1A73E8")
                                ElevatedCard(
                                    shape = RoundedCornerShape(18.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(12.dp)
                                                .background(color, CircleShape)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "${subject?.name ?: slot.subjectId} (${subject?.code ?: ""})",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "${slot.startTime} – ${slot.endTime} • ${slot.lectureType.displayName} • ${slot.rotationPattern.label}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            val loc = listOfNotNull(
                                                slot.roomNumber.takeIf { it.isNotBlank() }?.let { "Room $it" },
                                                slot.labNumber.takeIf { it.isNotBlank() }?.let { "Lab $it" },
                                                slot.building.takeIf { it.isNotBlank() },
                                                slot.floor.takeIf { it.isNotBlank() }?.let { "Floor $it" }
                                            ).joinToString(" • ")
                                            if (loc.isNotBlank()) {
                                                Text(
                                                    text = loc,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                        IconButton(onClick = {
                                            editingSlot = slot
                                            showSlotDialog = true
                                        }) {
                                            Icon(Icons.Default.Edit, contentDescription = "Edit Slot")
                                        }
                                        IconButton(onClick = { viewModel.deleteTimetableSlot(slot.id) }) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete Slot", tint = AttendanceRed)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Subjects & Custom Colours",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Button(onClick = {
                            editingSubject = null
                            showSubjectDialog = true
                        }) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Subject")
                        }
                    }

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(uiState.subjects, key = { it.id }) { subject ->
                            val color = parseHexColor(subject.colorHex)
                            ElevatedCard(
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(20.dp)
                                            .background(color, CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${subject.name} (${subject.code})",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Prof: ${subject.professor.ifBlank { "N/A" }} • Default Room: ${subject.defaultRoom.ifBlank { "TBD" }}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = "Min Attendance: ${(subject.customRequiredPercentage ?: uiState.preferences.globalRequiredAttendance).toInt()}% • Reminders: ${if (subject.remindersEnabled) "On" else "Off"}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    IconButton(onClick = {
                                        editingSubject = subject
                                        showSubjectDialog = true
                                    }) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit Subject")
                                    }
                                    IconButton(onClick = { viewModel.deleteSubject(subject.id) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete Subject", tint = AttendanceRed)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            2 -> {
                val customInstances = uiState.allInstances.filter { it.isOneTimeOrExtra || it.isRescheduled }
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "One-Time, Extra & Rescheduled",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Button(onClick = { showExtraLectureDialog = true }) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Lecture")
                        }
                    }

                    if (customInstances.isEmpty()) {
                        ElevatedCard(
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Use 'Add Lecture' to schedule one-off extra lectures or rescheduled sessions without altering your weekly template.",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(20.dp)
                            )
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            items(customInstances, key = { it.id }) { inst ->
                                ElevatedCard(
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text(
                                            text = "${inst.date} • ${inst.startTime}-${inst.endTime} • ${inst.subjectName}",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${inst.formattedLocation()} • Status: ${inst.attendanceStatus.displayName}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Subject Create/Edit Dialog
    if (showSubjectDialog) {
        val initial = editingSubject
        var name by remember { mutableStateOf(initial?.name ?: "") }
        var code by remember { mutableStateOf(initial?.code ?: "") }
        var professor by remember { mutableStateOf(initial?.professor ?: "") }
        var room by remember { mutableStateOf(initial?.defaultRoom ?: "") }
        var lab by remember { mutableStateOf(initial?.defaultLab ?: "") }
        var building by remember { mutableStateOf(initial?.defaultBuilding ?: "") }
        var floor by remember { mutableStateOf(initial?.defaultFloor ?: "") }
        var reqPct by remember { mutableStateOf((initial?.customRequiredPercentage ?: 70.0).toString()) }
        var colorHex by remember { mutableStateOf(initial?.colorHex ?: SubjectPalettePresets.first()) }
        var remindersOn by remember { mutableStateOf(initial?.remindersEnabled ?: true) }

        AlertDialog(
            onDismissRequest = { showSubjectDialog = false },
            title = { Text(if (initial == null) "Add Subject" else "Edit Subject") },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Subject Name") }, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        OutlinedTextField(value = code, onValueChange = { code = it }, label = { Text("Subject Code (e.g. CS201)") }, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        OutlinedTextField(value = professor, onValueChange = { professor = it }, label = { Text("Professor Name") }, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = room, onValueChange = { room = it }, label = { Text("Room") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = lab, onValueChange = { lab = it }, label = { Text("Lab") }, modifier = Modifier.weight(1f))
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = building, onValueChange = { building = it }, label = { Text("Building") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = floor, onValueChange = { floor = it }, label = { Text("Floor") }, modifier = Modifier.weight(1f))
                        }
                    }
                    item {
                        OutlinedTextField(value = reqPct, onValueChange = { reqPct = it }, label = { Text("Required Attendance % (default 70)") }, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        Text("Subject Colour", style = MaterialTheme.typography.labelMedium)
                        Spacer(modifier = Modifier.height(4.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SubjectPalettePresets.forEach { preset ->
                                val c = parseHexColor(preset)
                                Box(
                                    modifier = Modifier
                                        .size(30.dp)
                                        .background(c, CircleShape)
                                        .clickable { colorHex = preset },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (colorHex.equals(preset, ignoreCase = true)) {
                                        Box(modifier = Modifier.size(10.dp).background(Color.White, CircleShape))
                                    }
                                }
                            }
                        }
                    }
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Enable Lecture Reminders")
                            Switch(checked = remindersOn, onCheckedChange = { remindersOn = it })
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isNotBlank() && code.isNotBlank()) {
                            val sub = Subject(
                                id = initial?.id ?: "sub_${UUID.randomUUID().toString().take(8)}",
                                code = code.trim(),
                                name = name.trim(),
                                professor = professor.trim(),
                                colorHex = colorHex,
                                defaultRoom = room.trim(),
                                defaultLab = lab.trim(),
                                defaultBuilding = building.trim(),
                                defaultFloor = floor.trim(),
                                customRequiredPercentage = reqPct.toDoubleOrNull() ?: 70.0,
                                remindersEnabled = remindersOn
                            )
                            viewModel.saveSubject(sub)
                            showSubjectDialog = false
                        }
                    }
                ) {
                    Text("SAVE")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSubjectDialog = false }) { Text("CANCEL") }
            }
        )
    }

    // Timetable Slot Create/Edit Dialog
    if (showSlotDialog && uiState.subjects.isNotEmpty()) {
        val initial = editingSlot
        var selectedSubjectId by remember { mutableStateOf(initial?.subjectId ?: uiState.subjects.first().id) }
        var day by remember { mutableIntStateOf(initial?.dayOfWeek ?: selectedDayOfWeek) }
        var startTime by remember { mutableStateOf(initial?.startTime ?: "09:00") }
        var endTime by remember { mutableStateOf(initial?.endTime ?: "10:00") }
        var room by remember { mutableStateOf(initial?.roomNumber ?: "") }
        var lab by remember { mutableStateOf(initial?.labNumber ?: "") }
        var building by remember { mutableStateOf(initial?.building ?: "") }
        var floor by remember { mutableStateOf(initial?.floor ?: "") }
        var lectureType by remember { mutableStateOf(initial?.lectureType ?: LectureType.LECTURE) }
        var rotation by remember { mutableStateOf(initial?.rotationPattern ?: RotationPattern.EVERY_WEEK) }

        AlertDialog(
            onDismissRequest = { showSlotDialog = false },
            title = { Text(if (initial == null) "Add Timetable Slot" else "Edit Timetable Slot") },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        Text("Subject", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            uiState.subjects.forEach { sub ->
                                FilterChip(
                                    selected = selectedSubjectId == sub.id,
                                    onClick = { selectedSubjectId = sub.id },
                                    label = { Text(sub.code) }
                                )
                            }
                        }
                    }
                    item {
                        Text("Day of Week", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            (1..7).forEach { d ->
                                FilterChip(
                                    selected = day == d,
                                    onClick = { day = d },
                                    label = { Text(TimetableGenerator.dayName(d).take(3)) }
                                )
                            }
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = startTime, onValueChange = { startTime = it }, label = { Text("Start (HH:mm)") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = endTime, onValueChange = { endTime = it }, label = { Text("End (HH:mm)") }, modifier = Modifier.weight(1f))
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = room, onValueChange = { room = it }, label = { Text("Room") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = lab, onValueChange = { lab = it }, label = { Text("Lab") }, modifier = Modifier.weight(1f))
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = building, onValueChange = { building = it }, label = { Text("Building") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = floor, onValueChange = { floor = it }, label = { Text("Floor") }, modifier = Modifier.weight(1f))
                        }
                    }
                    item {
                        Text("Lecture Type", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            LectureType.entries.forEach { t ->
                                FilterChip(
                                    selected = lectureType == t,
                                    onClick = { lectureType = t },
                                    label = { Text(t.displayName) }
                                )
                            }
                        }
                    }
                    item {
                        Text("Rotation Schedule", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            RotationPattern.entries.forEach { r ->
                                FilterChip(
                                    selected = rotation == r,
                                    onClick = { rotation = r },
                                    label = { Text(r.name) }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val slot = TimetableSlot(
                        id = initial?.id ?: "slot_${UUID.randomUUID().toString().take(8)}",
                        subjectId = selectedSubjectId,
                        dayOfWeek = day,
                        startTime = startTime.trim(),
                        endTime = endTime.trim(),
                        roomNumber = room.trim(),
                        labNumber = lab.trim(),
                        building = building.trim(),
                        floor = floor.trim(),
                        lectureType = lectureType,
                        rotationPattern = rotation
                    )
                    viewModel.saveTimetableSlot(slot)
                    showSlotDialog = false
                }) {
                    Text("SAVE")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSlotDialog = false }) { Text("CANCEL") }
            }
        )
    }

    // One-Time / Extra / Rescheduled Lecture Dialog
    if (showExtraLectureDialog && uiState.subjects.isNotEmpty()) {
        var subjectId by remember { mutableStateOf(uiState.subjects.first().id) }
        var dateStr by remember { mutableStateOf(LocalDate.now().toString()) }
        var startTime by remember { mutableStateOf("15:00") }
        var endTime by remember { mutableStateOf("16:00") }
        var room by remember { mutableStateOf("") }
        var isRescheduled by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showExtraLectureDialog = false },
            title = { Text("Add One-Time / Rescheduled Lecture") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        uiState.subjects.forEach { sub ->
                            FilterChip(
                                selected = subjectId == sub.id,
                                onClick = { subjectId = sub.id },
                                label = { Text(sub.code) }
                            )
                        }
                    }
                    OutlinedTextField(value = dateStr, onValueChange = { dateStr = it }, label = { Text("Date (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = startTime, onValueChange = { startTime = it }, label = { Text("Start (HH:mm)") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = endTime, onValueChange = { endTime = it }, label = { Text("End (HH:mm)") }, modifier = Modifier.weight(1f))
                    }
                    OutlinedTextField(value = room, onValueChange = { room = it }, label = { Text("Room / Lab") }, modifier = Modifier.fillMaxWidth())
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Mark as Rescheduled Lecture")
                        Switch(checked = isRescheduled, onCheckedChange = { isRescheduled = it })
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val sub = subjectsById[subjectId] ?: return@Button
                    val instance = LectureInstance(
                        id = "extra_${dateStr}_${UUID.randomUUID().toString().take(6)}",
                        subjectId = sub.id,
                        subjectName = sub.name,
                        subjectCode = sub.code,
                        subjectColorHex = sub.colorHex,
                        date = dateStr.trim(),
                        startTime = startTime.trim(),
                        endTime = endTime.trim(),
                        roomNumber = room.ifBlank { sub.defaultRoom },
                        labNumber = sub.defaultLab,
                        building = sub.defaultBuilding,
                        floor = sub.defaultFloor,
                        professor = sub.professor,
                        lectureType = LectureType.EXTRA,
                        attendanceStatus = AttendanceStatus.PENDING,
                        isOneTimeOrExtra = true,
                        isRescheduled = isRescheduled
                    )
                    viewModel.saveExtraOrRescheduledLecture(instance)
                    showExtraLectureDialog = false
                }) {
                    Text("ADD LECTURE")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExtraLectureDialog = false }) { Text("CANCEL") }
            }
        )
    }
}
