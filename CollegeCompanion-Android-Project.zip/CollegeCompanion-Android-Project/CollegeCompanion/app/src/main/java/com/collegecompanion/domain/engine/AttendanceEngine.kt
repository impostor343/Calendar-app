package com.collegecompanion.domain.engine

import com.collegecompanion.domain.model.AttendanceStatus
import com.collegecompanion.domain.model.AttendanceWarningLevel
import com.collegecompanion.domain.model.LectureInstance
import com.collegecompanion.domain.model.OverallAttendanceSummary
import com.collegecompanion.domain.model.Subject
import com.collegecompanion.domain.model.SubjectAttendanceSummary
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max

/**
 * Core Attendance Engine implementing Part 6 & Part 15 specifications:
 * - Current attendance is calculated strictly from semesterStartDate up to currentLocalDate.
 * - Future lectures (date > currentLocalDate) are strictly excluded from current attendance.
 * - Unmarked (PENDING) lectures remain pending and are excluded from finalized denominator.
 * - Cancelled lectures and holidays are excluded.
 * - Overall attendance = Total Attended / Total Finalized across all subjects (not average of subject percentages).
 * - Safe absences = max(0, floor(A / r - T)) with BigDecimal precision to prevent IEEE-754 floating-point drift.
 * - Recovery lectures = smallest non-negative integer x satisfying (A + x) / (T + x) >= r.
 * - Attendance colours:
 *   - Red (CRITICAL): strictly below required threshold (< 70% default). Exactly 70.0% is NOT red.
 *   - Yellow/Orange (WARNING): between required threshold (inclusive) and warning threshold (exclusive, e.g. 70.0% .. <75.0%).
 *   - Green (COMFORTABLE): >= warning threshold (e.g. >= 75.0%).
 */
object AttendanceEngine {

    private const val EPSILON = 1e-9

    fun calculatePercentage(attended: Int, absent: Int): Double {
        val totalFinalized = attended + absent
        if (totalFinalized <= 0) return 100.0
        val raw = (attended.toDouble() / totalFinalized.toDouble()) * 100.0
        return BigDecimal.valueOf(raw).setScale(2, RoundingMode.HALF_UP).toDouble()
    }

    /**
     * Safe absences = max(0, floor(A / r - T))
     * where r = requiredPercentage / 100.0, T = A + absent.
     * If current attendance is already below r, returns 0.
     */
    fun calculateSafeAbsences(
        attended: Int,
        absent: Int,
        requiredPercentage: Double = 70.0
    ): Int {
        val totalFinalized = attended + absent
        if (totalFinalized <= 0 || attended <= 0) return 0
        val r = (requiredPercentage / 100.0).coerceIn(0.01, 1.0)

        // Check if already below threshold (with epsilon tolerance for exact ratios like 7/10 vs 0.70)
        val currentRatio = attended.toDouble() / totalFinalized.toDouble()
        if (currentRatio + EPSILON < r) {
            return 0
        }

        // Exact decimal division A / r - T
        val maxTotalAllowed = BigDecimal.valueOf(attended.toLong())
            .divide(BigDecimal.valueOf(r), 10, RoundingMode.HALF_UP)
        val remaining = maxTotalAllowed.subtract(BigDecimal.valueOf(totalFinalized.toLong()))
        val floored = floor(remaining.toDouble() + EPSILON).toInt()
        return max(0, floored)
    }

    /**
     * Minimum consecutive lectures x to attend to reach requiredPercentage:
     * Find smallest non-negative integer x satisfying (A + x) / (T + x) >= r.
     */
    fun calculateRecoveryLectures(
        attended: Int,
        absent: Int,
        requiredPercentage: Double = 70.0
    ): Int {
        val totalFinalized = attended + absent
        if (totalFinalized <= 0) return 0
        val r = (requiredPercentage / 100.0).coerceIn(0.01, 0.9999)

        val currentRatio = attended.toDouble() / totalFinalized.toDouble()
        if (currentRatio + EPSILON >= r) {
            return 0
        }

        // Solve (A + x) / (T + x) >= r  =>  A + x >= r*T + r*x  =>  x*(1 - r) >= r*T - A
        val numerator = r * totalFinalized.toDouble() - attended.toDouble()
        val denominator = 1.0 - r
        var candidate = max(0, ceil((numerator / denominator) - EPSILON).toInt())

        // Verify candidate satisfies (A + x) / (T + x) >= r exactly
        while (((attended + candidate).toDouble() / (totalFinalized + candidate).toDouble()) + EPSILON < r) {
            candidate++
        }
        return candidate
    }

    /**
     * Resolves warning level colour.
     * Attendance strictly below requiredPercentage is CRITICAL (Red).
     * Attendance exactly at requiredPercentage (e.g. 70.0%) is WARNING (Yellow/Orange), NEVER Red.
     * Attendance >= warningThreshold (e.g. 75.0%) is COMFORTABLE (Green).
     */
    fun resolveWarningLevel(
        attended: Int,
        absent: Int,
        requiredPercentage: Double = 70.0,
        warningThresholdPercentage: Double = 75.0
    ): AttendanceWarningLevel {
        val totalFinalized = attended + absent
        if (totalFinalized <= 0) return AttendanceWarningLevel.NEUTRAL

        val exactPercentage = (attended.toDouble() / totalFinalized.toDouble()) * 100.0
        val effectiveWarning = max(requiredPercentage, warningThresholdPercentage)

        return when {
            exactPercentage + EPSILON < requiredPercentage -> AttendanceWarningLevel.CRITICAL
            exactPercentage + EPSILON < effectiveWarning -> AttendanceWarningLevel.WARNING
            else -> AttendanceWarningLevel.COMFORTABLE
        }
    }

    /**
     * Calculates attendance summary for a single subject strictly within [semesterStartDate, currentDate].
     * Holiday dates are excluded even if a stray instance exists on that date.
     */
    fun calculateSubjectAttendance(
        subject: Subject,
        instances: List<LectureInstance>,
        semesterStartDate: LocalDate,
        semesterEndDate: LocalDate,
        currentDate: LocalDate,
        holidayDates: Set<LocalDate> = emptySet(),
        globalRequiredPercentage: Double = 70.0,
        globalWarningPercentage: Double = 75.0
    ): SubjectAttendanceSummary {
        val effectiveRequired = subject.customRequiredPercentage ?: globalRequiredPercentage
        val effectiveWarning = max(effectiveRequired, globalWarningPercentage)

        val subjectInstances = instances.filter { it.subjectId == subject.id }

        var attended = 0
        var absent = 0
        var pendingPast = 0
        var cancelled = 0
        var futureScheduled = 0

        for (instance in subjectInstances) {
            val instanceDate = runCatching { LocalDate.parse(instance.date) }.getOrNull() ?: continue
            if (instanceDate.isBefore(semesterStartDate) || instanceDate.isAfter(semesterEndDate)) {
                continue
            }
            if (holidayDates.contains(instanceDate)) {
                continue
            }

            if (instance.attendanceStatus == AttendanceStatus.CANCELLED) {
                cancelled++
                continue
            }

            if (instanceDate.isAfter(currentDate)) {
                // Future lecture: NEVER include in current attendance
                futureScheduled++
            } else {
                // Past or today up to currentDate
                when (instance.attendanceStatus) {
                    AttendanceStatus.ATTENDED -> attended++
                    AttendanceStatus.ABSENT -> absent++
                    AttendanceStatus.PENDING -> pendingPast++
                    AttendanceStatus.CANCELLED -> cancelled++
                }
            }
        }

        val totalFinalized = attended + absent
        val percentage = calculatePercentage(attended, absent)
        val safeAbsences = calculateSafeAbsences(attended, absent, effectiveRequired)
        val recovery = calculateRecoveryLectures(attended, absent, effectiveRequired)
        val warningLevel = resolveWarningLevel(attended, absent, effectiveRequired, effectiveWarning)

        return SubjectAttendanceSummary(
            subject = subject,
            attendedCount = attended,
            absentCount = absent,
            pendingPastCount = pendingPast,
            cancelledCount = cancelled,
            futureScheduledCount = futureScheduled,
            totalFinalizedCount = totalFinalized,
            currentPercentage = percentage,
            requiredPercentage = effectiveRequired,
            warningThresholdPercentage = effectiveWarning,
            safeAbsences = safeAbsences,
            recoveryLecturesNeeded = recovery,
            warningLevel = warningLevel
        )
    }

    /**
     * Calculates Overall Attendance across all subjects using total attended divided by total finalized
     * (never simple average of subject percentages).
     */
    fun calculateOverallAttendance(
        subjects: List<Subject>,
        instances: List<LectureInstance>,
        semesterStartDate: LocalDate,
        semesterEndDate: LocalDate,
        currentDate: LocalDate,
        holidayDates: Set<LocalDate> = emptySet(),
        globalRequiredPercentage: Double = 70.0,
        globalWarningPercentage: Double = 75.0
    ): OverallAttendanceSummary {
        val subjectSummaries = subjects.map { subject ->
            calculateSubjectAttendance(
                subject = subject,
                instances = instances,
                semesterStartDate = semesterStartDate,
                semesterEndDate = semesterEndDate,
                currentDate = currentDate,
                holidayDates = holidayDates,
                globalRequiredPercentage = globalRequiredPercentage,
                globalWarningPercentage = globalWarningPercentage
            )
        }

        val totalAttended = subjectSummaries.sumOf { it.attendedCount }
        val totalAbsent = subjectSummaries.sumOf { it.absentCount }
        val totalPendingPast = subjectSummaries.sumOf { it.pendingPastCount }
        val totalCancelled = subjectSummaries.sumOf { it.cancelledCount }
        val totalFutureScheduled = subjectSummaries.sumOf { it.futureScheduledCount }
        val totalFinalized = totalAttended + totalAbsent

        val overallPercentage = calculatePercentage(totalAttended, totalAbsent)
        val overallSafeAbsences = calculateSafeAbsences(totalAttended, totalAbsent, globalRequiredPercentage)
        val overallRecovery = calculateRecoveryLectures(totalAttended, totalAbsent, globalRequiredPercentage)
        val overallWarningLevel = resolveWarningLevel(
            attended = totalAttended,
            absent = totalAbsent,
            requiredPercentage = globalRequiredPercentage,
            warningThresholdPercentage = globalWarningPercentage
        )
        val subjectsBelowThreshold = subjectSummaries.count {
            it.warningLevel == AttendanceWarningLevel.CRITICAL
        }

        return OverallAttendanceSummary(
            totalAttended = totalAttended,
            totalAbsent = totalAbsent,
            totalPendingPast = totalPendingPast,
            totalCancelled = totalCancelled,
            totalFutureScheduled = totalFutureScheduled,
            totalFinalized = totalFinalized,
            currentPercentage = overallPercentage,
            globalRequiredPercentage = globalRequiredPercentage,
            globalWarningPercentage = globalWarningPercentage,
            overallSafeAbsences = overallSafeAbsences,
            overallRecoveryLecturesNeeded = overallRecovery,
            warningLevel = overallWarningLevel,
            subjectSummaries = subjectSummaries,
            subjectsBelowThresholdCount = subjectsBelowThreshold
        )
    }
}
