package com.collegecompanion.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.collegecompanion.domain.model.CardStyleOption
import com.collegecompanion.domain.model.FontFamilyOption
import com.collegecompanion.domain.model.ThemeMode
import com.collegecompanion.domain.model.UserPreferences
import com.collegecompanion.domain.model.WidgetThemeOption
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "college_companion_prefs")

class PreferencesDataStore(private val context: Context) {

    private object Keys {
        val PRIMARY_COLOR = stringPreferencesKey("primary_color_hex")
        val SECONDARY_COLOR = stringPreferencesKey("secondary_color_hex")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val FONT_FAMILY = stringPreferencesKey("font_family")
        val FONT_SCALE = floatPreferencesKey("font_scale")
        val CARD_STYLE = stringPreferencesKey("card_style")
        val WIDGET_THEME = stringPreferencesKey("widget_theme")
        val GLOBAL_REQUIRED_ATTENDANCE = doublePreferencesKey("global_required_attendance")
        val WARNING_THRESHOLD_ATTENDANCE = doublePreferencesKey("warning_threshold_attendance")
        val REMINDERS_MASTER_ENABLED = booleanPreferencesKey("reminders_master_enabled")
        val REMINDER_INTERVALS = stringSetPreferencesKey("reminder_intervals_minutes")
        val NOTIFICATION_SOUND = booleanPreferencesKey("notification_sound_enabled")
        val NOTIFICATION_VIBRATION = booleanPreferencesKey("notification_vibration_enabled")
        val SEMESTER_NAME = stringPreferencesKey("semester_name")
        val SEMESTER_START_DATE = stringPreferencesKey("semester_start_date")
        val SEMESTER_END_DATE = stringPreferencesKey("semester_end_date")
        val WORKING_DAYS = stringSetPreferencesKey("working_days_of_week")
        val INITIAL_SEED_DONE = booleanPreferencesKey("initial_seed_done")
    }

    val userPreferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        UserPreferences(
            primaryColorHex = prefs[Keys.PRIMARY_COLOR] ?: "#1A73E8",
            secondaryColorHex = prefs[Keys.SECONDARY_COLOR] ?: "#00897B",
            themeMode = prefs[Keys.THEME_MODE]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() }
                ?: ThemeMode.SYSTEM,
            fontFamily = prefs[Keys.FONT_FAMILY]?.let { runCatching { FontFamilyOption.valueOf(it) }.getOrNull() }
                ?: FontFamilyOption.SANS_SERIF,
            fontScale = prefs[Keys.FONT_SCALE] ?: 1.0f,
            cardStyle = prefs[Keys.CARD_STYLE]?.let { runCatching { CardStyleOption.valueOf(it) }.getOrNull() }
                ?: CardStyleOption.ELEVATED,
            widgetTheme = prefs[Keys.WIDGET_THEME]?.let { runCatching { WidgetThemeOption.valueOf(it) }.getOrNull() }
                ?: WidgetThemeOption.BLUE_CALENDAR,
            globalRequiredAttendance = prefs[Keys.GLOBAL_REQUIRED_ATTENDANCE] ?: 70.0,
            warningThresholdAttendance = prefs[Keys.WARNING_THRESHOLD_ATTENDANCE] ?: 75.0,
            remindersMasterEnabled = prefs[Keys.REMINDERS_MASTER_ENABLED] ?: true,
            reminderIntervalsMinutes = prefs[Keys.REMINDER_INTERVALS]
                ?.mapNotNull { it.toIntOrNull() }
                ?.toSet()
                ?.ifEmpty { setOf(30, 15, 5) }
                ?: setOf(30, 15, 5),
            notificationSoundEnabled = prefs[Keys.NOTIFICATION_SOUND] ?: true,
            notificationVibrationEnabled = prefs[Keys.NOTIFICATION_VIBRATION] ?: true,
            semesterName = prefs[Keys.SEMESTER_NAME] ?: "Fall Semester 2026",
            semesterStartDate = prefs[Keys.SEMESTER_START_DATE] ?: "2026-07-01",
            semesterEndDate = prefs[Keys.SEMESTER_END_DATE] ?: "2026-12-15",
            workingDaysOfWeek = prefs[Keys.WORKING_DAYS]
                ?.mapNotNull { it.toIntOrNull() }
                ?.toSet()
                ?.ifEmpty { setOf(1, 2, 3, 4, 5) }
                ?: setOf(1, 2, 3, 4, 5)
        )
    }

    suspend fun getPreferencesSnapshot(): UserPreferences = userPreferencesFlow.first()

    suspend fun isInitialSeedDone(): Boolean =
        context.dataStore.data.first()[Keys.INITIAL_SEED_DONE] ?: false

    suspend fun markInitialSeedDone() {
        context.dataStore.edit { it[Keys.INITIAL_SEED_DONE] = true }
    }

    suspend fun updateAppearance(
        primaryColorHex: String? = null,
        secondaryColorHex: String? = null,
        themeMode: ThemeMode? = null,
        fontFamily: FontFamilyOption? = null,
        fontScale: Float? = null,
        cardStyle: CardStyleOption? = null,
        widgetTheme: WidgetThemeOption? = null
    ) {
        context.dataStore.edit { prefs ->
            primaryColorHex?.let { prefs[Keys.PRIMARY_COLOR] = it }
            secondaryColorHex?.let { prefs[Keys.SECONDARY_COLOR] = it }
            themeMode?.let { prefs[Keys.THEME_MODE] = it.name }
            fontFamily?.let { prefs[Keys.FONT_FAMILY] = it.name }
            fontScale?.let { prefs[Keys.FONT_SCALE] = it }
            cardStyle?.let { prefs[Keys.CARD_STYLE] = it.name }
            widgetTheme?.let { prefs[Keys.WIDGET_THEME] = it.name }
        }
    }

    suspend fun updateAttendanceSettings(
        requiredPercentage: Double,
        warningPercentage: Double
    ) {
        context.dataStore.edit { prefs ->
            prefs[Keys.GLOBAL_REQUIRED_ATTENDANCE] = requiredPercentage.coerceIn(10.0, 100.0)
            prefs[Keys.WARNING_THRESHOLD_ATTENDANCE] = warningPercentage.coerceIn(requiredPercentage, 100.0)
        }
    }

    suspend fun updateNotificationSettings(
        masterEnabled: Boolean,
        intervalsMinutes: Set<Int>,
        soundEnabled: Boolean,
        vibrationEnabled: Boolean
    ) {
        context.dataStore.edit { prefs ->
            prefs[Keys.REMINDERS_MASTER_ENABLED] = masterEnabled
            prefs[Keys.REMINDER_INTERVALS] = intervalsMinutes.map { it.toString() }.toSet()
            prefs[Keys.NOTIFICATION_SOUND] = soundEnabled
            prefs[Keys.NOTIFICATION_VIBRATION] = vibrationEnabled
        }
    }

    suspend fun updateSemesterConfig(
        semesterName: String,
        startDate: String,
        endDate: String,
        workingDays: Set<Int>
    ) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SEMESTER_NAME] = semesterName
            prefs[Keys.SEMESTER_START_DATE] = startDate
            prefs[Keys.SEMESTER_END_DATE] = endDate
            prefs[Keys.WORKING_DAYS] = workingDays.map { it.toString() }.toSet()
        }
    }
}
