package com.collegecompanion.widget

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.collegecompanion.data.local.CollegeCompanionDatabase
import com.collegecompanion.data.preferences.PreferencesDataStore
import com.collegecompanion.data.repository.CollegeRepository
import com.collegecompanion.data.repository.CompleteDayAbsentPreview
import com.collegecompanion.domain.model.AttendanceStatus
import com.collegecompanion.ui.theme.CollegeCompanionTheme
import kotlinx.coroutines.launch
import java.time.LocalDate

/**
 * Confirmation dialog Activity launched when the user taps "COMPLETE ABSENT" on the home-screen widget
 * (Part 5.B).
 * - Displays all affected lectures for the target date.
 * - Explicitly warns if previously ATTENDED lectures will be changed to ABSENT.
 * - Executes the bulk update transactionally and provides an immediate one-tap UNDO option.
 */
class CompleteDayAbsentActivity : ComponentActivity() {

    companion object {
        const val EXTRA_TARGET_DATE = "extra_target_date"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val dateString = intent.getStringExtra(EXTRA_TARGET_DATE) ?: LocalDate.now().toString()
        val targetDate = runCatching { LocalDate.parse(dateString) }.getOrDefault(LocalDate.now())

        val database = CollegeCompanionDatabase.getInstance(applicationContext)
        val prefsStore = PreferencesDataStore(applicationContext)
        val repository = CollegeRepository(applicationContext, database, prefsStore)

        setContent {
            CollegeCompanionTheme {
                val scope = rememberCoroutineScope()
                var preview by remember { mutableStateOf<CompleteDayAbsentPreview?>(null) }
                var completedOperationId by remember { mutableStateOf<String?>(null) }
                var wasUndone by remember { mutableStateOf(false) }

                LaunchedEffect(targetDate) {
                    preview = repository.previewCompleteDayAbsent(targetDate)
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.55f))
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Text(
                                text = "Complete Day Absence",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Date: $targetDate",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            val currentPreview = preview
                            if (currentPreview == null) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CircularProgressIndicator()
                                }
                            } else if (completedOperationId != null) {
                                Surface(
                                    color = if (wasUndone) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text(
                                            text = if (wasUndone) {
                                                "Bulk absence operation undone. Previous attendance statuses restored."
                                            } else {
                                                "Marked ${currentPreview.applicableLectures.size} lecture(s) absent for $targetDate."
                                            },
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color(0xFF1B1B1F)
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    if (!wasUndone) {
                                        OutlinedButton(
                                            onClick = {
                                                val opId = completedOperationId ?: return@OutlinedButton
                                                scope.launch {
                                                    if (repository.undoBulkAbsenceOperation(opId)) {
                                                        wasUndone = true
                                                    }
                                                }
                                            }
                                        ) {
                                            Text("UNDO BULK ABSENCE")
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                    }
                                    Button(onClick = { finish() }) {
                                        Text("DONE")
                                    }
                                }
                            } else if (!currentPreview.canProceed) {
                                Text(
                                    text = currentPreview.blockingReason ?: "No applicable lectures.",
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    Button(onClick = { finish() }) {
                                        Text("CLOSE")
                                    }
                                }
                            } else {
                                if (currentPreview.previouslyAttendedLectures.isNotEmpty()) {
                                    Surface(
                                        color = Color(0xFFFFF3E0),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Warning,
                                                contentDescription = "Warning",
                                                tint = Color(0xFFE65100)
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Text(
                                                text = "Warning: ${currentPreview.previouslyAttendedLectures.size} lecture(s) already marked ATTENDED will be overwritten to ABSENT.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color(0xFFBF360C),
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }
                                }

                                Text(
                                    text = "Affected Lectures (${currentPreview.applicableLectures.size}):",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.SemiBold
                                )

                                LazyColumn(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(180.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(currentPreview.applicableLectures, key = { it.id }) { lecture ->
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = lecture.subjectName,
                                                        style = MaterialTheme.typography.bodyMedium,
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                    Text(
                                                        text = "${lecture.startTime} - ${lecture.endTime} • ${lecture.formattedLocation()}",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                Text(
                                                    text = "${lecture.attendanceStatus.displayName} → Absent",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = if (lecture.attendanceStatus == AttendanceStatus.ATTENDED) {
                                                        Color(0xFFD32F2F)
                                                    } else {
                                                        MaterialTheme.colorScheme.onSurfaceVariant
                                                    },
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    OutlinedButton(onClick = { finish() }) {
                                        Text("CANCEL")
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Button(
                                        onClick = {
                                            scope.launch {
                                                val opId = repository.executeCompleteDayAbsent(targetDate)
                                                if (opId != null) {
                                                    completedOperationId = opId
                                                } else {
                                                    finish()
                                                }
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFFD32F2F),
                                            contentColor = Color.White
                                        )
                                    ) {
                                        Text("CONFIRM COMPLETE ABSENT")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
