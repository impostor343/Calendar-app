package com.collegecompanion.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.collegecompanion.domain.model.AcademicCalendarEvent
import com.collegecompanion.domain.model.AttendanceStatus
import com.collegecompanion.domain.model.BulkAbsenceOperationRecord
import com.collegecompanion.domain.model.CalendarEventType
import com.collegecompanion.domain.model.LectureInstance
import com.collegecompanion.domain.model.LectureType
import com.collegecompanion.domain.model.PreviousLectureStatusEntry
import com.collegecompanion.domain.model.RotationPattern
import com.collegecompanion.domain.model.Subject
import com.collegecompanion.domain.model.TimetableSlot

@Entity(
    tableName = "subjects",
    indices = [Index(value = ["code"])]
)
data class SubjectEntity(
    @PrimaryKey val id: String,
    val code: String,
    val name: String,
    val professor: String,
    val colorHex: String,
    val defaultRoom: String,
    val defaultLab: String,
    val defaultBuilding: String,
    val defaultFloor: String,
    val customRequiredPercentage: Double?,
    val remindersEnabled: Boolean
) {
    fun toDomain() = Subject(
        id = id,
        code = code,
        name = name,
        professor = professor,
        colorHex = colorHex,
        defaultRoom = defaultRoom,
        defaultLab = defaultLab,
        defaultBuilding = defaultBuilding,
        defaultFloor = defaultFloor,
        customRequiredPercentage = customRequiredPercentage,
        remindersEnabled = remindersEnabled
    )

    companion object {
        fun fromDomain(s: Subject) = SubjectEntity(
            id = s.id,
            code = s.code,
            name = s.name,
            professor = s.professor,
            colorHex = s.colorHex,
            defaultRoom = s.defaultRoom,
            defaultLab = s.defaultLab,
            defaultBuilding = s.defaultBuilding,
            defaultFloor = s.defaultFloor,
            customRequiredPercentage = s.customRequiredPercentage,
            remindersEnabled = s.remindersEnabled
        )
    }
}

@Entity(
    tableName = "timetable_slots",
    indices = [Index(value = ["subjectId"]), Index(value = ["dayOfWeek"])]
)
data class TimetableSlotEntity(
    @PrimaryKey val id: String,
    val subjectId: String,
    val dayOfWeek: Int,
    val startTime: String,
    val endTime: String,
    val roomNumber: String,
    val labNumber: String,
    val building: String,
    val floor: String,
    val professorOverride: String,
    val lectureType: LectureType,
    val rotationPattern: RotationPattern,
    val isActive: Boolean
) {
    fun toDomain() = TimetableSlot(
        id = id,
        subjectId = subjectId,
        dayOfWeek = dayOfWeek,
        startTime = startTime,
        endTime = endTime,
        roomNumber = roomNumber,
        labNumber = labNumber,
        building = building,
        floor = floor,
        professorOverride = professorOverride,
        lectureType = lectureType,
        rotationPattern = rotationPattern,
        isActive = isActive
    )

    companion object {
        fun fromDomain(slot: TimetableSlot) = TimetableSlotEntity(
            id = slot.id,
            subjectId = slot.subjectId,
            dayOfWeek = slot.dayOfWeek,
            startTime = slot.startTime,
            endTime = slot.endTime,
            roomNumber = slot.roomNumber,
            labNumber = slot.labNumber,
            building = slot.building,
            floor = slot.floor,
            professorOverride = slot.professorOverride,
            lectureType = slot.lectureType,
            rotationPattern = slot.rotationPattern,
            isActive = slot.isActive
        )
    }
}

/**
 * Stores individual lecture instances independently of mutable TimetableSlot rows so historical
 * attendance records are never lost when future timetable templates are edited.
 */
@Entity(
    tableName = "lecture_instances",
    indices = [
        Index(value = ["date"]),
        Index(value = ["subjectId"]),
        Index(value = ["date", "subjectId"])
    ]
)
data class LectureInstanceEntity(
    @PrimaryKey val id: String,
    val subjectId: String,
    val subjectName: String,
    val subjectCode: String,
    val subjectColorHex: String,
    val date: String,
    val startTime: String,
    val endTime: String,
    val roomNumber: String,
    val labNumber: String,
    val building: String,
    val floor: String,
    val professor: String,
    val lectureType: LectureType,
    val attendanceStatus: AttendanceStatus,
    val isOneTimeOrExtra: Boolean,
    val isRescheduled: Boolean,
    val rescheduledFromDate: String?,
    val sourceSlotId: String?,
    val notes: String,
    val lastUpdatedEpochMillis: Long
) {
    fun toDomain() = LectureInstance(
        id = id,
        subjectId = subjectId,
        subjectName = subjectName,
        subjectCode = subjectCode,
        subjectColorHex = subjectColorHex,
        date = date,
        startTime = startTime,
        endTime = endTime,
        roomNumber = roomNumber,
        labNumber = labNumber,
        building = building,
        floor = floor,
        professor = professor,
        lectureType = lectureType,
        attendanceStatus = attendanceStatus,
        isOneTimeOrExtra = isOneTimeOrExtra,
        isRescheduled = isRescheduled,
        rescheduledFromDate = rescheduledFromDate,
        sourceSlotId = sourceSlotId,
        notes = notes,
        lastUpdatedEpochMillis = lastUpdatedEpochMillis
    )

    companion object {
        fun fromDomain(inst: LectureInstance) = LectureInstanceEntity(
            id = inst.id,
            subjectId = inst.subjectId,
            subjectName = inst.subjectName,
            subjectCode = inst.subjectCode,
            subjectColorHex = inst.subjectColorHex,
            date = inst.date,
            startTime = inst.startTime,
            endTime = inst.endTime,
            roomNumber = inst.roomNumber,
            labNumber = inst.labNumber,
            building = inst.building,
            floor = inst.floor,
            professor = inst.professor,
            lectureType = inst.lectureType,
            attendanceStatus = inst.attendanceStatus,
            isOneTimeOrExtra = inst.isOneTimeOrExtra,
            isRescheduled = inst.isRescheduled,
            rescheduledFromDate = inst.rescheduledFromDate,
            sourceSlotId = inst.sourceSlotId,
            notes = inst.notes,
            lastUpdatedEpochMillis = inst.lastUpdatedEpochMillis
        )
    }
}

@Entity(
    tableName = "calendar_events",
    indices = [Index(value = ["startDate", "endDate"])]
)
data class AcademicCalendarEventEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val startDate: String,
    val endDate: String,
    val eventType: CalendarEventType,
    val followsDayOfWeek: Int?,
    val rotationSetOverride: RotationPattern?,
    val subjectId: String?,
    val startTime: String?,
    val endTime: String?,
    val location: String
) {
    fun toDomain() = AcademicCalendarEvent(
        id = id,
        title = title,
        description = description,
        startDate = startDate,
        endDate = endDate,
        eventType = eventType,
        followsDayOfWeek = followsDayOfWeek,
        rotationSetOverride = rotationSetOverride,
        subjectId = subjectId,
        startTime = startTime,
        endTime = endTime,
        location = location
    )

    companion object {
        fun fromDomain(e: AcademicCalendarEvent) = AcademicCalendarEventEntity(
            id = e.id,
            title = e.title,
            description = e.description,
            startDate = e.startDate,
            endDate = e.endDate,
            eventType = e.eventType,
            followsDayOfWeek = e.followsDayOfWeek,
            rotationSetOverride = e.rotationSetOverride,
            subjectId = e.subjectId,
            startTime = e.startTime,
            endTime = e.endTime,
            location = e.location
        )
    }
}

@Entity(
    tableName = "attendance_audit_log",
    indices = [Index(value = ["lectureInstanceId"]), Index(value = ["timestampEpochMillis"])]
)
data class AttendanceAuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val lectureInstanceId: String,
    val subjectId: String,
    val subjectName: String,
    val lectureDate: String,
    val startTime: String,
    val previousStatus: AttendanceStatus,
    val newStatus: AttendanceStatus,
    val source: String, // "WIDGET", "HOME_SCREEN", "ATTENDANCE_HISTORY", "BULK_COMPLETE_ABSENT", "UNDO_BULK"
    val timestampEpochMillis: Long
)

@Entity(
    tableName = "bulk_absence_operations",
    indices = [Index(value = ["targetDate"])]
)
data class BulkAbsenceOperationEntity(
    @PrimaryKey val operationId: String,
    val targetDate: String,
    val timestampEpochMillis: Long,
    val affectedLecturesJson: String,
    val wasUndone: Boolean
)
