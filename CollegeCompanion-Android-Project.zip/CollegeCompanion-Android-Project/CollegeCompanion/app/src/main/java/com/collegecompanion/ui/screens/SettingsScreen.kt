package com.collegecompanion.ui.screens

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.Button
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.collegecompanion.domain.engine.TimetableGenerator
import com.collegecompanion.domain.model.CardStyleOption
import com.collegecompanion.domain.model.FontFamilyOption
import com.collegecompanion.domain.model.ThemeMode
import com.collegecompanion.domain.model.WidgetThemeOption
import com.collegecompanion.notification.LectureReminderScheduler
import com.collegecompanion.ui.theme.SubjectPalettePresets
import com.collegecompanion.ui.theme.parseHexColor
import com.collegecompanion.ui.viewmodel.AppUiState
import com.collegecompanion.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    uiState: AppUiState,
    viewModel: MainViewModel,
    onNavigateToImportSchedule: () -> Unit,
    onNavigateToGenerateAiPrompt: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = uiState.preferences

    var semesterName by remember(prefs.semesterName) { mutableStateOf(prefs.semesterName) }
    var semesterStart by remember(prefs.semesterStartDate) { mutableStateOf(prefs.semesterStartDate) }
    var semesterEnd by remember(prefs.semesterEndDate) { mutableStateOf(prefs.semesterEndDate) }
    var workingDays by remember(prefs.workingDaysOfWeek) { mutableStateOf(prefs.workingDaysOfWeek) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    val exportBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val jsonPayload = viewModel.repository.exportFullBackupJson()
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(jsonPayload.toByteArray(Charsets.UTF_8))
                }
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Quick Schedule Import & AI Generator Section
        item {
            ElevatedCard(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Schedule Import, AI Prompt & Backup",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Import your timetable, academic calendar, or full JSON backup, or copy the AI prompt to generate a structured schedule.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = onNavigateToImportSchedule,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Import Schedule")
                        }
                        Button(
                            onClick = onNavigateToGenerateAiPrompt,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("AI Schedule")
                        }
                    }
                    OutlinedButton(
                        onClick = { exportBackupLauncher.launch("college_companion_backup.json") },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Export Full Database Backup (JSON)")
                    }
                }
            }
        }

        // Appearance, Theme, Colours & Typography Section
        item {
            ElevatedCard(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Palette, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Appearance, Theme & Typography", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    }

                    Text("Theme Mode", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeMode.entries.forEach { mode ->
                            FilterChip(
                                selected = prefs.themeMode == mode,
                                onClick = { viewModel.updateAppearance(themeMode = mode) },
                                label = { Text(mode.name) }
                            )
                        }
                    }

                    Text("Primary Accent Colour", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SubjectPalettePresets.forEach { hex ->
                            val c = parseHexColor(hex)
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(c, CircleShape)
                                    .clickable { viewModel.updateAppearance(primaryColorHex = hex) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (prefs.primaryColorHex.equals(hex, ignoreCase = true)) {
                                    Box(modifier = Modifier.size(12.dp).background(Color.White, CircleShape))
                                }
                            }
                        }
                    }

                    Text("Secondary Colour", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SubjectPalettePresets.forEach { hex ->
                            val c = parseHexColor(hex)
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(c, CircleShape)
                                    .clickable { viewModel.updateAppearance(secondaryColorHex = hex) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (prefs.secondaryColorHex.equals(hex, ignoreCase = true)) {
                                    Box(modifier = Modifier.size(12.dp).background(Color.White, CircleShape))
                                }
                            }
                        }
                    }

                    Text("Font Family", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FontFamilyOption.entries.forEach { font ->
                            FilterChip(
                                selected = prefs.fontFamily == font,
                                onClick = { viewModel.updateAppearance(fontFamily = font) },
                                label = { Text(font.label) }
                            )
                        }
                    }

                    Text("Font Size Scale: ${String.format("%.2f", prefs.fontScale)}x", style = MaterialTheme.typography.labelLarge)
                    Slider(
                        value = prefs.fontScale,
                        onValueChange = { viewModel.updateAppearance(fontScale = it) },
                        valueRange = 0.85f..1.30f
                    )

                    Text("Card Style", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CardStyleOption.entries.forEach { style ->
                            FilterChip(
                                selected = prefs.cardStyle == style,
                                onClick = { viewModel.updateAppearance(cardStyle = style) },
                                label = { Text(style.label) }
                            )
                        }
                    }

                    Text("Home-Screen Widget Appearance", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        WidgetThemeOption.entries.forEach { wTheme ->
                            FilterChip(
                                selected = prefs.widgetTheme == wTheme,
                                onClick = { viewModel.updateAppearance(widgetTheme = wTheme) },
                                label = { Text(wTheme.label) }
                            )
                        }
                    }
                }
            }
        }

        // Attendance Threshold & Warning Levels
        item {
            ElevatedCard(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Attendance Threshold & Warning Levels", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(
                        text = "Minimum Required Attendance: ${prefs.globalRequiredAttendance.toInt()}% (Below this is Red)",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Slider(
                        value = prefs.globalRequiredAttendance.toFloat(),
                        onValueChange = {
                            viewModel.updateAttendanceThresholds(it.toDouble(), prefs.warningThresholdAttendance)
                        },
                        valueRange = 50f..95f
                    )
                    Text(
                        text = "Comfortable (Green) Threshold: ${prefs.warningThresholdAttendance.toInt()}% (Between ${prefs.globalRequiredAttendance.toInt()}% and ${prefs.warningThresholdAttendance.toInt()}% is Amber)",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Slider(
                        value = prefs.warningThresholdAttendance.toFloat(),
                        onValueChange = {
                            viewModel.updateAttendanceThresholds(prefs.globalRequiredAttendance, it.toDouble())
                        },
                        valueRange = prefs.globalRequiredAttendance.toFloat()..100f
                    )
                }
            }
        }

        // Notification & Multi-Interval Reminder Preferences
        item {
            ElevatedCard(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Notifications, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Lecture Reminders (Multi-Interval)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Enable All Lecture Reminders", style = MaterialTheme.typography.bodyLarge)
                        Switch(
                            checked = prefs.remindersMasterEnabled,
                            onCheckedChange = { enabled ->
                                viewModel.updateNotificationPreferences(
                                    masterEnabled = enabled,
                                    intervals = prefs.reminderIntervalsMinutes,
                                    soundEnabled = prefs.notificationSoundEnabled,
                                    vibrationEnabled = prefs.notificationVibrationEnabled
                                )
                            }
                        )
                    }

                    Text(
                        text = "Select Simultaneous Reminder Intervals (Minutes Before Lecture):",
                        style = MaterialTheme.typography.labelLarge
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LectureReminderScheduler.SUPPORTED_INTERVALS.forEach { mins ->
                            val selected = prefs.reminderIntervalsMinutes.contains(mins)
                            FilterChip(
                                selected = selected,
                                onClick = {
                                    val updated = prefs.reminderIntervalsMinutes.toMutableSet()
                                    if (!updated.add(mins)) updated.remove(mins)
                                    viewModel.updateNotificationPreferences(
                                        masterEnabled = prefs.remindersMasterEnabled,
                                        intervals = updated,
                                        soundEnabled = prefs.notificationSoundEnabled,
                                        vibrationEnabled = prefs.notificationVibrationEnabled
                                    )
                                },
                                label = { Text("$mins min") }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Notification Sound")
                        Switch(
                            checked = prefs.notificationSoundEnabled,
                            onCheckedChange = {
                                viewModel.updateNotificationPreferences(
                                    masterEnabled = prefs.remindersMasterEnabled,
                                    intervals = prefs.reminderIntervalsMinutes,
                                    soundEnabled = it,
                                    vibrationEnabled = prefs.notificationVibrationEnabled
                                )
                            }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Vibration")
                        Switch(
                            checked = prefs.notificationVibrationEnabled,
                            onCheckedChange = {
                                viewModel.updateNotificationPreferences(
                                    masterEnabled = prefs.remindersMasterEnabled,
                                    intervals = prefs.reminderIntervalsMinutes,
                                    soundEnabled = prefs.notificationSoundEnabled,
                                    vibrationEnabled = it
                                )
                            }
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            OutlinedButton(
                                onClick = { notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
                            ) {
                                Text("Grant Notification Permission")
                            }
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !LectureReminderScheduler.canScheduleExactAlarms(context)) {
                            OutlinedButton(
                                onClick = {
                                    runCatching {
                                        context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
                                    }
                                }
                            ) {
                                Text("Allow Exact Alarms")
                            }
                        }
                    }
                }
            }
        }

        // Semester Dates & Working Days Configuration
        item {
            ElevatedCard(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Semester & Academic Working Days", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = semesterName,
                        onValueChange = { semesterName = it },
                        label = { Text("Semester Title") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = semesterStart,
                            onValueChange = { semesterStart = it },
                            label = { Text("Start (YYYY-MM-DD)") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = semesterEnd,
                            onValueChange = { semesterEnd = it },
                            label = { Text("End (YYYY-MM-DD)") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Text("Regular College Working Days:", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (1..7).forEach { day ->
                            val isSelected = workingDays.contains(day)
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    val next = workingDays.toMutableSet()
                                    if (!next.add(day)) next.remove(day)
                                    workingDays = next
                                },
                                label = { Text(TimetableGenerator.dayName(day).take(3)) }
                            )
                        }
                    }
                    Button(
                        onClick = {
                            viewModel.updateSemesterConfiguration(
                                semesterName = semesterName.trim(),
                                startDate = semesterStart.trim(),
                                endDate = semesterEnd.trim(),
                                workingDays = workingDays
                            )
                        }
                    ) {
                        Text("Save Semester Configuration")
                    }
                }
            }
        }

        // About Section
        item {
            ElevatedCard(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("About College Companion", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        text = "Version 1.0.0 • 100% Local & Offline Native Android Application (Kotlin, Jetpack Compose, Material 3, Room, DataStore, Jetpack Glance Widgets).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Zero internet permissions, zero tracking, zero ads. All academic data remains privately stored on your device.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
