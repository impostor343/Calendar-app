package com.collegecompanion.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.collegecompanion.data.SampleInitialDataSeeder
import com.collegecompanion.data.local.CollegeCompanionDatabase
import com.collegecompanion.data.local.entity.AttendanceAuditLogEntity
import com.collegecompanion.data.preferences.PreferencesDataStore
import com.collegecompanion.data.repository.CollegeRepository
import com.collegecompanion.data.repository.CompleteDayAbsentPreview
import com.collegecompanion.domain.engine.AttendanceEngine
import com.collegecompanion.domain.engine.ImportMode
import com.collegecompanion.domain.engine.ImportValidationReport
import com.collegecompanion.domain.engine.ProjectedAttendanceEngine
import com.collegecompanion.domain.engine.ScheduleImportExportEngine
import com.collegecompanion.domain.engine.TimetableGenerator
import com.collegecompanion.domain.engine.TimetableOverlapWarning
import com.collegecompanion.domain.model.AcademicCalendarConfig
import com.collegecompanion.domain.model.AcademicCalendarEvent
import com.collegecompanion.domain.model.AttendanceStatus
import com.collegecompanion.domain.model.BulkAbsenceOperationRecord
import com.collegecompanion.domain.model.CardStyleOption
import com.collegecompanion.domain.model.FontFamilyOption
import com.collegecompanion.domain.model.LectureInstance
import com.collegecompanion.domain.model.OverallAttendanceSummary
import com.collegecompanion.domain.model.ProjectedAttendanceResult
import com.collegecompanion.domain.model.ProjectionScenarioType
import com.collegecompanion.domain.model.Subject
import com.collegecompanion.domain.model.ThemeMode
import com.collegecompanion.domain.model.TimetableSlot
import com.collegecompanion.domain.model.UserPreferences
import com.collegecompanion.domain.model.WidgetThemeOption
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

data class NextLectureCountdown(
    val lecture: LectureInstance,
    val minutesUntilStart: Long,
    val formattedCountdown: String
)

data class ProjectionUiConfig(
    val scenario: ProjectionScenarioType = ProjectionScenarioType.ATTEND_ALL,
    val customCount: Int = 2,
    val specificMissedIds: Set<String> = emptySet(),
    val evaluateImmediateHorizonOnly: Boolean = false
)

data class AppUiState(
    val currentDate: LocalDate = LocalDate.now(),
    val currentTime: LocalTime = LocalTime.now(),
    val preferences: UserPreferences = UserPreferences(),
    val subjects: List<Subject> = emptyList(),
    val timetableSlots: List<TimetableSlot> = emptyList(),
    val allInstances: List<LectureInstance> = emptyList(),
    val todayLectures: List<LectureInstance> = emptyList(),
    val isHolidayToday: Boolean = false,
    val todayHolidayTitle: String? = null,
    val nextLectureCountdown: NextLectureCountdown? = null,
    val calendarEvents: List<AcademicCalendarEvent> = emptyList(),
    val holidayDates: Set<LocalDate> = emptySet(),
    val overallAttendance: OverallAttendanceSummary? = null,
    val pendingPastLectures: List<LectureInstance> = emptyList(),
    val futureLectures: List<LectureInstance> = emptyList(),
    val projectionConfig: ProjectionUiConfig = ProjectionUiConfig(),
    val overallProjection: ProjectedAttendanceResult? = null,
    val subjectProjections: List<ProjectedAttendanceResult> = emptyList(),
    val slotOverlapWarnings: List<TimetableOverlapWarning> = emptyList(),
    val instanceOverlapWarnings: List<TimetableOverlapWarning> = emptyList(),
    val auditLogs: List<AttendanceAuditLogEntity> = emptyList(),
    val bulkOperations: List<BulkAbsenceOperationRecord> = emptyList(),
    val statusBannerMessage: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = CollegeCompanionDatabase.getInstance(application)
    private val preferencesDataStore = PreferencesDataStore(application)
    val repository = CollegeRepository(application, database, preferencesDataStore)

    private val _projectionConfig = MutableStateFlow(ProjectionUiConfig())
    val projectionConfig: StateFlow<ProjectionUiConfig> = _projectionConfig.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)

    private val _importValidationReport = MutableStateFlow<ImportValidationReport?>(null)
    val importValidationReport: StateFlow<ImportValidationReport?> = _importValidationReport.asStateFlow()

    // Ticker flow emitting current LocalDateTime every 30 seconds so Home Screen automatically updates on date/time change
    private val clockFlow = flow {
        while (true) {
            emit(LocalDateTime.now())
            delay(30_000L)
        }
    }

    init {
        viewModelScope.launch {
            if (!preferencesDataStore.isInitialSeedDone()) {
                val existingSubjects = database.subjectDao().getAllSubjects()
                if (existingSubjects.isEmpty()) {
                    val sampleBundle = SampleInitialDataSeeder.buildDefaultAcademicBundle()
                    repository.applyValidatedImport(
                        bundle = sampleBundle,
                        mode = ImportMode.COMBINED_SCHEDULE,
                        overwriteExistingFinalizedAttendance = false
                    )
                }
                preferencesDataStore.markInitialSeedDone()
            }
        }
    }

    private val coreDataFlow = combine(
        preferencesDataStore.userPreferencesFlow,
        repository.subjectsFlow,
        repository.timetableSlotsFlow,
        repository.lectureInstancesFlow,
        repository.calendarEventsFlow
    ) { prefs, subjects, slots, instances, events ->
        CoreDataTuple(prefs, subjects, slots, instances, events)
    }

    private val historyFlow = combine(
        repository.auditLogFlow,
        repository.bulkOperationsFlow,
        _projectionConfig,
        _statusBanner
    ) { audits, bulks, projCfg, banner ->
        HistoryTuple(audits, bulks, projCfg, banner)
    }

    val uiState: StateFlow<AppUiState> = combine(
        coreDataFlow,
        historyFlow,
        clockFlow
    ) { core, hist, nowDateTime ->
        val currentDate = nowDateTime.toLocalDate()
        val currentTime = nowDateTime.toLocalTime()
        val prefs = core.prefs

        val calendarConfig = AcademicCalendarConfig(
            semesterName = prefs.semesterName,
            semesterStartDate = prefs.semesterStartDate,
            semesterEndDate = prefs.semesterEndDate,
            workingDaysOfWeek = prefs.workingDaysOfWeek
        )
        val semesterStart = runCatching { LocalDate.parse(prefs.semesterStartDate) }.getOrDefault(currentDate.minusMonths(3))
        val semesterEnd = runCatching { LocalDate.parse(prefs.semesterEndDate) }.getOrDefault(currentDate.plusMonths(3))

        val holidayDates = TimetableGenerator.extractHolidayAndNoClassDates(calendarConfig, core.events)
        val todayStr = currentDate.toString()
        val todayLectures = core.instances
            .filter { it.date == todayStr }
            .sortedBy { it.startTime }

        val todayHolidayEvent = core.events.firstOrNull { ev ->
            TimetableGenerator.isDateWithinEvent(currentDate, ev) && holidayDates.contains(currentDate)
        }

        val nextLecture = computeNextLectureCountdown(
            todayLectures = todayLectures,
            allInstances = core.instances,
            currentDate = currentDate,
            currentTime = currentTime
        )

        val overallAttendance = AttendanceEngine.calculateOverallAttendance(
            subjects = core.subjects,
            instances = core.instances,
            semesterStartDate = semesterStart,
            semesterEndDate = semesterEnd,
            currentDate = currentDate,
            holidayDates = holidayDates,
            globalRequiredPercentage = prefs.globalRequiredAttendance,
            globalWarningPercentage = prefs.warningThresholdAttendance
        )

        val pendingPast = core.instances.filter { inst ->
            val d = runCatching { LocalDate.parse(inst.date) }.getOrNull() ?: return@filter false
            !d.isBefore(semesterStart) &&
                !d.isAfter(currentDate) &&
                !holidayDates.contains(d) &&
                inst.attendanceStatus == AttendanceStatus.PENDING
        }.sortedWith(compareByDescending<LectureInstance> { it.date }.thenBy { it.startTime })

        val futureLectures = ProjectedAttendanceEngine.getValidFutureLectures(
            instances = core.instances,
            currentDate = currentDate,
            semesterStartDate = semesterStart,
            semesterEndDate = semesterEnd,
            holidayDates = holidayDates
        )

        val overallProjection = ProjectedAttendanceEngine.simulateOverallProjection(
            subjects = core.subjects,
            allInstances = core.instances,
            currentDate = currentDate,
            semesterStartDate = semesterStart,
            semesterEndDate = semesterEnd,
            holidayDates = holidayDates,
            scenario = hist.projCfg.scenario,
            customCount = hist.projCfg.customCount,
            specificMissedLectureIds = hist.projCfg.specificMissedIds,
            evaluateImmediateHorizonOnly = hist.projCfg.evaluateImmediateHorizonOnly,
            globalRequiredPercentage = prefs.globalRequiredAttendance,
            globalWarningPercentage = prefs.warningThresholdAttendance
        )

        val subjectProjections = core.subjects.map { subject ->
            ProjectedAttendanceEngine.simulateSubjectProjection(
                subject = subject,
                allInstances = core.instances,
                currentDate = currentDate,
                semesterStartDate = semesterStart,
                semesterEndDate = semesterEnd,
                holidayDates = holidayDates,
                scenario = hist.projCfg.scenario,
                customCount = hist.projCfg.customCount,
                specificMissedLectureIds = hist.projCfg.specificMissedIds,
                evaluateImmediateHorizonOnly = hist.projCfg.evaluateImmediateHorizonOnly,
                globalRequiredPercentage = prefs.globalRequiredAttendance,
                globalWarningPercentage = prefs.warningThresholdAttendance
            )
        }

        val subjectsById = core.subjects.associateBy { it.id }
        val slotOverlaps = TimetableGenerator.detectSlotOverlaps(core.slots, subjectsById)
        val instanceOverlaps = TimetableGenerator.detectInstanceOverlaps(todayLectures)

        AppUiState(
            currentDate = currentDate,
            currentTime = currentTime,
            preferences = prefs,
            subjects = core.subjects,
            timetableSlots = core.slots,
            allInstances = core.instances,
            todayLectures = todayLectures,
            isHolidayToday = holidayDates.contains(currentDate),
            todayHolidayTitle = todayHolidayEvent?.title,
            nextLectureCountdown = nextLecture,
            calendarEvents = core.events,
            holidayDates = holidayDates,
            overallAttendance = overallAttendance,
            pendingPastLectures = pendingPast,
            futureLectures = futureLectures,
            projectionConfig = hist.projCfg,
            overallProjection = overallProjection,
            subjectProjections = subjectProjections,
            slotOverlapWarnings = slotOverlaps,
            instanceOverlapWarnings = instanceOverlaps,
            auditLogs = hist.audits,
            bulkOperations = hist.bulks,
            statusBannerMessage = hist.banner
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = AppUiState()
    )

    private fun computeNextLectureCountdown(
        todayLectures: List<LectureInstance>,
        allInstances: List<LectureInstance>,
        currentDate: LocalDate,
        currentTime: LocalTime
    ): NextLectureCountdown? {
        val upcomingToday = todayLectures.firstOrNull { inst ->
            inst.attendanceStatus != AttendanceStatus.CANCELLED &&
                runCatching { LocalTime.parse(inst.startTime).isAfter(currentTime) }.getOrDefault(false)
        }
        if (upcomingToday != null) {
            val start = LocalTime.parse(upcomingToday.startTime)
            val mins = Duration.between(currentTime, start).toMinutes().coerceAtLeast(0)
            val hours = mins / 60
            val remMins = mins % 60
            val formatted = if (hours > 0) "${hours}h ${remMins}m" else "${remMins}m"
            return NextLectureCountdown(upcomingToday, mins, "Starts in $formatted")
        }

        val nextFuture = allInstances
            .filter {
                it.attendanceStatus != AttendanceStatus.CANCELLED &&
                    it.date > currentDate.toString()
            }
            .minWithOrNull(compareBy<LectureInstance> { it.date }.thenBy { it.startTime })

        return if (nextFuture != null) {
            val nextDateTime = LocalDateTime.of(
                LocalDate.parse(nextFuture.date),
                LocalTime.parse(nextFuture.startTime)
            )
            val mins = Duration.between(LocalDateTime.of(currentDate, currentTime), nextDateTime)
                .toMinutes().coerceAtLeast(0)
            NextLectureCountdown(nextFuture, mins, "Next on ${nextFuture.date} at ${nextFuture.startTime}")
        } else {
            null
        }
    }

    // Actions
    fun markAttendance(instanceId: String, status: AttendanceStatus, source: String = "HOME_SCREEN") {
        viewModelScope.launch {
            repository.markLectureAttendance(instanceId, status, source)
        }
    }

    suspend fun previewCompleteDayAbsent(date: LocalDate): CompleteDayAbsentPreview {
        return repository.previewCompleteDayAbsent(date)
    }

    fun executeCompleteDayAbsent(date: LocalDate) {
        viewModelScope.launch {
            val opId = repository.executeCompleteDayAbsent(date)
            if (opId != null) {
                _statusBanner.value = "Marked all applicable lectures on $date as Absent. You can undo this from Attendance History."
            }
        }
    }

    fun undoBulkOperation(operationId: String) {
        viewModelScope.launch {
            if (repository.undoBulkAbsenceOperation(operationId)) {
                _statusBanner.value = "Bulk absence operation undone and previous attendance restored."
            }
        }
    }

    fun clearBanner() {
        _statusBanner.value = null
    }

    // Projection Scenario updates (never modifies actual attendance)
    fun updateProjectionScenario(
        scenario: ProjectionScenarioType,
        customCount: Int = _projectionConfig.value.customCount,
        evaluateImmediateHorizonOnly: Boolean = _projectionConfig.value.evaluateImmediateHorizonOnly
    ) {
        _projectionConfig.value = _projectionConfig.value.copy(
            scenario = scenario,
            customCount = customCount,
            evaluateImmediateHorizonOnly = evaluateImmediateHorizonOnly
        )
    }

    fun toggleSpecificFutureLectureMiss(instanceId: String) {
        val currentSet = _projectionConfig.value.specificMissedIds.toMutableSet()
        if (!currentSet.add(instanceId)) {
            currentSet.remove(instanceId)
        }
        _projectionConfig.value = _projectionConfig.value.copy(
            scenario = ProjectionScenarioType.SELECT_SPECIFIC_FUTURE,
            specificMissedIds = currentSet
        )
    }

    fun resetProjectionToDefault() {
        _projectionConfig.value = ProjectionUiConfig()
    }

    // Subject & Timetable CRUD
    fun saveSubject(subject: Subject) {
        viewModelScope.launch {
            repository.saveSubject(subject)
            _statusBanner.value = "Saved subject ${subject.name}."
        }
    }

    fun deleteSubject(subjectId: String) {
        viewModelScope.launch {
            repository.deleteSubject(subjectId)
            _statusBanner.value = "Subject removed."
        }
    }

    fun saveTimetableSlot(slot: TimetableSlot) {
        viewModelScope.launch {
            repository.saveTimetableSlot(slot)
            _statusBanner.value = "Timetable slot saved."
        }
    }

    fun deleteTimetableSlot(slotId: String) {
        viewModelScope.launch {
            repository.deleteTimetableSlot(slotId)
            _statusBanner.value = "Timetable slot removed."
        }
    }

    fun saveExtraOrRescheduledLecture(instance: LectureInstance) {
        viewModelScope.launch {
            repository.saveOneTimeOrRescheduledLecture(instance)
            _statusBanner.value = "Saved lecture instance on ${instance.date}."
        }
    }

    fun saveCalendarEvent(event: AcademicCalendarEvent) {
        viewModelScope.launch {
            repository.saveCalendarEvent(event)
            _statusBanner.value = "Saved academic calendar entry '${event.title}'."
        }
    }

    fun deleteCalendarEvent(eventId: String) {
        viewModelScope.launch {
            repository.deleteCalendarEvent(eventId)
            _statusBanner.value = "Removed calendar entry."
        }
    }

    // Import & Validation
    fun validateImportContent(rawText: String, mode: ImportMode, isCsv: Boolean) {
        val current = uiState.value
        val report = if (isCsv) {
            ScheduleImportExportEngine.parseAndValidateCsvTimetable(
                rawCsv = rawText,
                existingSubjects = current.subjects,
                existingSlots = current.timetableSlots,
                existingInstances = current.allInstances
            )
        } else {
            ScheduleImportExportEngine.validateJsonImport(
                rawJson = rawText,
                mode = mode,
                existingSubjects = current.subjects,
                existingSlots = current.timetableSlots,
                existingInstances = current.allInstances
            )
        }
        _importValidationReport.value = report
    }

    fun clearImportValidation() {
        _importValidationReport.value = null
    }

    fun confirmAndApplyImport(mode: ImportMode, overwriteHistory: Boolean = false) {
        val report = _importValidationReport.value ?: return
        val bundle = report.bundle ?: return
        if (!report.isValid) return

        viewModelScope.launch {
            repository.applyValidatedImport(bundle, mode, overwriteHistory)
            _importValidationReport.value = null
            _statusBanner.value = "Successfully imported ${mode.title}!"
        }
    }

    // Settings updates
    fun updateAppearance(
        primaryColorHex: String? = null,
        secondaryColorHex: String? = null,
        themeMode: ThemeMode? = null,
        fontFamily: FontFamilyOption? = null,
        fontScale: Float? = null,
        cardStyle: CardStyleOption? = null,
        widgetTheme: WidgetThemeOption? = null
    ) {
        viewModelScope.launch {
            preferencesDataStore.updateAppearance(
                primaryColorHex = primaryColorHex,
                secondaryColorHex = secondaryColorHex,
                themeMode = themeMode,
                fontFamily = fontFamily,
                fontScale = fontScale,
                cardStyle = cardStyle,
                widgetTheme = widgetTheme
            )
        }
    }

    fun updateAttendanceThresholds(requiredPct: Double, warningPct: Double) {
        viewModelScope.launch {
            preferencesDataStore.updateAttendanceSettings(requiredPct, warningPct)
        }
    }

    fun updateNotificationPreferences(
        masterEnabled: Boolean,
        intervals: Set<Int>,
        soundEnabled: Boolean,
        vibrationEnabled: Boolean
    ) {
        viewModelScope.launch {
            preferencesDataStore.updateNotificationSettings(
                masterEnabled = masterEnabled,
                intervalsMinutes = intervals,
                soundEnabled = soundEnabled,
                vibrationEnabled = vibrationEnabled
            )
            repository.rescheduleUpcomingReminders()
        }
    }

    fun updateSemesterConfiguration(
        semesterName: String,
        startDate: String,
        endDate: String,
        workingDays: Set<Int>
    ) {
        viewModelScope.launch {
            preferencesDataStore.updateSemesterConfig(semesterName, startDate, endDate, workingDays)
            repository.regenerateSchedulePreservingHistory()
            _statusBanner.value = "Semester dates & working days updated."
        }
    }
}

private data class CoreDataTuple(
    val prefs: UserPreferences,
    val subjects: List<Subject>,
    val slots: List<TimetableSlot>,
    val instances: List<LectureInstance>,
    val events: List<AcademicCalendarEvent>
)

private data class HistoryTuple(
    val audits: List<AttendanceAuditLogEntity>,
    val bulks: List<BulkAbsenceOperationRecord>,
    val projCfg: ProjectionUiConfig,
    val banner: String?
)
