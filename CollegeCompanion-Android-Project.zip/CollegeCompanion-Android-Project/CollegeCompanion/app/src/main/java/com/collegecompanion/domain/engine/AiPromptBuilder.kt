package com.collegecompanion.domain.engine

/**
 * Generates the complete external AI Assistant prompt for "Generate My Academic Schedule" (Part 10.D)
 * as well as the sample JSON schedule matching the documented schema.
 */
object AiPromptBuilder {

    fun buildExternalAiSchedulePrompt(
        semesterName: String = "Fall Semester 2026",
        semesterStartDate: String = "2026-07-01",
        semesterEndDate: String = "2026-12-15"
    ): String = """
You are an Academic Schedule & Timetable Data Extraction Assistant for the "College Companion" Android application.

Your task is to transform the user's supplied college timetable, academic calendar, or syllabus documents into a SINGLE, strictly valid, machine-readable JSON file matching the College Companion Import Schema v1 below.

CRITICAL RULES:
1. NEVER invent, guess, or fabricate missing rooms, professors, dates, or times. Leave optional strings as "" if not provided.
2. If any dates, times, or weekday mappings are ambiguous or contradictory, explicitly ask the user for clarification and list unresolved issues before producing the final JSON.
3. Preserve all available lecture details: subject name, subject code, professor name, room number, laboratory number, building, floor, start/end times (24-hour HH:mm format), and lecture type (LECTURE, LAB, TUTORIAL, SEMINAR, WORKSHOP, EXTRA).
4. Map recurring weekdays using ISO-8601 integers: 1 = Monday, 2 = Tuesday, 3 = Wednesday, 4 = Thursday, 5 = Friday, 6 = Saturday, 7 = Sunday.
5. Identify all holidays, vacations, examination periods, non-working days, special working Saturdays, and timetable override days (e.g., "Saturday Nov 14 follows Monday's timetable" -> eventType: "SPECIAL_WORKING_SATURDAY", followsDayOfWeek: 1).
6. Detect and warn the user if any two lectures on the same day have overlapping start/end times.
7. Output valid UTF-8 JSON conforming to the schema below.

====================================================================
COLLEGE COMPANION JSON IMPORT SCHEMA (v1)
====================================================================
{
  "schemaVersion": 1,
  "exportTimestampEpochMillis": 1761955200000,
  "calendarConfig": {
    "semesterName": "$semesterName",
    "semesterStartDate": "$semesterStartDate",
    "semesterEndDate": "$semesterEndDate",
    "workingDaysOfWeek": [1, 2, 3, 4, 5]
  },
  "subjects": [
    {
      "id": "sub_ds",
      "code": "CS201",
      "name": "Data Structures",
      "professor": "Dr. A. Sharma",
      "colorHex": "#1A73E8",
      "defaultRoom": "301",
      "defaultLab": "Lab-2",
      "defaultBuilding": "Main CS Block",
      "defaultFloor": "3rd",
      "customRequiredPercentage": 70.0,
      "remindersEnabled": true
    },
    {
      "id": "sub_dbms",
      "code": "CS204",
      "name": "Database Management Systems",
      "professor": "Prof. R. Patel",
      "colorHex": "#00897B",
      "defaultRoom": "204",
      "defaultLab": "DB-Lab-1",
      "defaultBuilding": "IT Annex",
      "defaultFloor": "2nd",
      "customRequiredPercentage": 70.0,
      "remindersEnabled": true
    },
    {
      "id": "sub_prob",
      "code": "MA202",
      "name": "Probability and Statistics",
      "professor": "Dr. K. Iyer",
      "colorHex": "#E65100",
      "defaultRoom": "105",
      "defaultLab": "",
      "defaultBuilding": "Science Block",
      "defaultFloor": "1st",
      "customRequiredPercentage": 70.0,
      "remindersEnabled": true
    }
  ],
  "timetableSlots": [
    {
      "id": "slot_mon_0900_ds",
      "subjectId": "sub_ds",
      "dayOfWeek": 1,
      "startTime": "09:00",
      "endTime": "10:00",
      "roomNumber": "301",
      "labNumber": "",
      "building": "Main CS Block",
      "floor": "3rd",
      "professorOverride": "Dr. A. Sharma",
      "lectureType": "LECTURE",
      "rotationPattern": "EVERY_WEEK",
      "isActive": true
    },
    {
      "id": "slot_mon_1000_ds",
      "subjectId": "sub_ds",
      "dayOfWeek": 1,
      "startTime": "10:00",
      "endTime": "11:00",
      "roomNumber": "301",
      "labNumber": "",
      "building": "Main CS Block",
      "floor": "3rd",
      "professorOverride": "Dr. A. Sharma",
      "lectureType": "LECTURE",
      "rotationPattern": "EVERY_WEEK",
      "isActive": true
    },
    {
      "id": "slot_mon_1145_dbms",
      "subjectId": "sub_dbms",
      "dayOfWeek": 1,
      "startTime": "11:45",
      "endTime": "12:45",
      "roomNumber": "204",
      "labNumber": "",
      "building": "IT Annex",
      "floor": "2nd",
      "professorOverride": "Prof. R. Patel",
      "lectureType": "LECTURE",
      "rotationPattern": "EVERY_WEEK",
      "isActive": true
    },
    {
      "id": "slot_mon_1245_prob",
      "subjectId": "sub_prob",
      "dayOfWeek": 1,
      "startTime": "12:45",
      "endTime": "13:45",
      "roomNumber": "105",
      "labNumber": "",
      "building": "Science Block",
      "floor": "1st",
      "professorOverride": "Dr. K. Iyer",
      "lectureType": "LECTURE",
      "rotationPattern": "EVERY_WEEK",
      "isActive": true
    }
  ],
  "calendarEvents": [
    {
      "id": "ev_diwali_break",
      "title": "Diwali Festival Holiday",
      "description": "Official College Holiday",
      "startDate": "2026-11-08",
      "endDate": "2026-11-12",
      "eventType": "HOLIDAY",
      "followsDayOfWeek": null,
      "rotationSetOverride": null,
      "subjectId": null,
      "startTime": null,
      "endTime": null,
      "location": ""
    },
    {
      "id": "ev_working_sat_nov14",
      "title": "Compensatory Working Saturday (Follows Monday Schedule)",
      "description": "Follows Monday timetable to compensate for festival holiday",
      "startDate": "2026-11-14",
      "endDate": "2026-11-14",
      "eventType": "SPECIAL_WORKING_SATURDAY",
      "followsDayOfWeek": 1,
      "rotationSetOverride": null,
      "subjectId": null,
      "startTime": null,
      "endTime": null,
      "location": ""
    }
  ]
}

ENUM VALUES REFERENCE:
- lectureType: "LECTURE" | "LAB" | "TUTORIAL" | "SEMINAR" | "WORKSHOP" | "EXTRA"
- rotationPattern: "EVERY_WEEK" | "ODD_WEEKS" | "EVEN_WEEKS" | "ROTATION_SET_A" | "ROTATION_SET_B"
- eventType: "HOLIDAY" | "NON_WORKING_DAY" | "SPECIAL_WORKING_SATURDAY" | "TIMETABLE_OVERRIDE_DAY" | "EXAMINATION" | "VACATION" | "SPECIAL_LECTURE" | "EVENT" | "ACADEMIC_DEADLINE"

Now, please wait for or analyze my attached/pasted college timetable and academic calendar data and produce the validated JSON.
""".trimIndent()
}
