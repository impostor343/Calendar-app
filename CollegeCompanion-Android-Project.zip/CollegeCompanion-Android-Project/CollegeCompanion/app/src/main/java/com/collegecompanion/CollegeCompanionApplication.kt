package com.collegecompanion

import android.app.Application
import com.collegecompanion.notification.LectureReminderScheduler
import com.collegecompanion.worker.DailyWidgetRefreshWorker

class CollegeCompanionApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        LectureReminderScheduler.ensureNotificationChannel(this)
        DailyWidgetRefreshWorker.enqueuePeriodicSync(this)
    }
}
