package com.collegecompanion.domain.engine

import com.collegecompanion.domain.model.AcademicCalendarConfig
import com.collegecompanion.domain.model.AcademicCalendarEvent
import com.collegecompanion.domain.model.BulkAbsenceOperationRecord
import com.collegecompanion.domain.model.CalendarEventType
import com.collegecompanion.domain.model.LectureInstance
import com.collegecompanion.domain.model.LectureType
import com.collegecompanion.domain.model.RotationPattern
import com.collegecompanion.domain.model.Subject
import com.collegecompanion.domain.model.TimetableSlot
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.time.LocalDate
import java.time.LocalTime

@Serializable
enum class ImportMode(val title: String) {
    TIMETABLE_ONLY("Import Timetable Only"),
    ACADEMIC_CALENDAR_ONLY("Import Academic Calendar Only"),
    COMBINED_SCHEDULE("Import Combined Academic Schedule"),
    FULL_BACKUP_RESTORE("Full Database Backup & Restore")
}

@Serializable
data class AcademicScheduleBundle(
    val schemaVersion: Int = 1,
    val exportTimestampEpochMillis: Long = 0L,
    val calendarConfig: AcademicCalendarConfig? = null,
    val subjects: List<Subject> = emptyList(),
    val timetableSlots: List<TimetableSlot> = emptyList(),
    val calendarEvents: List<AcademicCalendarEvent> = emptyList(),
    val lectureInstances: List<LectureInstance> = emptyList(),
    val bulkOperationsHistory: List<BulkAbsenceOperationRecord> = emptyList()
)

data class ImportValidationReport(
    val isValid: Boolean,
    val bundle: AcademicScheduleBundle?,
    val errors: List<String>,
    val warnings: List<String>,
    val duplicateSlotIds: List<String>,
    val duplicateSubjectIds: List<String>,
    val overlapWarnings: List<TimetableOverlapWarning>,
    val preservedAttendanceRecordsCount: Int
)

/**
 * Handles JSON & CSV Schedule Import, Validation, Duplicate Detection, Conflict Detection,
 * and Full Backup/Restore (Part 10 & Part 13).
 */
object ScheduleImportExportEngine {

    val jsonFormat = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
        isLenient = true
    }

    fun exportToJson(bundle: AcademicScheduleBundle): String {
        return jsonFormat.encodeToString(bundle)
    }

    /**
     * Parses and validates JSON schedule payload for Timetable-only, Calendar-only, Combined, or Full Backup.
     */
    fun validateJsonImport(
        rawJson: String,
        mode: ImportMode,
        existingSubjects: List<Subject> = emptyList(),
        existingSlots: List<TimetableSlot> = emptyList(),
        existingInstances: List<LectureInstance> = emptyList()
    ): ImportValidationReport {
        val errors = mutableListOf<String>()
        val warnings = mutableListOf<String>()

        if (rawJson.isBlank()) {
            return ImportValidationReport(
                isValid = false,
                bundle = null,
                errors = listOf("Import content is empty."),
                warnings = emptyList(),
                duplicateSlotIds = emptyList(),
                duplicateSubjectIds = emptyList(),
                overlapWarnings = emptyList(),
                preservedAttendanceRecordsCount = 0
            )
        }

        val bundle = try {
            jsonFormat.decodeFromString<AcademicScheduleBundle>(rawJson)
        } catch (e: Exception) {
            return ImportValidationReport(
                isValid = false,
                bundle = null,
                errors = listOf("Invalid JSON syntax or schema mismatch: ${e.message}"),
                warnings = emptyList(),
                duplicateSlotIds = emptyList(),
                duplicateSubjectIds = emptyList(),
                overlapWarnings = emptyList(),
                preservedAttendanceRecordsCount = 0
            )
        }

        // Mode-specific presence validation
        when (mode) {
            ImportMode.TIMETABLE_ONLY -> {
                if (bundle.subjects.isEmpty() && bundle.timetableSlots.isEmpty()) {
                    errors.add("Timetable import requires at least one subject or timetable slot.")
                }
            }
            ImportMode.ACADEMIC_CALENDAR_ONLY -> {
                if (bundle.calendarConfig == null && bundle.calendarEvents.isEmpty()) {
                    errors.add("Academic calendar import requires calendarConfig or calendarEvents.")
                }
            }
            ImportMode.COMBINED_SCHEDULE -> {
                if (bundle.subjects.isEmpty() && bundle.timetableSlots.isEmpty() && bundle.calendarEvents.isEmpty()) {
                    errors.add("Combined schedule import contains no subjects, slots, or calendar events.")
                }
            }
            ImportMode.FULL_BACKUP_RESTORE -> {
                // Any valid bundle can be restored
            }
        }

        // Validate semester dates if present
        bundle.calendarConfig?.let { cfg ->
            val start = runCatching { LocalDate.parse(cfg.semesterStartDate) }.getOrNull()
            val end = runCatching { LocalDate.parse(cfg.semesterEndDate) }.getOrNull()
            if (start == null || end == null) {
                errors.add("Invalid semesterStartDate or semesterEndDate format (expected YYYY-MM-DD).")
            } else if (end.isBefore(start)) {
                errors.add("semesterEndDate (${cfg.semesterEndDate}) cannot be before semesterStartDate (${cfg.semesterStartDate}).")
            }
        }

        // Validate subjects
        val existingSubjectIds = existingSubjects.map { it.id }.toSet()
        val duplicateSubjectIds = mutableListOf<String>()
        val seenSubjectIds = mutableSetOf<String>()
        for (subject in bundle.subjects) {
            if (subject.id.isBlank() || subject.name.isBlank()) {
                errors.add("Subject is missing id or name: $subject")
            }
            if (!seenSubjectIds.add(subject.id) || existingSubjectIds.contains(subject.id)) {
                duplicateSubjectIds.add(subject.id)
            }
        }
        if (duplicateSubjectIds.isNotEmpty()) {
            warnings.add("${duplicateSubjectIds.size} subject(s) match existing IDs and will be updated cleanly without losing attendance history.")
        }

        // Validate timetable slots
        val allKnownSubjectIds = existingSubjectIds + bundle.subjects.map { it.id }.toSet()
        val existingSlotIds = existingSlots.map { it.id }.toSet()
        val duplicateSlotIds = mutableListOf<String>()
        val seenSlotIds = mutableSetOf<String>()

        for (slot in bundle.timetableSlots) {
            if (slot.dayOfWeek !in 1..7) {
                errors.add("Slot '${slot.id}' has invalid dayOfWeek ${slot.dayOfWeek} (expected 1=Monday..7=Sunday).")
            }
            val start = runCatching { LocalTime.parse(slot.startTime) }.getOrNull()
            val end = runCatching { LocalTime.parse(slot.endTime) }.getOrNull()
            if (start == null || end == null) {
                errors.add("Slot '${slot.id}' has invalid time format (${slot.startTime}-${slot.endTime}). Expected HH:mm.")
            } else if (!end.isAfter(start)) {
                errors.add("Slot '${slot.id}' endTime (${slot.endTime}) must be after startTime (${slot.startTime}).")
            }
            if (!allKnownSubjectIds.contains(slot.subjectId)) {
                errors.add("Slot '${slot.id}' references unknown subjectId '${slot.subjectId}'.")
            }
            if (!seenSlotIds.add(slot.id) || existingSlotIds.contains(slot.id)) {
                duplicateSlotIds.add(slot.id)
            }
        }

        if (duplicateSlotIds.isNotEmpty()) {
            warnings.add("${duplicateSlotIds.size} timetable slot(s) already exist and will be merged without duplicating records.")
        }

        // Validate calendar events
        for (ev in bundle.calendarEvents) {
            val s = runCatching { LocalDate.parse(ev.startDate) }.getOrNull()
            val e = runCatching { LocalDate.parse(ev.endDate) }.getOrNull()
            if (s == null || e == null) {
                errors.add("Calendar event '${ev.title}' has invalid startDate/endDate (expected YYYY-MM-DD).")
            } else if (e.isBefore(s)) {
                errors.add("Calendar event '${ev.title}' endDate (${ev.endDate}) is before startDate (${ev.startDate}).")
            }
        }

        // Overlap detection
        val mergedSubjects = (existingSubjects + bundle.subjects).associateBy { it.id }
        val overlapWarnings = TimetableGenerator.detectSlotOverlaps(bundle.timetableSlots, mergedSubjects)
        if (overlapWarnings.isNotEmpty()) {
            warnings.add("Detected ${overlapWarnings.size} overlapping lecture slot(s) in imported schedule.")
        }

        val finalizedHistoryCount = existingInstances.count {
            it.attendanceStatus == com.collegecompanion.domain.model.AttendanceStatus.ATTENDED ||
                it.attendanceStatus == com.collegecompanion.domain.model.AttendanceStatus.ABSENT
        }

        return ImportValidationReport(
            isValid = errors.isEmpty(),
            bundle = bundle,
            errors = errors,
            warnings = warnings,
            duplicateSlotIds = duplicateSlotIds,
            duplicateSubjectIds = duplicateSubjectIds,
            overlapWarnings = overlapWarnings,
            preservedAttendanceRecordsCount = finalizedHistoryCount
        )
    }

    /**
     * Parses CSV schedule format into an AcademicScheduleBundle and validates it.
     * Expected CSV header:
     * subjectCode,subjectName,professor,dayOfWeek,startTime,endTime,roomNumber,labNumber,building,floor,lectureType,colorHex
     */
    fun parseAndValidateCsvTimetable(
        rawCsv: String,
        existingSubjects: List<Subject> = emptyList(),
        existingSlots: List<TimetableSlot> = emptyList(),
        existingInstances: List<LectureInstance> = emptyList()
    ): ImportValidationReport {
        val lines = rawCsv.lines().map { it.trim() }.filter { it.isNotBlank() && !it.startsWith("#") }
        if (lines.size < 2) {
            return ImportValidationReport(
                isValid = false,
                bundle = null,
                errors = listOf("CSV file must contain a header row and at least one timetable row."),
                warnings = emptyList(),
                duplicateSlotIds = emptyList(),
                duplicateSubjectIds = emptyList(),
                overlapWarnings = emptyList(),
                preservedAttendanceRecordsCount = 0
            )
        }

        val subjectsByCode = LinkedHashMap<String, Subject>()
        val slots = mutableListOf<TimetableSlot>()
        val parseErrors = mutableListOf<String>()

        for ((index, line) in lines.drop(1).withIndex()) {
            val rowNum = index + 2
            val cols = line.split(",").map { it.trim() }
            if (cols.size < 6) {
                parseErrors.add("Row $rowNum has fewer than 6 columns: '$line'")
                continue
            }
            val code = cols[0]
            val name = cols[1]
            val professor = cols.getOrNull(2) ?: ""
            val dayOfWeek = cols[3].toIntOrNull() ?: parseDayName(cols[3])
            val startTime = cols[4]
            val endTime = cols[5]
            val room = cols.getOrNull(6) ?: ""
            val lab = cols.getOrNull(7) ?: ""
            val building = cols.getOrNull(8) ?: ""
            val floor = cols.getOrNull(9) ?: ""
            val typeStr = cols.getOrNull(10)?.uppercase() ?: "LECTURE"
            val colorHex = cols.getOrNull(11)?.ifBlank { "#1A73E8" } ?: "#1A73E8"

            if (dayOfWeek !in 1..7) {
                parseErrors.add("Row $rowNum has unrecognized dayOfWeek '${cols[3]}'")
                continue
            }

            val subjectId = "sub_${code.lowercase().replace(Regex("[^a-z0-9]"), "_")}"
            if (!subjectsByCode.containsKey(subjectId)) {
                subjectsByCode[subjectId] = Subject(
                    id = subjectId,
                    code = code,
                    name = name,
                    professor = professor,
                    colorHex = colorHex,
                    defaultRoom = room,
                    defaultLab = lab,
                    defaultBuilding = building,
                    defaultFloor = floor
                )
            }

            val lectureType = runCatching { LectureType.valueOf(typeStr) }.getOrDefault(LectureType.LECTURE)
            val slotId = "slot_${subjectId}_d${dayOfWeek}_${startTime.replace(":", "")}"
            slots.add(
                TimetableSlot(
                    id = slotId,
                    subjectId = subjectId,
                    dayOfWeek = dayOfWeek,
                    startTime = startTime,
                    endTime = endTime,
                    roomNumber = room,
                    labNumber = lab,
                    building = building,
                    floor = floor,
                    professorOverride = professor,
                    lectureType = lectureType,
                    rotationPattern = RotationPattern.EVERY_WEEK
                )
            )
        }

        if (parseErrors.isNotEmpty()) {
            return ImportValidationReport(
                isValid = false,
                bundle = null,
                errors = parseErrors,
                warnings = emptyList(),
                duplicateSlotIds = emptyList(),
                duplicateSubjectIds = emptyList(),
                overlapWarnings = emptyList(),
                preservedAttendanceRecordsCount = 0
            )
        }

        val bundle = AcademicScheduleBundle(
            schemaVersion = 1,
            exportTimestampEpochMillis = System.currentTimeMillis(),
            subjects = subjectsByCode.values.toList(),
            timetableSlots = slots
        )
        return validateJsonImport(
            rawJson = exportToJson(bundle),
            mode = ImportMode.TIMETABLE_ONLY,
            existingSubjects = existingSubjects,
            existingSlots = existingSlots,
            existingInstances = existingInstances
        )
    }

    private fun parseDayName(input: String): Int = when (input.trim().lowercase().take(3)) {
        "mon" -> 1
        "tue" -> 2
        "wed" -> 3
        "thu" -> 4
        "fri" -> 5
        "sat" -> 6
        "sun" -> 7
        else -> -1
    }
}
