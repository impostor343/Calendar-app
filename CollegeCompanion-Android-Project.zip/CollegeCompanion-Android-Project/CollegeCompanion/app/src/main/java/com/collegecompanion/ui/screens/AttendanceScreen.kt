package com.collegecompanion.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.collegecompanion.domain.model.AttendanceStatus
import com.collegecompanion.domain.model.AttendanceWarningLevel
import com.collegecompanion.domain.model.ProjectedAttendanceResult
import com.collegecompanion.domain.model.ProjectionScenarioType
import com.collegecompanion.domain.model.SubjectAttendanceSummary
import com.collegecompanion.ui.theme.AttendanceAmber
import com.collegecompanion.ui.theme.AttendanceGreen
import com.collegecompanion.ui.theme.AttendanceRed
import com.collegecompanion.ui.theme.parseHexColor
import com.collegecompanion.ui.viewmodel.AppUiState
import com.collegecompanion.ui.viewmodel.MainViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AttendanceScreen(
    uiState: AppUiState,
    viewModel: MainViewModel
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Column(modifier = Modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = selectedTab, edgePadding = 16.dp) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Current Attendance") })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Projected Simulator") })
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("Pending (${uiState.pendingPastLectures.size})") }
            )
            Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("History & Undo") })
        }

        when (selectedTab) {
            0 -> CurrentAttendanceTab(uiState)
            1 -> ProjectedAttendanceTab(uiState, viewModel)
            2 -> PendingLecturesTab(uiState, viewModel)
            3 -> AttendanceHistoryTab(uiState, viewModel)
        }
    }
}

@Composable
private fun CurrentAttendanceTab(uiState: AppUiState) {
    val overall = uiState.overallAttendance ?: return
    val overallColor = warningColor(overall.warningLevel)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ElevatedCard(
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "OVERALL CURRENT ATTENDANCE (UP TO ${uiState.currentDate})",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${String.format("%.2f", overall.currentPercentage)}%",
                            style = MaterialTheme.typography.headlineLarge,
                            color = overallColor,
                            fontWeight = FontWeight.Bold
                        )
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Safe Absences: ${overall.overallSafeAbsences}",
                                style = MaterialTheme.typography.titleMedium,
                                color = overallColor,
                                fontWeight = FontWeight.Bold
                            )
                            if (overall.overallRecoveryLecturesNeeded > 0) {
                                Text(
                                    text = "Recovery Needed: +${overall.overallRecoveryLecturesNeeded} lectures",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AttendanceRed,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    LinearProgressIndicator(
                        progress = { (overall.currentPercentage.toFloat() / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp),
                        color = overallColor,
                        trackColor = overallColor.copy(alpha = 0.2f)
                    )

                    Text(
                        text = "Attended: ${overall.totalAttended}  •  Absent: ${overall.totalAbsent}  •  Finalized: ${overall.totalFinalized}  •  Pending: ${overall.totalPendingPast}  •  Future Excluded: ${overall.totalFutureScheduled}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            Text(
                text = "Subject Breakdown",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        items(overall.subjectSummaries, key = { it.subject.id }) { subSummary ->
            SubjectAttendanceCard(subSummary)
        }
    }
}

@Composable
private fun SubjectAttendanceCard(summary: SubjectAttendanceSummary) {
    val statusColor = warningColor(summary.warningLevel)
    val accent = parseHexColor(summary.subject.colorHex)

    ElevatedCard(
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.size(14.dp).background(accent, CircleShape))
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${summary.subject.name} (${summary.subject.code})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Required: ${summary.requiredPercentage.toInt()}% • Finalized: ${summary.totalFinalizedCount} lectures",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = "${String.format("%.2f", summary.currentPercentage)}%",
                    style = MaterialTheme.typography.headlineSmall,
                    color = statusColor,
                    fontWeight = FontWeight.Bold
                )
            }

            LinearProgressIndicator(
                progress = { (summary.currentPercentage.toFloat() / 100f).coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp),
                color = statusColor,
                trackColor = statusColor.copy(alpha = 0.18f)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Attended: ${summary.attendedCount} | Absent: ${summary.absentCount} | Pending: ${summary.pendingPastCount}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (summary.recoveryLecturesNeeded > 0) {
                    Text(
                        text = "Recover: +${summary.recoveryLecturesNeeded} consecutive",
                        style = MaterialTheme.typography.labelSmall,
                        color = AttendanceRed,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Text(
                        text = "Safe Absences: ${summary.safeAbsences}",
                        style = MaterialTheme.typography.labelSmall,
                        color = statusColor,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ProjectedAttendanceTab(
    uiState: AppUiState,
    viewModel: MainViewModel
) {
    val cfg = uiState.projectionConfig
    val overallProj = uiState.overallProjection

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ElevatedCard(
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "PROJECTED ATTENDANCE SIMULATOR",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Simulates future outcomes without altering actual attendance.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        OutlinedButton(onClick = { viewModel.resetProjectionToDefault() }) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Reset")
                        }
                    }

                    Text("Select Projection Scenario:", style = MaterialTheme.typography.labelLarge)

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ProjectionScenarioType.entries.forEach { scenario ->
                            FilterChip(
                                selected = cfg.scenario == scenario,
                                onClick = { viewModel.updateProjectionScenario(scenario) },
                                label = { Text(scenario.title) }
                            )
                        }
                    }

                    if (cfg.scenario == ProjectionScenarioType.MISS_CUSTOM_COUNT ||
                        cfg.scenario == ProjectionScenarioType.ATTEND_SELECTED_COUNT
                    ) {
                        val maxFuture = uiState.futureLectures.size.coerceAtLeast(1)
                        Column {
                            Text(
                                text = if (cfg.scenario == ProjectionScenarioType.MISS_CUSTOM_COUNT) {
                                    "Custom Upcoming Lectures to Miss: ${cfg.customCount}"
                                } else {
                                    "Selected Future Lectures to Attend: ${cfg.customCount} (Miss remaining)"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Slider(
                                value = cfg.customCount.toFloat().coerceIn(0f, maxFuture.toFloat()),
                                onValueChange = {
                                    viewModel.updateProjectionScenario(cfg.scenario, customCount = it.toInt())
                                },
                                valueRange = 0f..maxFuture.toFloat()
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Immediate Horizon Only (Project right after next N lectures)",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f)
                        )
                        Switch(
                            checked = cfg.evaluateImmediateHorizonOnly,
                            onCheckedChange = {
                                viewModel.updateProjectionScenario(
                                    scenario = cfg.scenario,
                                    evaluateImmediateHorizonOnly = it
                                )
                            }
                        )
                    }
                }
            }
        }

        // Overall Projection Comparison Card
        overallProj?.let { proj ->
            item {
                ProjectionComparisonCard(proj = proj, isOverall = true)
            }
        }

        // Per-Subject Projection Comparison Cards
        item {
            Text(
                text = "Subject Projections (Actual vs Projected)",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        items(uiState.subjectProjections, key = { it.subjectId ?: it.label }) { subProj ->
            ProjectionComparisonCard(proj = subProj, isOverall = false)
        }

        // Scenario 6 Specific Future Lecture Picker
        if (cfg.scenario == ProjectionScenarioType.SELECT_SPECIFIC_FUTURE) {
            item {
                Text(
                    text = "Tap Future Lectures to Toggle Miss / Attend (${uiState.futureLectures.size} scheduled)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            items(uiState.futureLectures.take(40), key = { it.id }) { futureLecture ->
                val isMarkedMissed = cfg.specificMissedIds.contains(futureLecture.id)
                ElevatedCard(
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${futureLecture.date} • ${futureLecture.startTime}-${futureLecture.endTime}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = futureLecture.subjectName,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (isMarkedMissed) "PROJECTED MISS" else "PROJECTED ATTEND",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isMarkedMissed) AttendanceRed else AttendanceGreen,
                                fontWeight = FontWeight.Bold
                            )
                            Checkbox(
                                checked = isMarkedMissed,
                                onCheckedChange = { viewModel.toggleSpecificFutureLectureMiss(futureLecture.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProjectionComparisonCard(
    proj: ProjectedAttendanceResult,
    isOverall: Boolean
) {
    val projColor = warningColor(proj.warningLevel)

    ElevatedCard(
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = proj.label,
                style = if (isOverall) MaterialTheme.typography.titleLarge else MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("CURRENT (ACTUAL)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = "${String.format("%.2f", proj.currentPercentage)}%",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text("Safe Absences: ${proj.currentSafeAbsences}", style = MaterialTheme.typography.bodySmall)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("PROJECTED ESTIMATE", style = MaterialTheme.typography.labelSmall, color = projColor)
                    Text(
                        text = "${String.format("%.2f", proj.projectedPercentage)}%",
                        style = MaterialTheme.typography.headlineSmall,
                        color = projColor,
                        fontWeight = FontWeight.Bold
                    )
                    Text("Projected Safe: ${proj.projectedSafeAbsences}", style = MaterialTheme.typography.bodySmall)
                }
            }

            Text(
                text = "Future Scheduled: ${proj.futureTotalScheduled}  •  Projected Attend (F): ${proj.futureProjectedAttended}  •  Projected Miss (M): ${proj.futureProjectedMissed}  •  Required: ${proj.requiredPercentage.toInt()}%",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (proj.dropsBelowThreshold) {
                Surface(
                    color = AttendanceRed.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = AttendanceRed, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Warning: This scenario causes ${proj.label} attendance to fall below ${proj.requiredPercentage.toInt()}%!",
                            style = MaterialTheme.typography.bodySmall,
                            color = AttendanceRed,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PendingLecturesTab(
    uiState: AppUiState,
    viewModel: MainViewModel
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "Unmarked Past & Today Lectures (${uiState.pendingPastLectures.size})",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Pending lectures are excluded from Current Attendance until you mark them Attended or Absent.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        items(uiState.pendingPastLectures, key = { it.id }) { lecture ->
            ElevatedCard(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${lecture.date} • ${lecture.startTime}-${lecture.endTime}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${lecture.subjectName} (${lecture.subjectCode})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = lecture.formattedLocation(),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Button(
                        onClick = { viewModel.markAttendance(lecture.id, AttendanceStatus.ATTENDED, "PENDING_QUEUE") },
                        colors = ButtonDefaults.buttonColors(containerColor = AttendanceGreen)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = "Attended", modifier = Modifier.size(16.dp))
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = { viewModel.markAttendance(lecture.id, AttendanceStatus.ABSENT, "PENDING_QUEUE") },
                        colors = ButtonDefaults.buttonColors(containerColor = AttendanceRed)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Absent", modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun AttendanceHistoryTab(
    uiState: AppUiState,
    viewModel: MainViewModel
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (uiState.bulkOperations.isNotEmpty()) {
            item {
                Text(
                    text = "Bulk Absence Operations (Transactional Undo)",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
            items(uiState.bulkOperations, key = { it.operationId }) { bulkOp ->
                ElevatedCard(
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Complete-Day Absence on ${bulkOp.targetDate}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${bulkOp.affectedLectures.size} lecture(s) affected • Status: ${if (bulkOp.wasUndone) "Undone" else "Active"}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (!bulkOp.wasUndone) {
                            OutlinedButton(onClick = { viewModel.undoBulkOperation(bulkOp.operationId) }) {
                                Icon(Icons.Default.Undo, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("UNDO")
                            }
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "Recent Attendance Audit Log (${uiState.auditLogs.size})",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        items(uiState.auditLogs, key = { it.id }) { log ->
            ElevatedCard(
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${log.subjectName} (${log.lectureDate} at ${log.startTime})",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${log.previousStatus.displayName} → ${log.newStatus.displayName} • via ${log.source}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    OutlinedButton(
                        onClick = {
                            viewModel.markAttendance(log.lectureInstanceId, log.previousStatus, "AUDIT_UNDO")
                        }
                    ) {
                        Text("Revert")
                    }
                }
            }
        }
    }
}

private fun warningColor(level: AttendanceWarningLevel): Color = when (level) {
    AttendanceWarningLevel.CRITICAL -> AttendanceRed
    AttendanceWarningLevel.WARNING -> AttendanceAmber
    AttendanceWarningLevel.COMFORTABLE -> AttendanceGreen
    AttendanceWarningLevel.NEUTRAL -> Color(0xFF2563EB)
}
