package com.collegecompanion.ui.theme

import androidx.compose.ui.graphics.Color

val CalendarBluePrimary = Color(0xFF1A73E8)
val CalendarTealSecondary = Color(0xFF00897B)

val AttendanceGreen = Color(0xFF16A34A)
val AttendanceGreenSoft = Color(0xFFDCFCE7)
val AttendanceAmber = Color(0xFFD97706)
val AttendanceAmberSoft = Color(0xFFFEF3C7)
val AttendanceRed = Color(0xFFDC2626)
val AttendanceRedSoft = Color(0xFFFEE2E2)
val AttendanceGrey = Color(0xFF64748B)

val SubjectPalettePresets = listOf(
    "#1A73E8", // Google Blue
    "#00897B", // Teal
    "#E65100", // Deep Orange
    "#8E24AA", // Purple
    "#2E7D32", // Forest Green
    "#C62828", // Crimson
    "#1565C0", // Cobalt
    "#AD1457", // Berry
    "#4527A0", // Indigo
    "#00838F"  // Cyan
)

fun parseHexColor(hex: String, fallback: Color = CalendarBluePrimary): Color {
    return try {
        val cleaned = hex.trim().removePrefix("#")
        val value = when (cleaned.length) {
            6 -> "FF$cleaned".toLong(16)
            8 -> cleaned.toLong(16)
            else -> return fallback
        }
        Color(value)
    } catch (_: Exception) {
        fallback
    }
}
