package com.collegecompanion.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.collegecompanion.data.local.entity.AcademicCalendarEventEntity
import com.collegecompanion.data.local.entity.AttendanceAuditLogEntity
import com.collegecompanion.data.local.entity.BulkAbsenceOperationEntity
import com.collegecompanion.data.local.entity.LectureInstanceEntity
import com.collegecompanion.data.local.entity.SubjectEntity
import com.collegecompanion.data.local.entity.TimetableSlotEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SubjectDao {
    @Query("SELECT * FROM subjects ORDER BY name ASC")
    fun observeAllSubjects(): Flow<List<SubjectEntity>>

    @Query("SELECT * FROM subjects ORDER BY name ASC")
    suspend fun getAllSubjects(): List<SubjectEntity>

    @Query("SELECT * FROM subjects WHERE id = :id LIMIT 1")
    suspend fun getSubjectById(id: String): SubjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSubject(subject: SubjectEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSubjects(subjects: List<SubjectEntity>)

    @Query("DELETE FROM subjects WHERE id = :id")
    suspend fun deleteSubjectById(id: String)

    @Query("DELETE FROM subjects")
    suspend fun deleteAllSubjects()
}

@Dao
interface TimetableSlotDao {
    @Query("SELECT * FROM timetable_slots ORDER BY dayOfWeek ASC, startTime ASC")
    fun observeAllSlots(): Flow<List<TimetableSlotEntity>>

    @Query("SELECT * FROM timetable_slots ORDER BY dayOfWeek ASC, startTime ASC")
    suspend fun getAllSlots(): List<TimetableSlotEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSlot(slot: TimetableSlotEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSlots(slots: List<TimetableSlotEntity>)

    @Query("DELETE FROM timetable_slots WHERE id = :slotId")
    suspend fun deleteSlotById(slotId: String)

    @Query("DELETE FROM timetable_slots")
    suspend fun deleteAllSlots()
}

@Dao
interface LectureInstanceDao {
    @Query("SELECT * FROM lecture_instances ORDER BY date ASC, startTime ASC")
    fun observeAllInstances(): Flow<List<LectureInstanceEntity>>

    @Query("SELECT * FROM lecture_instances ORDER BY date ASC, startTime ASC")
    suspend fun getAllInstances(): List<LectureInstanceEntity>

    @Query("SELECT * FROM lecture_instances WHERE date = :date ORDER BY startTime ASC")
    fun observeInstancesForDate(date: String): Flow<List<LectureInstanceEntity>>

    @Query("SELECT * FROM lecture_instances WHERE date = :date ORDER BY startTime ASC")
    suspend fun getInstancesForDate(date: String): List<LectureInstanceEntity>

    @Query("SELECT * FROM lecture_instances WHERE id = :instanceId LIMIT 1")
    suspend fun getInstanceById(instanceId: String): LectureInstanceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertInstance(instance: LectureInstanceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertInstances(instances: List<LectureInstanceEntity>)

    @Query("DELETE FROM lecture_instances WHERE id = :instanceId")
    suspend fun deleteInstanceById(instanceId: String)

    @Query("DELETE FROM lecture_instances WHERE date >= :fromDate AND attendanceStatus = 'PENDING' AND isOneTimeOrExtra = 0 AND isRescheduled = 0")
    suspend fun deletePendingGeneratedInstancesFrom(fromDate: String)

    @Query("DELETE FROM lecture_instances")
    suspend fun deleteAllInstances()
}

@Dao
interface CalendarEventDao {
    @Query("SELECT * FROM calendar_events ORDER BY startDate ASC")
    fun observeAllEvents(): Flow<List<AcademicCalendarEventEntity>>

    @Query("SELECT * FROM calendar_events ORDER BY startDate ASC")
    suspend fun getAllEvents(): List<AcademicCalendarEventEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEvent(event: AcademicCalendarEventEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEvents(events: List<AcademicCalendarEventEntity>)

    @Query("DELETE FROM calendar_events WHERE id = :eventId")
    suspend fun deleteEventById(eventId: String)

    @Query("DELETE FROM calendar_events")
    suspend fun deleteAllEvents()
}

@Dao
interface AttendanceAuditDao {
    @Query("SELECT * FROM attendance_audit_log ORDER BY timestampEpochMillis DESC LIMIT 250")
    fun observeRecentAuditLogs(): Flow<List<AttendanceAuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(entry: AttendanceAuditLogEntity)

    @Query("SELECT * FROM bulk_absence_operations ORDER BY timestampEpochMillis DESC")
    fun observeBulkOperations(): Flow<List<BulkAbsenceOperationEntity>>

    @Query("SELECT * FROM bulk_absence_operations ORDER BY timestampEpochMillis DESC")
    suspend fun getAllBulkOperations(): List<BulkAbsenceOperationEntity>

    @Query("SELECT * FROM bulk_absence_operations WHERE operationId = :operationId LIMIT 1")
    suspend fun getBulkOperationById(operationId: String): BulkAbsenceOperationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBulkOperation(operation: BulkAbsenceOperationEntity)

    @Query("DELETE FROM bulk_absence_operations")
    suspend fun deleteAllBulkOperations()
}
