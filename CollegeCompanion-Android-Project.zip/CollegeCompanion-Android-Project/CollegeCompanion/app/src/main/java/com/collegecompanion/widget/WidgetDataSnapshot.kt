package com.collegecompanion.widget

import android.content.Context
import com.collegecompanion.data.local.CollegeCompanionDatabase
import com.collegecompanion.data.preferences.PreferencesDataStore
import com.collegecompanion.domain.engine.AttendanceEngine
import com.collegecompanion.domain.engine.ProjectedAttendanceEngine
import com.collegecompanion.domain.engine.TimetableGenerator
import com.collegecompanion.domain.model.AcademicCalendarConfig
import com.collegecompanion.domain.model.AttendanceWarningLevel
import com.collegecompanion.domain.model.LectureInstance
import com.collegecompanion.domain.model.OverallAttendanceSummary
import com.collegecompanion.domain.model.ProjectedAttendanceResult
import com.collegecompanion.domain.model.ProjectionScenarioType
import com.collegecompanion.domain.model.WidgetThemeOption
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

data class WidgetDataSnapshot(
    val currentDate: LocalDate,
    val dayOfWeekShort: String,
    val dayOfMonthNumber: String,
    val fullFormattedDate: String,
    val todayLectures: List<LectureInstance>,
    val isHolidayToday: Boolean,
    val holidayTitle: String?,
    val overallAttendance: OverallAttendanceSummary,
    val projectedAttendance: ProjectedAttendanceResult,
    val widgetTheme: WidgetThemeOption
)

object WidgetSnapshotLoader {

    suspend fun loadSnapshot(context: Context, now: LocalDate = LocalDate.now()): WidgetDataSnapshot {
        val db = CollegeCompanionDatabase.getInstance(context)
        val prefsStore = PreferencesDataStore(context)
        val prefs = prefsStore.getPreferencesSnapshot()

        val subjects = db.subjectDao().getAllSubjects().map { it.toDomain() }
        val allInstances = db.lectureInstanceDao().getAllInstances().map { it.toDomain() }
        val events = db.calendarEventDao().getAllEvents().map { it.toDomain() }

        val calendarConfig = AcademicCalendarConfig(
            semesterName = prefs.semesterName,
            semesterStartDate = prefs.semesterStartDate,
            semesterEndDate = prefs.semesterEndDate,
            workingDaysOfWeek = prefs.workingDaysOfWeek
        )
        val holidayDates = TimetableGenerator.extractHolidayAndNoClassDates(calendarConfig, events)
        val semesterStart = runCatching { LocalDate.parse(prefs.semesterStartDate) }.getOrDefault(now.minusMonths(3))
        val semesterEnd = runCatching { LocalDate.parse(prefs.semesterEndDate) }.getOrDefault(now.plusMonths(3))

        val todayStr = now.toString()
        val todayLectures = allInstances
            .filter { it.date == todayStr }
            .sortedBy { it.startTime }

        val todayHolidayEvent = events.firstOrNull { ev ->
            TimetableGenerator.isDateWithinEvent(now, ev) && holidayDates.contains(now)
        }

        val overallAttendance = AttendanceEngine.calculateOverallAttendance(
            subjects = subjects,
            instances = allInstances,
            semesterStartDate = semesterStart,
            semesterEndDate = semesterEnd,
            currentDate = now,
            holidayDates = holidayDates,
            globalRequiredPercentage = prefs.globalRequiredAttendance,
            globalWarningPercentage = prefs.warningThresholdAttendance
        )

        val projectedAttendance = ProjectedAttendanceEngine.simulateOverallProjection(
            subjects = subjects,
            allInstances = allInstances,
            currentDate = now,
            semesterStartDate = semesterStart,
            semesterEndDate = semesterEnd,
            holidayDates = holidayDates,
            scenario = ProjectionScenarioType.ATTEND_ALL,
            globalRequiredPercentage = prefs.globalRequiredAttendance,
            globalWarningPercentage = prefs.warningThresholdAttendance
        )

        return WidgetDataSnapshot(
            currentDate = now,
            dayOfWeekShort = now.format(DateTimeFormatter.ofPattern("EEE", Locale.ENGLISH)).uppercase(),
            dayOfMonthNumber = now.dayOfMonth.toString(),
            fullFormattedDate = now.format(DateTimeFormatter.ofPattern("EEEE, d MMM yyyy", Locale.ENGLISH)),
            todayLectures = todayLectures,
            isHolidayToday = holidayDates.contains(now),
            holidayTitle = todayHolidayEvent?.title,
            overallAttendance = overallAttendance,
            projectedAttendance = projectedAttendance,
            widgetTheme = prefs.widgetTheme
        )
    }
}
