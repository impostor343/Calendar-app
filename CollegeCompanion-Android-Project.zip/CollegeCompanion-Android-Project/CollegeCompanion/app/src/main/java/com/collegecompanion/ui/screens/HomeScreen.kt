package com.collegecompanion.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.collegecompanion.data.repository.CompleteDayAbsentPreview
import com.collegecompanion.domain.model.AttendanceStatus
import com.collegecompanion.domain.model.AttendanceWarningLevel
import com.collegecompanion.domain.model.LectureInstance
import com.collegecompanion.domain.model.LiveLecturePhase
import com.collegecompanion.ui.theme.AttendanceAmber
import com.collegecompanion.ui.theme.AttendanceGreen
import com.collegecompanion.ui.theme.AttendanceGrey
import com.collegecompanion.ui.theme.AttendanceRed
import com.collegecompanion.ui.theme.parseHexColor
import com.collegecompanion.ui.viewmodel.AppUiState
import com.collegecompanion.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun HomeScreen(
    uiState: AppUiState,
    viewModel: MainViewModel
) {
    val scope = rememberCoroutineScope()
    var completeAbsentDialogPreview by remember { mutableStateOf<CompleteDayAbsentPreview?>(null) }

    val formattedWeekday = uiState.currentDate.format(DateTimeFormatter.ofPattern("EEEE", Locale.ENGLISH))
    val formattedFullDate = uiState.currentDate.format(DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.ENGLISH))

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Status Banner if present
        uiState.statusBannerMessage?.let { msg ->
            item {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = msg,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { viewModel.clearBanner() }) {
                            Text("DISMISS")
                        }
                    }
                }
            }
        }

        // Top Date & Weekday Header + COMPLETE ABSENT action
        item {
            ElevatedCard(
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = uiState.preferences.semesterName.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = formattedWeekday,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = formattedFullDate,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (!uiState.isHolidayToday && uiState.todayLectures.isNotEmpty()) {
                        Button(
                            onClick = {
                                scope.launch {
                                    completeAbsentDialogPreview = viewModel.previewCompleteDayAbsent(uiState.currentDate)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AttendanceRed,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.EventBusy,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("COMPLETE ABSENT", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }

        // Current Attendance & Safe Absences Dashboard Card
        uiState.overallAttendance?.let { att ->
            item {
                val badgeColor = when (att.warningLevel) {
                    AttendanceWarningLevel.CRITICAL -> AttendanceRed
                    AttendanceWarningLevel.WARNING -> AttendanceAmber
                    AttendanceWarningLevel.COMFORTABLE -> AttendanceGreen
                    AttendanceWarningLevel.NEUTRAL -> MaterialTheme.colorScheme.primary
                }

                ElevatedCard(
                    shape = RoundedCornerShape(22.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "CURRENT ATTENDANCE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "${String.format("%.2f", att.currentPercentage)}%",
                                    style = MaterialTheme.typography.headlineLarge,
                                    color = badgeColor,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Surface(
                                color = badgeColor.copy(alpha = 0.14f),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                    horizontalAlignment = Alignment.End
                                ) {
                                    Text(
                                        text = "Safe Absences: ${att.overallSafeAbsences}",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = badgeColor,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Required: ${att.globalRequiredPercentage.toInt()}%",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            StatPill("Attended", att.totalAttended.toString(), AttendanceGreen, Modifier.weight(1f))
                            StatPill("Absent", att.totalAbsent.toString(), AttendanceRed, Modifier.weight(1f))
                            StatPill("Pending", att.totalPendingPast.toString(), AttendanceAmber, Modifier.weight(1f))
                        }

                        if (att.warningLevel == AttendanceWarningLevel.CRITICAL || att.subjectsBelowThresholdCount > 0) {
                            Surface(
                                color = AttendanceRed.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = "Attendance Warning",
                                        tint = AttendanceRed
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    val warningMsg = if (att.overallRecoveryLecturesNeeded > 0) {
                                        "Overall attendance is below ${att.globalRequiredPercentage.toInt()}%. Attend next ${att.overallRecoveryLecturesNeeded} consecutive lecture(s) to recover."
                                    } else {
                                        "${att.subjectsBelowThresholdCount} subject(s) are currently below their required attendance threshold."
                                    }
                                    Text(
                                        text = warningMsg,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = AttendanceRed,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Next Lecture & Upcoming Countdown Spotlight
        uiState.nextLectureCountdown?.let { nextInfo ->
            item {
                val accent = parseHexColor(nextInfo.lecture.subjectColorHex)
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = accent.copy(alpha = 0.12f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AccessTime,
                                    contentDescription = null,
                                    tint = accent,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "NEXT LECTURE • ${nextInfo.formattedCountdown.uppercase()}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = accent,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${nextInfo.lecture.subjectName} (${nextInfo.lecture.subjectCode})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${nextInfo.lecture.startTime} - ${nextInfo.lecture.endTime} • ${nextInfo.lecture.formattedLocation()}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Today's Lectures Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Today's Lectures (${uiState.todayLectures.size})",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Today's Lectures or "Nothing scheduled"
        if (uiState.isHolidayToday) {
            item {
                ElevatedCard(
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = uiState.todayHolidayTitle ?: "Academic Holiday",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Nothing scheduled",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else if (uiState.todayLectures.isEmpty()) {
            item {
                ElevatedCard(
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Nothing scheduled",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(uiState.todayLectures, key = { it.id }) { lecture ->
                HomeLectureCard(
                    lecture = lecture,
                    currentDate = uiState.currentDate,
                    currentTime = uiState.currentTime,
                    onMarkStatus = { newStatus ->
                        viewModel.markAttendance(lecture.id, newStatus, "HOME_SCREEN")
                    }
                )
            }
        }
    }

    // Complete-Day Absence Confirmation Dialog
    completeAbsentDialogPreview?.let { preview ->
        AlertDialog(
            onDismissRequest = { completeAbsentDialogPreview = null },
            title = { Text("Confirm Complete-Day Absence") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!preview.canProceed) {
                        Text(
                            text = preview.blockingReason ?: "No applicable lectures.",
                            color = MaterialTheme.colorScheme.error
                        )
                    } else {
                        Text("Mark all ${preview.applicableLectures.size} applicable lecture(s) on ${preview.date} as ABSENT?")
                        if (preview.previouslyAttendedLectures.isNotEmpty()) {
                            Surface(
                                color = AttendanceAmber.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = "Warning: ${preview.previouslyAttendedLectures.size} lecture(s) currently marked ATTENDED will be changed to ABSENT.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AttendanceRed,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }
                        preview.applicableLectures.forEach { lec ->
                            Text(
                                text = "• ${lec.startTime}-${lec.endTime}: ${lec.subjectName} (${lec.attendanceStatus.displayName})",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            },
            confirmButton = {
                if (preview.canProceed) {
                    Button(
                        onClick = {
                            viewModel.executeCompleteDayAbsent(uiState.currentDate)
                            completeAbsentDialogPreview = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AttendanceRed)
                    ) {
                        Text("CONFIRM ABSENT")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { completeAbsentDialogPreview = null }) {
                    Text("CANCEL")
                }
            }
        )
    }
}

@Composable
private fun StatPill(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = color.copy(alpha = 0.10f),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                color = color,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun HomeLectureCard(
    lecture: LectureInstance,
    currentDate: java.time.LocalDate,
    currentTime: java.time.LocalTime,
    onMarkStatus: (AttendanceStatus) -> Unit
) {
    val subjectColor = parseHexColor(lecture.subjectColorHex)
    val livePhase = lecture.resolveLivePhase(currentDate, currentTime)

    val phaseColor = when (livePhase) {
        LiveLecturePhase.ATTENDED -> AttendanceGreen
        LiveLecturePhase.ABSENT -> AttendanceRed
        LiveLecturePhase.CANCELLED -> AttendanceGrey
        LiveLecturePhase.ONGOING -> Color(0xFF2563EB)
        LiveLecturePhase.UPCOMING -> AttendanceAmber
        LiveLecturePhase.COMPLETED -> Color(0xFF475569)
    }

    ElevatedCard(
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .background(subjectColor, CircleShape)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${lecture.subjectName} (${lecture.subjectCode})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${lecture.startTime} – ${lecture.endTime} • ${lecture.lectureType.displayName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    color = phaseColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = livePhase.label.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = phaseColor,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            // Room, Lab, Building, Floor & Professor details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        modifier = Modifier.size(15.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = lecture.formattedLocation(),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (lecture.professor.isNotBlank()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            modifier = Modifier.size(15.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = lecture.professor,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Attendance Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val isAttended = lecture.attendanceStatus == AttendanceStatus.ATTENDED
                val isAbsent = lecture.attendanceStatus == AttendanceStatus.ABSENT
                val isCancelled = lecture.attendanceStatus == AttendanceStatus.CANCELLED

                Button(
                    onClick = { onMarkStatus(AttendanceStatus.ATTENDED) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isAttended) AttendanceGreen else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (isAttended) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ATTENDED", style = MaterialTheme.typography.labelSmall)
                }

                Button(
                    onClick = { onMarkStatus(AttendanceStatus.ABSENT) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isAbsent) AttendanceRed else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (isAbsent) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ABSENT", style = MaterialTheme.typography.labelSmall)
                }

                IconButton(
                    onClick = {
                        val next = if (isCancelled) AttendanceStatus.PENDING else AttendanceStatus.CANCELLED
                        onMarkStatus(next)
                    }
                ) {
                    Icon(
                        imageVector = if (isCancelled) Icons.Default.Refresh else Icons.Default.Block,
                        contentDescription = "Toggle Cancelled",
                        tint = if (isCancelled) AttendanceAmber else AttendanceGrey
                    )
                }
            }
        }
    }
}
