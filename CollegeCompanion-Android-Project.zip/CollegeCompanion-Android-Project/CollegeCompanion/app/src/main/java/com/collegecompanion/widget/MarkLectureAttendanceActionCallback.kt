package com.collegecompanion.widget

import android.content.Context
import androidx.glance.GlanceId
import androidx.glance.action.ActionParameters
import androidx.glance.appwidget.action.ActionCallback
import com.collegecompanion.data.local.CollegeCompanionDatabase
import com.collegecompanion.data.preferences.PreferencesDataStore
import com.collegecompanion.data.repository.CollegeRepository
import com.collegecompanion.domain.model.AttendanceStatus

/**
 * Genuine Jetpack Glance ActionCallback that marks a lecture instance ATTENDED or ABSENT
 * directly from any home-screen widget without launching the main application UI.
 */
class MarkLectureAttendanceActionCallback : ActionCallback {

    companion object {
        val KEY_LECTURE_INSTANCE_ID = ActionParameters.Key<String>("lecture_instance_id")
        val KEY_TARGET_STATUS = ActionParameters.Key<String>("target_status")
    }

    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: ActionParameters
    ) {
        val instanceId = parameters[KEY_LECTURE_INSTANCE_ID] ?: return
        val statusName = parameters[KEY_TARGET_STATUS] ?: return
        val targetStatus = runCatching { AttendanceStatus.valueOf(statusName) }.getOrNull() ?: return

        val database = CollegeCompanionDatabase.getInstance(context)
        val prefs = PreferencesDataStore(context)
        val repository = CollegeRepository(context.applicationContext, database, prefs)

        // Transactional update in Room + refreshes all widgets + updates notifications
        repository.markLectureAttendance(
            lectureInstanceId = instanceId,
            newStatus = targetStatus,
            source = "WIDGET"
        )
    }
}
