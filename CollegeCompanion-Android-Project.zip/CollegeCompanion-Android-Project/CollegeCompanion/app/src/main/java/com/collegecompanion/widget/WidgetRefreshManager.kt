package com.collegecompanion.widget

import android.content.Context
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Coordinates immediate updates across all instances of Widget A, Widget B, and Widget C.
 */
object WidgetRefreshManager {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    suspend fun refreshAllWidgets(context: Context) {
        val appContext = context.applicationContext
        runCatching { TodayTimetableWidget().updateAll(appContext) }
        runCatching { AttendanceOverviewWidget().updateAll(appContext) }
        runCatching { CombinedCompanionWidget().updateAll(appContext) }
    }

    fun triggerAsyncRefresh(context: Context) {
        val appContext = context.applicationContext
        scope.launch {
            refreshAllWidgets(appContext)
        }
    }
}
