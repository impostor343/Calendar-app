package com.collegecompanion.notification

import android.Manifest
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.collegecompanion.MainActivity

/**
 * BroadcastReceiver that posts the rich lecture reminder notification (Part 9).
 * Displays Subject name, Lecture time, Classroom/Lab, Building, Floor, and Professor.
 */
class LectureReminderReceiver : BroadcastReceiver() {

    companion object {
        const val EXTRA_INSTANCE_ID = "extra_instance_id"
        const val EXTRA_SUBJECT_NAME = "extra_subject_name"
        const val EXTRA_START_TIME = "extra_start_time"
        const val EXTRA_END_TIME = "extra_end_time"
        const val EXTRA_ROOM = "extra_room"
        const val EXTRA_LAB = "extra_lab"
        const val EXTRA_BUILDING = "extra_building"
        const val EXTRA_FLOOR = "extra_floor"
        const val EXTRA_PROFESSOR = "extra_professor"
        const val EXTRA_MINUTES_BEFORE = "extra_minutes_before"
        const val EXTRA_SOUND_ENABLED = "extra_sound_enabled"
        const val EXTRA_VIBRATION_ENABLED = "extra_vibration_enabled"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != LectureReminderScheduler.ACTION_SHOW_LECTURE_REMINDER) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }

        LectureReminderScheduler.ensureNotificationChannel(context)

        val instanceId = intent.getStringExtra(EXTRA_INSTANCE_ID) ?: return
        val subjectName = intent.getStringExtra(EXTRA_SUBJECT_NAME) ?: "Upcoming Lecture"
        val startTime = intent.getStringExtra(EXTRA_START_TIME) ?: ""
        val endTime = intent.getStringExtra(EXTRA_END_TIME) ?: ""
        val room = intent.getStringExtra(EXTRA_ROOM) ?: ""
        val lab = intent.getStringExtra(EXTRA_LAB) ?: ""
        val building = intent.getStringExtra(EXTRA_BUILDING) ?: ""
        val floor = intent.getStringExtra(EXTRA_FLOOR) ?: ""
        val professor = intent.getStringExtra(EXTRA_PROFESSOR) ?: ""
        val minutesBefore = intent.getIntExtra(EXTRA_MINUTES_BEFORE, 15)
        val soundEnabled = intent.getBooleanExtra(EXTRA_SOUND_ENABLED, true)
        val vibrationEnabled = intent.getBooleanExtra(EXTRA_VIBRATION_ENABLED, true)

        val locationParts = mutableListOf<String>()
        if (room.isNotBlank()) locationParts.add("Room $room")
        if (lab.isNotBlank()) locationParts.add("Lab $lab")
        if (building.isNotBlank()) locationParts.add(building)
        if (floor.isNotBlank()) locationParts.add("Floor $floor")
        val locationLine = if (locationParts.isEmpty()) "Room TBD" else locationParts.joinToString(" • ")

        val contentTitle = "$subjectName in $minutesBefore min ($startTime)"
        val detailLines = buildString {
            append("Time: $startTime - $endTime
")
            append("Location: $locationLine")
            if (professor.isNotBlank()) {
                append("
Professor: $professor")
            }
        }

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context,
            instanceId.hashCode(),
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, LectureReminderScheduler.CHANNEL_ID_REMINDERS)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(contentTitle)
            .setContentText("$locationLine${if (professor.isNotBlank()) " • $professor" else ""}")
            .setStyle(NotificationCompat.BigTextStyle().bigText(detailLines))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(contentPendingIntent)

        if (!soundEnabled) {
            builder.setSilent(true)
        }
        if (vibrationEnabled) {
            builder.setVibrate(longArrayOf(0L, 250L, 150L, 250L))
        }

        val notificationId = LectureReminderScheduler.computeRequestCode(instanceId, minutesBefore)
        runCatching {
            NotificationManagerCompat.from(context).notify(notificationId, builder.build())
        }
    }
}
