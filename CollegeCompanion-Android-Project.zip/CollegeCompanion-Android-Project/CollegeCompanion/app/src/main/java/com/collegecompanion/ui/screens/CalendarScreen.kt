package com.collegecompanion.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.collegecompanion.domain.engine.TimetableGenerator
import com.collegecompanion.domain.model.AcademicCalendarEvent
import com.collegecompanion.domain.model.CalendarEventType
import com.collegecompanion.ui.theme.AttendanceAmber
import com.collegecompanion.ui.theme.AttendanceGreen
import com.collegecompanion.ui.theme.AttendanceRed
import com.collegecompanion.ui.theme.parseHexColor
import com.collegecompanion.ui.viewmodel.AppUiState
import com.collegecompanion.ui.viewmodel.MainViewModel
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CalendarScreen(
    uiState: AppUiState,
    viewModel: MainViewModel
) {
    var viewMode by remember { mutableIntStateOf(0) } // 0 = Monthly, 1 = Weekly, 2 = Daily
    var selectedDate by remember { mutableStateOf(uiState.currentDate) }
    var displayedYearMonth by remember { mutableStateOf(YearMonth.from(uiState.currentDate)) }
    var showAddEventDialog by remember { mutableStateOf(false) }

    val instancesByDate = remember(uiState.allInstances) {
        uiState.allInstances.groupBy { it.date }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = viewMode, edgePadding = 16.dp) {
            Tab(selected = viewMode == 0, onClick = { viewMode = 0 }, text = { Text("Monthly View") })
            Tab(selected = viewMode == 1, onClick = { viewMode = 1 }, text = { Text("Weekly View") })
            Tab(selected = viewMode == 2, onClick = { viewMode = 2 }, text = { Text("Daily View") })
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Month Navigation Bar
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { displayedYearMonth = displayedYearMonth.minusMonths(1) }) {
                        Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Month")
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = displayedYearMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        TextButton(onClick = {
                            selectedDate = uiState.currentDate
                            displayedYearMonth = YearMonth.from(uiState.currentDate)
                        }) {
                            Text("Jump to Today (${uiState.currentDate})")
                        }
                    }
                    IconButton(onClick = { displayedYearMonth = displayedYearMonth.plusMonths(1) }) {
                        Icon(Icons.Default.ChevronRight, contentDescription = "Next Month")
                    }
                }
            }

            if (viewMode == 0) {
                // Monthly Calendar Grid
                item {
                    MonthlyCalendarGrid(
                        yearMonth = displayedYearMonth,
                        selectedDate = selectedDate,
                        holidayDates = uiState.holidayDates,
                        instancesByDate = instancesByDate,
                        onSelectDate = { date -> selectedDate = date }
                    )
                }
            } else if (viewMode == 1) {
                // Weekly Strip View
                item {
                    val startOfWeek = selectedDate.minusDays((selectedDate.dayOfWeek.value - 1).toLong())
                    ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            for (i in 0..6) {
                                val dayDate = startOfWeek.plusDays(i.toLong())
                                val isSelected = dayDate == selectedDate
                                Surface(
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.clickable { selectedDate = dayDate }
                                ) {
                                    Column(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = dayDate.dayOfWeek.name.take(3),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = dayDate.dayOfMonth.toString(),
                                            style = MaterialTheme.typography.titleMedium,
                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Selected Date Details Header + Add Event Button
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = selectedDate.format(DateTimeFormatter.ofPattern("EEE, MMM d, yyyy", Locale.ENGLISH)),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Button(onClick = { showAddEventDialog = true }) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Calendar Event")
                    }
                }
            }

            // Academic Events on Selected Date
            val matchingEvents = uiState.calendarEvents.filter { ev ->
                TimetableGenerator.isDateWithinEvent(selectedDate, ev)
            }
            if (matchingEvents.isNotEmpty()) {
                items(matchingEvents, key = { it.id }) { event ->
                    ElevatedCard(
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${event.eventType.label}: ${event.title}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "${event.startDate} to ${event.endDate}${if (event.description.isNotBlank()) " • ${event.description}" else ""}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { viewModel.deleteCalendarEvent(event.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete Event", tint = AttendanceRed)
                            }
                        }
                    }
                }
            }

            // Lectures on Selected Date
            val dayLectures = instancesByDate[selectedDate.toString()].orEmpty().sortedBy { it.startTime }
            if (dayLectures.isEmpty()) {
                item {
                    ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = if (uiState.holidayDates.contains(selectedDate)) {
                                "Academic Holiday / No Classes Scheduled."
                            } else {
                                "Nothing scheduled on $selectedDate."
                            },
                            modifier = Modifier.padding(20.dp),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            } else {
                items(dayLectures, key = { it.id }) { lecture ->
                    HomeLectureCard(
                        lecture = lecture,
                        currentDate = uiState.currentDate,
                        currentTime = uiState.currentTime,
                        onMarkStatus = { status ->
                            viewModel.markAttendance(lecture.id, status, "CALENDAR_SCREEN")
                        }
                    )
                }
            }
        }
    }

    if (showAddEventDialog) {
        var title by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }
        var startDate by remember { mutableStateOf(selectedDate.toString()) }
        var endDate by remember { mutableStateOf(selectedDate.toString()) }
        var eventType by remember { mutableStateOf(CalendarEventType.HOLIDAY) }
        var followsDay by remember { mutableIntStateOf(1) }

        AlertDialog(
            onDismissRequest = { showAddEventDialog = false },
            title = { Text("Add Academic Calendar Entry") },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Event / Holiday Title") }, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = startDate, onValueChange = { startDate = it }, label = { Text("Start (YYYY-MM-DD)") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = endDate, onValueChange = { endDate = it }, label = { Text("End (YYYY-MM-DD)") }, modifier = Modifier.weight(1f))
                        }
                    }
                    item {
                        Text("Event Type", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            CalendarEventType.entries.forEach { t ->
                                FilterChip(
                                    selected = eventType == t,
                                    onClick = { eventType = t },
                                    label = { Text(t.label) }
                                )
                            }
                        }
                    }
                    if (eventType == CalendarEventType.SPECIAL_WORKING_SATURDAY ||
                        eventType == CalendarEventType.TIMETABLE_OVERRIDE_DAY
                    ) {
                        item {
                            Text("Follows Weekday Schedule:", style = MaterialTheme.typography.labelMedium)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                (1..5).forEach { d ->
                                    FilterChip(
                                        selected = followsDay == d,
                                        onClick = { followsDay = d },
                                        label = { Text(TimetableGenerator.dayName(d)) }
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (title.isNotBlank()) {
                        viewModel.saveCalendarEvent(
                            AcademicCalendarEvent(
                                id = "ev_${UUID.randomUUID().toString().take(8)}",
                                title = title.trim(),
                                description = description.trim(),
                                startDate = startDate.trim(),
                                endDate = endDate.trim(),
                                eventType = eventType,
                                followsDayOfWeek = if (
                                    eventType == CalendarEventType.SPECIAL_WORKING_SATURDAY ||
                                    eventType == CalendarEventType.TIMETABLE_OVERRIDE_DAY
                                ) followsDay else null
                            )
                        )
                        showAddEventDialog = false
                    }
                }) {
                    Text("SAVE")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddEventDialog = false }) { Text("CANCEL") }
            }
        )
    }
}

@Composable
private fun MonthlyCalendarGrid(
    yearMonth: YearMonth,
    selectedDate: LocalDate,
    holidayDates: Set<LocalDate>,
    instancesByDate: Map<String, List<com.collegecompanion.domain.model.LectureInstance>>,
    onSelectDate: (LocalDate) -> Unit
) {
    val firstOfMonth = yearMonth.atDay(1)
    val daysInMonth = yearMonth.lengthOfMonth()
    val leadingEmptyCells = (firstOfMonth.dayOfWeek.value - 1) // Monday = 0 offset

    ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(modifier = Modifier.fillMaxWidth()) {
                listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun").forEach { d ->
                    Text(
                        text = d,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            val totalCells = leadingEmptyCells + daysInMonth
            val rows = (totalCells + 6) / 7
            for (r in 0 until rows) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    for (c in 0..6) {
                        val cellIndex = r * 7 + c
                        val dayNum = cellIndex - leadingEmptyCells + 1
                        if (dayNum in 1..daysInMonth) {
                            val date = yearMonth.atDay(dayNum)
                            val isSelected = date == selectedDate
                            val isHoliday = holidayDates.contains(date)
                            val dayLectures = instancesByDate[date.toString()].orEmpty()

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .padding(2.dp)
                                    .background(
                                        color = when {
                                            isSelected -> MaterialTheme.colorScheme.primary
                                            isHoliday -> AttendanceRed.copy(alpha = 0.14f)
                                            else -> Color.Transparent
                                        },
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                    .clickable { onSelectDate(date) },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = dayNum.toString(),
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = when {
                                            isSelected -> Color.White
                                            isHoliday -> AttendanceRed
                                            else -> MaterialTheme.colorScheme.onSurface
                                        }
                                    )
                                    if (dayLectures.isNotEmpty()) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                            dayLectures.take(3).forEach { lec ->
                                                Box(
                                                    modifier = Modifier
                                                        .size(5.dp)
                                                        .background(
                                                            parseHexColor(lec.subjectColorHex),
                                                            CircleShape
                                                        )
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            Spacer(modifier = Modifier.weight(1f).height(48.dp))
                        }
                    }
                }
            }
        }
    }
}
