package com.collegecompanion.domain.model

import kotlinx.serialization.Serializable
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime

@Serializable
enum class LectureType(val displayName: String) {
    LECTURE("Lecture"),
    LAB("Laboratory"),
    TUTORIAL("Tutorial"),
    SEMINAR("Seminar"),
    WORKSHOP("Workshop"),
    EXTRA("Additional Lecture")
}

@Serializable
enum class AttendanceStatus(val displayName: String) {
    PENDING("Pending"),
    ATTENDED("Attended"),
    ABSENT("Absent"),
    CANCELLED("Cancelled")
}

@Serializable
enum class LiveLecturePhase(val label: String) {
    UPCOMING("Upcoming"),
    ONGOING("Ongoing"),
    COMPLETED("Completed"),
    ATTENDED("Attended"),
    ABSENT("Absent"),
    CANCELLED("Cancelled")
}

@Serializable
enum class AttendanceWarningLevel {
    COMFORTABLE, // Green (e.g. >= 75%)
    WARNING,     // Yellow/Orange (e.g. 70% .. <75%)
    CRITICAL,    // Red (< required threshold, e.g. < 70%)
    NEUTRAL      // No finalized lectures yet (0 conducted)
}

@Serializable
enum class CalendarEventType(val label: String) {
    HOLIDAY("Holiday"),
    NON_WORKING_DAY("Non-Working Day"),
    SPECIAL_WORKING_SATURDAY("Special Working Saturday"),
    TIMETABLE_OVERRIDE_DAY("Timetable Override (Follows Another Weekday)"),
    EXAMINATION("Examination Period"),
    VACATION("Vacation"),
    SPECIAL_LECTURE("Special Lecture"),
    EVENT("College Event"),
    ACADEMIC_DEADLINE("Academic Deadline")
}

@Serializable
enum class RotationPattern(val label: String) {
    EVERY_WEEK("Every Week"),
    ODD_WEEKS("Odd Semester Weeks (Week 1, 3, 5...)"),
    EVEN_WEEKS("Even Semester Weeks (Week 2, 4, 6...)"),
    ROTATION_SET_A("Rotation Set A"),
    ROTATION_SET_B("Rotation Set B")
}

@Serializable
data class Subject(
    val id: String,
    val code: String,
    val name: String,
    val professor: String = "",
    val colorHex: String = "#1A73E8",
    val defaultRoom: String = "",
    val defaultLab: String = "",
    val defaultBuilding: String = "",
    val defaultFloor: String = "",
    val customRequiredPercentage: Double? = null,
    val remindersEnabled: Boolean = true
)

@Serializable
data class TimetableSlot(
    val id: String,
    val subjectId: String,
    val dayOfWeek: Int, // 1 = Monday .. 7 = Sunday (ISO-8601)
    val startTime: String, // HH:mm
    val endTime: String,   // HH:mm
    val roomNumber: String = "",
    val labNumber: String = "",
    val building: String = "",
    val floor: String = "",
    val professorOverride: String = "",
    val lectureType: LectureType = LectureType.LECTURE,
    val rotationPattern: RotationPattern = RotationPattern.EVERY_WEEK,
    val isActive: Boolean = true
)

@Serializable
data class LectureInstance(
    val id: String, // Unique deterministic or UUID instance ID (e.g. "2026-11-01_slotId" or custom one-off ID)
    val subjectId: String,
    val subjectName: String,
    val subjectCode: String,
    val subjectColorHex: String,
    val date: String,      // YYYY-MM-DD
    val startTime: String, // HH:mm
    val endTime: String,   // HH:mm
    val roomNumber: String = "",
    val labNumber: String = "",
    val building: String = "",
    val floor: String = "",
    val professor: String = "",
    val lectureType: LectureType = LectureType.LECTURE,
    val attendanceStatus: AttendanceStatus = AttendanceStatus.PENDING,
    val isOneTimeOrExtra: Boolean = false,
    val isRescheduled: Boolean = false,
    val rescheduledFromDate: String? = null,
    val sourceSlotId: String? = null,
    val notes: String = "",
    val lastUpdatedEpochMillis: Long = 0L
) {
    fun formattedLocation(): String {
        val parts = mutableListOf<String>()
        if (roomNumber.isNotBlank()) parts.add("Room $roomNumber")
        if (labNumber.isNotBlank()) parts.add("Lab $labNumber")
        if (building.isNotBlank()) parts.add(building)
        if (floor.isNotBlank()) parts.add("Floor $floor")
        return if (parts.isEmpty()) "Room TBD" else parts.joinToString(" • ")
    }

    fun resolveLivePhase(currentDate: LocalDate, currentTime: LocalTime): LiveLecturePhase {
        return when (attendanceStatus) {
            AttendanceStatus.CANCELLED -> LiveLecturePhase.CANCELLED
            AttendanceStatus.ATTENDED -> LiveLecturePhase.ATTENDED
            AttendanceStatus.ABSENT -> LiveLecturePhase.ABSENT
            AttendanceStatus.PENDING -> {
                val lectureDate = LocalDate.parse(date)
                val start = LocalTime.parse(startTime)
                val end = LocalTime.parse(endTime)
                when {
                    lectureDate.isAfter(currentDate) -> LiveLecturePhase.UPCOMING
                    lectureDate.isBefore(currentDate) -> LiveLecturePhase.COMPLETED
                    currentTime.isBefore(start) -> LiveLecturePhase.UPCOMING
                    !currentTime.isAfter(end) -> LiveLecturePhase.ONGOING
                    else -> LiveLecturePhase.COMPLETED
                }
            }
        }
    }
}

@Serializable
data class AcademicCalendarConfig(
    val semesterName: String = "Fall Semester 2026",
    val semesterStartDate: String = "2026-07-01", // YYYY-MM-DD
    val semesterEndDate: String = "2026-12-15",   // YYYY-MM-DD
    val workingDaysOfWeek: Set<Int> = setOf(1, 2, 3, 4, 5) // Mon..Fri default
)

@Serializable
data class AcademicCalendarEvent(
    val id: String,
    val title: String,
    val description: String = "",
    val startDate: String, // YYYY-MM-DD
    val endDate: String,   // YYYY-MM-DD
    val eventType: CalendarEventType,
    val followsDayOfWeek: Int? = null, // Used when eventType == SPECIAL_WORKING_SATURDAY or TIMETABLE_OVERRIDE_DAY
    val rotationSetOverride: RotationPattern? = null,
    val subjectId: String? = null,
    val startTime: String? = null,
    val endTime: String? = null,
    val location: String = ""
)

data class SubjectAttendanceSummary(
    val subject: Subject,
    val attendedCount: Int,
    val absentCount: Int,
    val pendingPastCount: Int,
    val cancelledCount: Int,
    val futureScheduledCount: Int,
    val totalFinalizedCount: Int,
    val currentPercentage: Double,
    val requiredPercentage: Double,
    val warningThresholdPercentage: Double,
    val safeAbsences: Int,
    val recoveryLecturesNeeded: Int,
    val warningLevel: AttendanceWarningLevel
)

data class OverallAttendanceSummary(
    val totalAttended: Int,
    val totalAbsent: Int,
    val totalPendingPast: Int,
    val totalCancelled: Int,
    val totalFutureScheduled: Int,
    val totalFinalized: Int,
    val currentPercentage: Double,
    val globalRequiredPercentage: Double,
    val globalWarningPercentage: Double,
    val overallSafeAbsences: Int,
    val overallRecoveryLecturesNeeded: Int,
    val warningLevel: AttendanceWarningLevel,
    val subjectSummaries: List<SubjectAttendanceSummary>,
    val subjectsBelowThresholdCount: Int
)

enum class ProjectionScenarioType(val title: String, val description: String) {
    ATTEND_ALL("Scenario 1: Attend All Upcoming", "Simulate attending 100% of remaining scheduled lectures"),
    MISS_NEXT_1("Scenario 2: Miss Next 1 Lecture", "Miss the very next lecture and attend remaining"),
    MISS_NEXT_2("Scenario 3: Miss Next 2 Lectures", "Miss the next 2 upcoming lectures"),
    MISS_NEXT_3("Scenario 4: Miss Next 3 Lectures", "Miss the next 3 upcoming lectures"),
    MISS_CUSTOM_COUNT("Scenario 5: Miss Custom Number", "Specify how many upcoming lectures you might miss"),
    SELECT_SPECIFIC_FUTURE("Scenario 6: Pick Specific Future Lectures", "Toggle individual future lectures as Attend or Miss"),
    ATTEND_SELECTED_COUNT("Scenario 7: Attend N & Miss Remaining", "Attend a selected count of future lectures and miss the rest")
}

data class ProjectedAttendanceResult(
    val subjectId: String?, // null for overall
    val label: String,
    val currentAttended: Int,
    val currentFinalized: Int,
    val currentPercentage: Double,
    val futureTotalScheduled: Int,
    val futureProjectedAttended: Int,
    val futureProjectedMissed: Int,
    val projectedPercentage: Double,
    val requiredPercentage: Double,
    val currentSafeAbsences: Int,
    val projectedSafeAbsences: Int,
    val dropsBelowThreshold: Boolean,
    val warningLevel: AttendanceWarningLevel
)

@Serializable
data class PreviousLectureStatusEntry(
    val lectureInstanceId: String,
    val subjectName: String,
    val startTime: String,
    val previousStatus: AttendanceStatus,
    val newStatus: AttendanceStatus
)

@Serializable
data class BulkAbsenceOperationRecord(
    val operationId: String,
    val targetDate: String,
    val timestampEpochMillis: Long,
    val affectedLectures: List<PreviousLectureStatusEntry>,
    val wasUndone: Boolean = false
)

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class FontFamilyOption(val label: String) { SANS_SERIF("Default Sans"), SERIF("Academic Serif"), MONOSPACE("Monospace"), ROUNDED("Rounded Modern") }
enum class CardStyleOption(val label: String) { ELEVATED("Elevated Rounded"), OUTLINED("Clean Outlined"), FILLED("Tonal Filled") }
enum class WidgetThemeOption(val label: String) { BLUE_CALENDAR("Google Calendar Blue"), DYNAMIC_MATERIAL("Material Dynamic"), DARK_SLATE("Dark Slate"), HIGH_CONTRAST("High Contrast") }

data class UserPreferences(
    val primaryColorHex: String = "#1A73E8",
    val secondaryColorHex: String = "#00897B",
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val fontFamily: FontFamilyOption = FontFamilyOption.SANS_SERIF,
    val fontScale: Float = 1.0f,
    val cardStyle: CardStyleOption = CardStyleOption.ELEVATED,
    val widgetTheme: WidgetThemeOption = WidgetThemeOption.BLUE_CALENDAR,
    val globalRequiredAttendance: Double = 70.0,
    val warningThresholdAttendance: Double = 75.0,
    val remindersMasterEnabled: Boolean = true,
    val reminderIntervalsMinutes: Set<Int> = setOf(30, 15, 5),
    val notificationSoundEnabled: Boolean = true,
    val notificationVibrationEnabled: Boolean = true,
    val semesterName: String = "Fall Semester 2026",
    val semesterStartDate: String = "2026-07-01",
    val semesterEndDate: String = "2026-12-15",
    val workingDaysOfWeek: Set<Int> = setOf(1, 2, 3, 4, 5)
)
