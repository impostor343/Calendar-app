package com.collegecompanion.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.collegecompanion.data.local.CollegeCompanionDatabase
import com.collegecompanion.data.preferences.PreferencesDataStore
import com.collegecompanion.data.repository.CollegeRepository
import com.collegecompanion.widget.WidgetRefreshManager
import java.util.concurrent.TimeUnit

class DailyWidgetRefreshWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val db = CollegeCompanionDatabase.getInstance(applicationContext)
        val prefs = PreferencesDataStore(applicationContext)
        val repo = CollegeRepository(applicationContext, db, prefs)

        repo.rescheduleUpcomingReminders()
        WidgetRefreshManager.refreshAllWidgets(applicationContext)
        return Result.success()
    }

    companion object {
        private const val WORK_NAME = "college_companion_periodic_sync"

        fun enqueuePeriodicSync(context: Context) {
            val request = PeriodicWorkRequestBuilder<DailyWidgetRefreshWorker>(6, TimeUnit.HOURS)
                .build()
            WorkManager.getInstance(context.applicationContext).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }
    }
}
