package com.collegecompanion.notification

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.collegecompanion.domain.model.LectureInstance
import com.collegecompanion.domain.model.Subject
import com.collegecompanion.domain.model.UserPreferences
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

/**
 * Schedules multi-interval lecture notifications (5, 10, 15, 20, 30, 45, 60 minutes)
 * using Android's native AlarmManager (Part 9).
 * Also schedules a daily midnight rollover alarm so the Home Screen and Jetpack Glance Widgets
 * automatically refresh when the local date changes.
 */
object LectureReminderScheduler {

    const val CHANNEL_ID_REMINDERS = "college_companion_lecture_reminders"
    const val ACTION_SHOW_LECTURE_REMINDER = "com.collegecompanion.action.SHOW_LECTURE_REMINDER"
    const val ACTION_MIDNIGHT_DATE_ROLLOVER = "com.collegecompanion.action.MIDNIGHT_DATE_ROLLOVER"

    val SUPPORTED_INTERVALS = listOf(5, 10, 15, 20, 30, 45, 60)

    fun ensureNotificationChannel(context: Context) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val existing = manager.getNotificationChannel(CHANNEL_ID_REMINDERS)
        if (existing == null) {
            val channel = NotificationChannel(
                CHANNEL_ID_REMINDERS,
                "Lecture Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Upcoming college lecture reminders with classroom and professor details"
                enableVibration(true)
            }
            manager.createNotificationChannel(channel)
        }
    }

    fun canScheduleExactAlarms(context: Context): Boolean {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }
    }

    /**
     * Schedules notifications for upcoming lectures over the next 7 days across all user-selected
     * reminder intervals (e.g., 30m, 15m, and 5m simultaneously), and schedules midnight rollover.
     */
    fun scheduleUpcomingLectures(
        context: Context,
        preferences: UserPreferences,
        subjectsById: Map<String, Subject>,
        upcomingInstances: List<LectureInstance>,
        now: LocalDateTime = LocalDateTime.now()
    ) {
        ensureNotificationChannel(context)
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        // Always keep midnight rollover scheduled for automatic date updates
        scheduleMidnightRollover(context, alarmManager, now.toLocalDate())

        val horizonDate = now.toLocalDate().plusDays(7)
        val candidateInstances = upcomingInstances.filter { inst ->
            val d = runCatching { LocalDate.parse(inst.date) }.getOrNull() ?: return@filter false
            !d.isBefore(now.toLocalDate()) && !d.isAfter(horizonDate)
        }

        // First cancel any previously scheduled interval alarms for these instances
        for (instance in candidateInstances) {
            for (interval in SUPPORTED_INTERVALS) {
                val requestCode = computeRequestCode(instance.id, interval)
                val pending = buildReminderPendingIntent(
                    context = context,
                    requestCode = requestCode,
                    instance = instance,
                    minutesBefore = interval,
                    soundEnabled = preferences.notificationSoundEnabled,
                    vibrationEnabled = preferences.notificationVibrationEnabled,
                    noCreate = true
                )
                if (pending != null) {
                    alarmManager.cancel(pending)
                    pending.cancel()
                }
            }
        }

        if (!preferences.remindersMasterEnabled || preferences.reminderIntervalsMinutes.isEmpty()) {
            return
        }

        val zoneId = ZoneId.systemDefault()
        val nowMillis = now.atZone(zoneId).toInstant().toEpochMilli()

        for (instance in candidateInstances) {
            val subject = subjectsById[instance.subjectId]
            if (subject != null && !subject.remindersEnabled) {
                continue
            }

            val lectureDate = runCatching { LocalDate.parse(instance.date) }.getOrNull() ?: continue
            val lectureTime = runCatching { LocalTime.parse(instance.startTime) }.getOrNull() ?: continue
            val lectureDateTime = LocalDateTime.of(lectureDate, lectureTime)

            for (minutesBefore in preferences.reminderIntervalsMinutes) {
                val triggerDateTime = lectureDateTime.minusMinutes(minutesBefore.toLong())
                val triggerMillis = triggerDateTime.atZone(zoneId).toInstant().toEpochMilli()

                if (triggerMillis <= nowMillis) {
                    continue
                }

                val requestCode = computeRequestCode(instance.id, minutesBefore)
                val pendingIntent = buildReminderPendingIntent(
                    context = context,
                    requestCode = requestCode,
                    instance = instance,
                    minutesBefore = minutesBefore,
                    soundEnabled = preferences.notificationSoundEnabled,
                    vibrationEnabled = preferences.notificationVibrationEnabled,
                    noCreate = false
                ) ?: continue

                scheduleAlarmSafely(alarmManager, triggerMillis, pendingIntent)
            }
        }
    }

    fun scheduleMidnightRollover(
        context: Context,
        alarmManager: AlarmManager,
        currentDate: LocalDate = LocalDate.now()
    ) {
        val nextMidnight = LocalDateTime.of(currentDate.plusDays(1), LocalTime.MIDNIGHT).plusSeconds(2)
        val triggerMillis = nextMidnight.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

        val intent = Intent(context, BootAndTimeChangeReceiver::class.java).apply {
            action = ACTION_MIDNIGHT_DATE_ROLLOVER
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            999_001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        scheduleAlarmSafely(alarmManager, triggerMillis, pendingIntent)
    }

    private fun scheduleAlarmSafely(
        alarmManager: AlarmManager,
        triggerAtMillis: Long,
        pendingIntent: PendingIntent
    ) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                // Graceful fallback when exact alarm permission is denied by the user
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
            }
        } catch (_: SecurityException) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
        }
    }

    fun computeRequestCode(instanceId: String, minutesBefore: Int): Int {
        return (instanceId.hashCode() * 31) + minutesBefore
    }

    private fun buildReminderPendingIntent(
        context: Context,
        requestCode: Int,
        instance: LectureInstance,
        minutesBefore: Int,
        soundEnabled: Boolean,
        vibrationEnabled: Boolean,
        noCreate: Boolean
    ): PendingIntent? {
        val intent = Intent(context, LectureReminderReceiver::class.java).apply {
            action = ACTION_SHOW_LECTURE_REMINDER
            putExtra(LectureReminderReceiver.EXTRA_INSTANCE_ID, instance.id)
            putExtra(LectureReminderReceiver.EXTRA_SUBJECT_NAME, instance.subjectName)
            putExtra(LectureReminderReceiver.EXTRA_START_TIME, instance.startTime)
            putExtra(LectureReminderReceiver.EXTRA_END_TIME, instance.endTime)
            putExtra(LectureReminderReceiver.EXTRA_ROOM, instance.roomNumber)
            putExtra(LectureReminderReceiver.EXTRA_LAB, instance.labNumber)
            putExtra(LectureReminderReceiver.EXTRA_BUILDING, instance.building)
            putExtra(LectureReminderReceiver.EXTRA_FLOOR, instance.floor)
            putExtra(LectureReminderReceiver.EXTRA_PROFESSOR, instance.professor)
            putExtra(LectureReminderReceiver.EXTRA_MINUTES_BEFORE, minutesBefore)
            putExtra(LectureReminderReceiver.EXTRA_SOUND_ENABLED, soundEnabled)
            putExtra(LectureReminderReceiver.EXTRA_VIBRATION_ENABLED, vibrationEnabled)
        }
        val flags = if (noCreate) {
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        }
        return PendingIntent.getBroadcast(context, requestCode, intent, flags)
    }
}
