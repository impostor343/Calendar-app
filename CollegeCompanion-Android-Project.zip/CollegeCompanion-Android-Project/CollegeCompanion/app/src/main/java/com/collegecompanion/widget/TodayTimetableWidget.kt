package com.collegecompanion.widget

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.lazy.LazyColumn
import androidx.glance.appwidget.lazy.items
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.collegecompanion.MainActivity
import com.collegecompanion.domain.model.AttendanceStatus
import com.collegecompanion.domain.model.AttendanceWarningLevel
import com.collegecompanion.domain.model.LectureInstance

/**
 * Widget A: Today's Timetable (Part 4 & Part 5).
 * - Google Calendar schedule inspired layout:
 *   - Date/Day column & prominent "COMPLETE ABSENT" button at the top.
 *   - Rounded blue/subject-colored lecture cards displaying subject, time, room/lab/building/floor, professor.
 *   - Interactive "ATTENDED" (green) and "ABSENT" (red) buttons directly on every lecture card.
 *   - Current attendance percentage & safe absences bar at the bottom.
 */
class TodayTimetableWidget : GlanceAppWidget() {

    override val sizeMode: SizeMode = SizeMode.Responsive(
        setOf(
            DpSize(250.dp, 180.dp),
            DpSize(320.dp, 260.dp),
            DpSize(380.dp, 360.dp)
        )
    )

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val snapshot = WidgetSnapshotLoader.loadSnapshot(context)
        provideContent {
            GlanceTheme {
                TodayTimetableWidgetContent(context = context, snapshot = snapshot)
            }
        }
    }
}

@Composable
fun TodayTimetableWidgetContent(
    context: Context,
    snapshot: WidgetDataSnapshot
) {
    val containerBg = ColorProvider(Color(0xFF0F172A))
    val headerCardBg = ColorProvider(Color(0xFF1E293B))
    val blueCardBg = ColorProvider(Color(0xFF1E3A8A))
    val textWhite = ColorProvider(Color(0xFFF8FAFC))
    val textMuted = ColorProvider(Color(0xFF94A3B8))

    val completeAbsentIntent = Intent(context, CompleteDayAbsentActivity::class.java).apply {
        putExtra(CompleteDayAbsentActivity.EXTRA_TARGET_DATE, snapshot.currentDate.toString())
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }
    val openAppIntent = Intent(context, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(containerBg)
            .cornerRadius(22.dp)
            .padding(12.dp)
    ) {
        // Top Header: Date/Day badge on the left + "COMPLETE ABSENT" action button on the right
        Row(
            modifier = GlanceModifier
                .fillMaxWidth()
                .background(headerCardBg)
                .cornerRadius(16.dp)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Date / Weekday Column
            Row(
                modifier = GlanceModifier
                    .defaultWeight()
                    .clickable(actionStartActivity(openAppIntent)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = GlanceModifier
                        .background(ColorProvider(Color(0xFF2563EB)))
                        .cornerRadius(12.dp)
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = snapshot.dayOfWeekShort,
                            style = TextStyle(
                                color = textWhite,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = snapshot.dayOfMonthNumber,
                            style = TextStyle(
                                color = textWhite,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
                Spacer(modifier = GlanceModifier.width(10.dp))
                Column {
                    Text(
                        text = "Today's Schedule",
                        style = TextStyle(
                            color = textWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = snapshot.fullFormattedDate,
                        style = TextStyle(
                            color = textMuted,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            // Prominent COMPLETE ABSENT button
            if (!snapshot.isHolidayToday && snapshot.todayLectures.isNotEmpty()) {
                Box(
                    modifier = GlanceModifier
                        .background(ColorProvider(Color(0xFFB91C1C)))
                        .cornerRadius(10.dp)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .clickable(actionStartActivity(completeAbsentIntent)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "COMPLETE ABSENT",
                        style = TextStyle(
                            color = textWhite,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        Spacer(modifier = GlanceModifier.height(8.dp))

        // Main Lecture List
        if (snapshot.isHolidayToday) {
            Box(
                modifier = GlanceModifier
                    .fillMaxWidth()
                    .defaultWeight()
                    .background(headerCardBg)
                    .cornerRadius(16.dp)
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = snapshot.holidayTitle ?: "Academic Holiday",
                        style = TextStyle(color = textWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = GlanceModifier.height(4.dp))
                    Text(
                        text = "Nothing scheduled",
                        style = TextStyle(color = textMuted, fontSize = 12.sp)
                    )
                }
            }
        } else if (snapshot.todayLectures.isEmpty()) {
            Box(
                modifier = GlanceModifier
                    .fillMaxWidth()
                    .defaultWeight()
                    .background(headerCardBg)
                    .cornerRadius(16.dp)
                    .padding(16.dp)
                    .clickable(actionStartActivity(openAppIntent)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Nothing scheduled",
                    style = TextStyle(color = textMuted, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                )
            }
        } else {
            LazyColumn(
                modifier = GlanceModifier
                    .fillMaxWidth()
                    .defaultWeight()
            ) {
                items(snapshot.todayLectures, itemId = { it.id.hashCode().toLong() }) { lecture ->
                    Column(modifier = GlanceModifier.fillMaxWidth().padding(bottom = 8.dp)) {
                        WidgetLectureCard(lecture = lecture, blueCardBg = blueCardBg)
                    }
                }
            }
        }

        Spacer(modifier = GlanceModifier.height(6.dp))

        // Bottom Attendance Bar
        val att = snapshot.overallAttendance
        val statusColor = when (att.warningLevel) {
            AttendanceWarningLevel.CRITICAL -> ColorProvider(Color(0xFFEF4444))
            AttendanceWarningLevel.WARNING -> ColorProvider(Color(0xFFF59E0B))
            AttendanceWarningLevel.COMFORTABLE -> ColorProvider(Color(0xFF22C55E))
            AttendanceWarningLevel.NEUTRAL -> ColorProvider(Color(0xFF60A5FA))
        }

        Row(
            modifier = GlanceModifier
                .fillMaxWidth()
                .background(headerCardBg)
                .cornerRadius(14.dp)
                .padding(horizontal = 12.dp, vertical = 8.dp)
                .clickable(actionStartActivity(openAppIntent)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Current Attendance: ${String.format("%.2f", att.currentPercentage)}%",
                style = TextStyle(
                    color = statusColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                ),
                modifier = GlanceModifier.defaultWeight()
            )
            Text(
                text = "Safe Absences: ${att.overallSafeAbsences}",
                style = TextStyle(
                    color = textWhite,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            )
        }
    }
}

@Composable
fun WidgetLectureCard(
    lecture: LectureInstance,
    blueCardBg: ColorProvider
) {
    val cardBackground = when (lecture.attendanceStatus) {
        AttendanceStatus.ATTENDED -> ColorProvider(Color(0xFF14532D)) // Distinct rich green
        AttendanceStatus.ABSENT -> ColorProvider(Color(0xFF7F1D1D))   // Distinct rich red
        AttendanceStatus.CANCELLED -> ColorProvider(Color(0xFF334155)) // Grey
        AttendanceStatus.PENDING -> blueCardBg                         // Default Google Calendar blue
    }
    val textWhite = ColorProvider(Color(0xFFF8FAFC))
    val textSub = ColorProvider(Color(0xFFCBD5E1))

    Column(
        modifier = GlanceModifier
            .fillMaxWidth()
            .background(cardBackground)
            .cornerRadius(16.dp)
            .padding(12.dp)
    ) {
        Row(
            modifier = GlanceModifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = GlanceModifier.defaultWeight()) {
                Text(
                    text = "${lecture.subjectName} (${lecture.subjectCode})",
                    style = TextStyle(
                        color = textWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = "${lecture.startTime} - ${lecture.endTime} • ${lecture.formattedLocation()}",
                    style = TextStyle(
                        color = textSub,
                        fontSize = 11.sp
                    )
                )
                if (lecture.professor.isNotBlank()) {
                    Text(
                        text = lecture.professor,
                        style = TextStyle(
                            color = textSub,
                            fontSize = 10.sp
                        )
                    )
                }
            }

            // Status Pill
            val badgeText = when (lecture.attendanceStatus) {
                AttendanceStatus.ATTENDED -> "ATTENDED"
                AttendanceStatus.ABSENT -> "ABSENT"
                AttendanceStatus.CANCELLED -> "CANCELLED"
                AttendanceStatus.PENDING -> "PENDING"
            }
            val badgeColor = when (lecture.attendanceStatus) {
                AttendanceStatus.ATTENDED -> ColorProvider(Color(0xFF22C55E))
                AttendanceStatus.ABSENT -> ColorProvider(Color(0xFFEF4444))
                AttendanceStatus.CANCELLED -> ColorProvider(Color(0xFF64748B))
                AttendanceStatus.PENDING -> ColorProvider(Color(0xFF3B82F6))
            }

            Box(
                modifier = GlanceModifier
                    .background(badgeColor)
                    .cornerRadius(8.dp)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = badgeText,
                    style = TextStyle(
                        color = textWhite,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        if (lecture.attendanceStatus != AttendanceStatus.CANCELLED) {
            Spacer(modifier = GlanceModifier.height(8.dp))
            Row(
                modifier = GlanceModifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // ATTENDED Button
                val attendedBg = if (lecture.attendanceStatus == AttendanceStatus.ATTENDED) {
                    ColorProvider(Color(0xFF16A34A))
                } else {
                    ColorProvider(Color(0xFF1E293B))
                }
                Box(
                    modifier = GlanceModifier
                        .defaultWeight()
                        .background(attendedBg)
                        .cornerRadius(10.dp)
                        .padding(vertical = 6.dp)
                        .clickable(
                            actionRunCallback<MarkLectureAttendanceActionCallback>(
                                actionParametersOf(
                                    MarkLectureAttendanceActionCallback.KEY_LECTURE_INSTANCE_ID to lecture.id,
                                    MarkLectureAttendanceActionCallback.KEY_TARGET_STATUS to AttendanceStatus.ATTENDED.name
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "✓ ATTENDED",
                        style = TextStyle(
                            color = textWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Spacer(modifier = GlanceModifier.width(8.dp))

                // ABSENT Button
                val absentBg = if (lecture.attendanceStatus == AttendanceStatus.ABSENT) {
                    ColorProvider(Color(0xFFDC2626))
                } else {
                    ColorProvider(Color(0xFF1E293B))
                }
                Box(
                    modifier = GlanceModifier
                        .defaultWeight()
                        .background(absentBg)
                        .cornerRadius(10.dp)
                        .padding(vertical = 6.dp)
                        .clickable(
                            actionRunCallback<MarkLectureAttendanceActionCallback>(
                                actionParametersOf(
                                    MarkLectureAttendanceActionCallback.KEY_LECTURE_INSTANCE_ID to lecture.id,
                                    MarkLectureAttendanceActionCallback.KEY_TARGET_STATUS to AttendanceStatus.ABSENT.name
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "✕ ABSENT",
                        style = TextStyle(
                            color = textWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }
    }
}

class TodayTimetableWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = TodayTimetableWidget()
}
