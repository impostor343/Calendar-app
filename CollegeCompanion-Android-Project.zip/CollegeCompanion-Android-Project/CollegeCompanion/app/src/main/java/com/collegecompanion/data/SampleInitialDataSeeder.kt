package com.collegecompanion.data

import com.collegecompanion.domain.engine.AcademicScheduleBundle
import com.collegecompanion.domain.model.AcademicCalendarConfig
import com.collegecompanion.domain.model.AcademicCalendarEvent
import com.collegecompanion.domain.model.CalendarEventType
import com.collegecompanion.domain.model.LectureType
import com.collegecompanion.domain.model.RotationPattern
import com.collegecompanion.domain.model.Subject
import com.collegecompanion.domain.model.TimetableSlot

/**
 * Provides a realistic default engineering timetable & academic calendar matching the prompt's
 * Data Structures, DBMS, and Probability & Statistics example so the user can immediately
 * test or customize their schedule.
 */
object SampleInitialDataSeeder {

    fun buildDefaultAcademicBundle(): AcademicScheduleBundle {
        val subjects = listOf(
            Subject(
                id = "sub_ds",
                code = "CS201",
                name = "Data Structures",
                professor = "Dr. A. Sharma",
                colorHex = "#1A73E8",
                defaultRoom = "301",
                defaultLab = "Lab-2",
                defaultBuilding = "Main CS Block",
                defaultFloor = "3rd",
                customRequiredPercentage = 70.0,
                remindersEnabled = true
            ),
            Subject(
                id = "sub_dbms",
                code = "CS204",
                name = "DBMS",
                professor = "Prof. R. Patel",
                colorHex = "#00897B",
                defaultRoom = "204",
                defaultLab = "DB-Lab-1",
                defaultBuilding = "IT Annex",
                defaultFloor = "2nd",
                customRequiredPercentage = 70.0,
                remindersEnabled = true
            ),
            Subject(
                id = "sub_prob",
                code = "MA202",
                name = "Probability and Statistics",
                professor = "Dr. K. Iyer",
                colorHex = "#E65100",
                defaultRoom = "105",
                defaultLab = "",
                defaultBuilding = "Science Block",
                defaultFloor = "1st",
                customRequiredPercentage = 70.0,
                remindersEnabled = true
            ),
            Subject(
                id = "sub_os",
                code = "CS206",
                name = "Operating Systems",
                professor = "Prof. N. Desai",
                colorHex = "#8E24AA",
                defaultRoom = "305",
                defaultLab = "OS-Lab-3",
                defaultBuilding = "Main CS Block",
                defaultFloor = "3rd",
                customRequiredPercentage = 75.0,
                remindersEnabled = true
            )
        )

        val slots = listOf(
            // Monday (Matches prompt Part 10.C example: 9 AM DS, 10 AM DS, 11:45 AM DBMS, 12:45 PM Prob & Stats)
            TimetableSlot("slot_mon_0900_ds", "sub_ds", 1, "09:00", "10:00", "301", "", "Main CS Block", "3rd", "Dr. A. Sharma", LectureType.LECTURE, RotationPattern.EVERY_WEEK),
            TimetableSlot("slot_mon_1000_ds", "sub_ds", 1, "10:00", "11:00", "301", "", "Main CS Block", "3rd", "Dr. A. Sharma", LectureType.LECTURE, RotationPattern.EVERY_WEEK),
            TimetableSlot("slot_mon_1145_dbms", "sub_dbms", 1, "11:45", "12:45", "204", "", "IT Annex", "2nd", "Prof. R. Patel", LectureType.LECTURE, RotationPattern.EVERY_WEEK),
            TimetableSlot("slot_mon_1245_prob", "sub_prob", 1, "12:45", "13:45", "105", "", "Science Block", "1st", "Dr. K. Iyer", LectureType.LECTURE, RotationPattern.EVERY_WEEK),

            // Tuesday
            TimetableSlot("slot_tue_0900_os", "sub_os", 2, "09:00", "10:00", "305", "", "Main CS Block", "3rd", "Prof. N. Desai", LectureType.LECTURE, RotationPattern.EVERY_WEEK),
            TimetableSlot("slot_tue_1015_dbms_lab", "sub_dbms", 2, "10:15", "12:15", "204", "DB-Lab-1", "IT Annex", "2nd", "Prof. R. Patel", LectureType.LAB, RotationPattern.EVERY_WEEK),
            TimetableSlot("slot_tue_1400_prob", "sub_prob", 2, "14:00", "15:00", "105", "", "Science Block", "1st", "Dr. K. Iyer", LectureType.TUTORIAL, RotationPattern.EVERY_WEEK),

            // Wednesday
            TimetableSlot("slot_wed_0900_ds_lab", "sub_ds", 3, "09:00", "11:00", "301", "Lab-2", "Main CS Block", "3rd", "Dr. A. Sharma", LectureType.LAB, RotationPattern.EVERY_WEEK),
            TimetableSlot("slot_wed_1145_os", "sub_os", 3, "11:45", "12:45", "305", "", "Main CS Block", "3rd", "Prof. N. Desai", LectureType.LECTURE, RotationPattern.EVERY_WEEK),
            TimetableSlot("slot_wed_1400_dbms", "sub_dbms", 3, "14:00", "15:00", "204", "", "IT Annex", "2nd", "Prof. R. Patel", LectureType.LECTURE, RotationPattern.EVERY_WEEK),

            // Thursday
            TimetableSlot("slot_thu_0900_prob", "sub_prob", 4, "09:00", "10:00", "105", "", "Science Block", "1st", "Dr. K. Iyer", LectureType.LECTURE, RotationPattern.EVERY_WEEK),
            TimetableSlot("slot_thu_1015_ds", "sub_ds", 4, "10:15", "11:15", "301", "", "Main CS Block", "3rd", "Dr. A. Sharma", LectureType.LECTURE, RotationPattern.EVERY_WEEK),
            TimetableSlot("slot_thu_1145_os_lab", "sub_os", 4, "11:45", "13:45", "305", "OS-Lab-3", "Main CS Block", "3rd", "Prof. N. Desai", LectureType.LAB, RotationPattern.EVERY_WEEK),

            // Friday
            TimetableSlot("slot_fri_0900_dbms", "sub_dbms", 5, "09:00", "10:00", "204", "", "IT Annex", "2nd", "Prof. R. Patel", LectureType.LECTURE, RotationPattern.EVERY_WEEK),
            TimetableSlot("slot_fri_1015_os", "sub_os", 5, "10:15", "11:15", "305", "", "Main CS Block", "3rd", "Prof. N. Desai", LectureType.LECTURE, RotationPattern.EVERY_WEEK),
            TimetableSlot("slot_fri_1145_prob", "sub_prob", 5, "11:45", "12:45", "105", "", "Science Block", "1st", "Dr. K. Iyer", LectureType.LECTURE, RotationPattern.EVERY_WEEK),

            // Sunday (Added 2 Sunday review/special sessions so if today is Sunday 2026-11-01, the user immediately sees active schedule cards too)
            TimetableSlot("slot_sun_1000_ds_rev", "sub_ds", 7, "10:00", "11:00", "301", "Lab-2", "Main CS Block", "3rd", "Dr. A. Sharma", LectureType.WORKSHOP, RotationPattern.EVERY_WEEK),
            TimetableSlot("slot_sun_1600_dbms_rev", "sub_dbms", 7, "16:00", "17:00", "204", "DB-Lab-1", "IT Annex", "2nd", "Prof. R. Patel", LectureType.TUTORIAL, RotationPattern.EVERY_WEEK)
        )

        val events = listOf(
            AcademicCalendarEvent(
                id = "ev_independence_day",
                title = "Independence Day Holiday",
                description = "National Holiday",
                startDate = "2026-08-15",
                endDate = "2026-08-15",
                eventType = CalendarEventType.HOLIDAY
            ),
            AcademicCalendarEvent(
                id = "ev_gandhi_jayanti",
                title = "Gandhi Jayanti",
                description = "National Holiday",
                startDate = "2026-10-02",
                endDate = "2026-10-02",
                eventType = CalendarEventType.HOLIDAY
            ),
            AcademicCalendarEvent(
                id = "ev_diwali_vacation",
                title = "Diwali Festival Break",
                description = "Academic festival vacation",
                startDate = "2026-11-08",
                endDate = "2026-11-12",
                eventType = CalendarEventType.HOLIDAY
            ),
            AcademicCalendarEvent(
                id = "ev_working_saturday_nov14",
                title = "Compensatory Working Saturday (Monday Timetable)",
                description = "Follows Monday schedule",
                startDate = "2026-11-14",
                endDate = "2026-11-14",
                eventType = CalendarEventType.SPECIAL_WORKING_SATURDAY,
                followsDayOfWeek = 1
            ),
            AcademicCalendarEvent(
                id = "ev_end_sem_exams",
                title = "End Semester Examinations",
                description = "Theory & Practical Final Exams",
                startDate = "2026-12-01",
                endDate = "2026-12-12",
                eventType = CalendarEventType.EXAMINATION
            )
        )

        return AcademicScheduleBundle(
            schemaVersion = 1,
            exportTimestampEpochMillis = System.currentTimeMillis(),
            calendarConfig = AcademicCalendarConfig(
                semesterName = "Fall Semester 2026",
                semesterStartDate = "2026-07-01",
                semesterEndDate = "2026-12-15",
                workingDaysOfWeek = setOf(1, 2, 3, 4, 5, 7)
            ),
            subjects = subjects,
            timetableSlots = slots,
            calendarEvents = events
        )
    }
}
