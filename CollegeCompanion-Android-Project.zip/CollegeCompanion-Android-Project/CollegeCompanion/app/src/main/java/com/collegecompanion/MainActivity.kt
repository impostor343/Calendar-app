package com.collegecompanion

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.collegecompanion.ui.screens.AttendanceScreen
import com.collegecompanion.ui.screens.CalendarScreen
import com.collegecompanion.ui.screens.GenerateAiScheduleScreen
import com.collegecompanion.ui.screens.HomeScreen
import com.collegecompanion.ui.screens.ImportScheduleScreen
import com.collegecompanion.ui.screens.SettingsScreen
import com.collegecompanion.ui.screens.TimetableScreen
import com.collegecompanion.ui.theme.CollegeCompanionTheme
import com.collegecompanion.ui.viewmodel.MainViewModel

enum class MainNavDestination(
    val route: String,
    val label: String,
    val icon: ImageVector
) {
    HOME("home", "Home", Icons.Default.Home),
    TIMETABLE("timetable", "Timetable", Icons.Default.Schedule),
    ATTENDANCE("attendance", "Attendance", Icons.Default.Assessment),
    CALENDAR("calendar", "Calendar", Icons.Default.CalendarMonth),
    SETTINGS("settings", "Settings", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val initialTab = intent?.getStringExtra("initial_tab")

        setContent {
            val mainViewModel: MainViewModel = viewModel()
            val uiState by mainViewModel.uiState.collectAsState()

            CollegeCompanionTheme(preferences = uiState.preferences) {
                CollegeCompanionAppShell(
                    uiState = uiState,
                    viewModel = mainViewModel,
                    initialRoute = initialTab
                )
            }
        }
    }
}

@Composable
fun CollegeCompanionAppShell(
    uiState: com.collegecompanion.ui.viewmodel.AppUiState,
    viewModel: MainViewModel,
    initialRoute: String? = null
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: MainNavDestination.HOME.route

    LaunchedEffect(initialRoute) {
        if (!initialRoute.isNullOrBlank() && MainNavDestination.entries.any { it.route == initialRoute }) {
            navController.navigate(initialRoute) {
                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar {
                MainNavDestination.entries.forEach { dest ->
                    NavigationBarItem(
                        selected = currentRoute == dest.route,
                        onClick = {
                            navController.navigate(dest.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(dest.icon, contentDescription = dest.label) },
                        label = { Text(dest.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = MainNavDestination.HOME.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(MainNavDestination.HOME.route) {
                HomeScreen(uiState = uiState, viewModel = viewModel)
            }
            composable(MainNavDestination.TIMETABLE.route) {
                TimetableScreen(uiState = uiState, viewModel = viewModel)
            }
            composable(MainNavDestination.ATTENDANCE.route) {
                AttendanceScreen(uiState = uiState, viewModel = viewModel)
            }
            composable(MainNavDestination.CALENDAR.route) {
                CalendarScreen(uiState = uiState, viewModel = viewModel)
            }
            composable(MainNavDestination.SETTINGS.route) {
                SettingsScreen(
                    uiState = uiState,
                    viewModel = viewModel,
                    onNavigateToImportSchedule = { navController.navigate("import_schedule") },
                    onNavigateToGenerateAiPrompt = { navController.navigate("generate_ai_schedule") }
                )
            }
            composable("import_schedule") {
                ImportScheduleScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
            composable("generate_ai_schedule") {
                GenerateAiScheduleScreen(
                    uiState = uiState,
                    onNavigateToImport = { navController.navigate("import_schedule") },
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
