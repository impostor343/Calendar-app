package com.collegecompanion.data.local

import androidx.room.TypeConverter
import com.collegecompanion.domain.model.AttendanceStatus
import com.collegecompanion.domain.model.CalendarEventType
import com.collegecompanion.domain.model.LectureType
import com.collegecompanion.domain.model.PreviousLectureStatusEntry
import com.collegecompanion.domain.model.RotationPattern
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class RoomConverters {
    private val json = Json { ignoreUnknownKeys = true }

    @TypeConverter
    fun fromLectureType(value: LectureType): String = value.name

    @TypeConverter
    fun toLectureType(value: String): LectureType =
        runCatching { LectureType.valueOf(value) }.getOrDefault(LectureType.LECTURE)

    @TypeConverter
    fun fromAttendanceStatus(value: AttendanceStatus): String = value.name

    @TypeConverter
    fun toAttendanceStatus(value: String): AttendanceStatus =
        runCatching { AttendanceStatus.valueOf(value) }.getOrDefault(AttendanceStatus.PENDING)

    @TypeConverter
    fun fromCalendarEventType(value: CalendarEventType): String = value.name

    @TypeConverter
    fun toCalendarEventType(value: String): CalendarEventType =
        runCatching { CalendarEventType.valueOf(value) }.getOrDefault(CalendarEventType.EVENT)

    @TypeConverter
    fun fromRotationPattern(value: RotationPattern?): String? = value?.name

    @TypeConverter
    fun toRotationPattern(value: String?): RotationPattern? =
        value?.let { runCatching { RotationPattern.valueOf(it) }.getOrNull() }

    @TypeConverter
    fun fromPreviousEntries(entries: List<PreviousLectureStatusEntry>): String =
        json.encodeToString(entries)

    @TypeConverter
    fun toPreviousEntries(raw: String): List<PreviousLectureStatusEntry> =
        runCatching { json.decodeFromString<List<PreviousLectureStatusEntry>>(raw) }.getOrDefault(emptyList())
}
