package com.collegecompanion.domain.engine

import com.collegecompanion.domain.model.AcademicCalendarConfig
import com.collegecompanion.domain.model.AcademicCalendarEvent
import com.collegecompanion.domain.model.AttendanceStatus
import com.collegecompanion.domain.model.CalendarEventType
import com.collegecompanion.domain.model.LectureInstance
import com.collegecompanion.domain.model.LectureType
import com.collegecompanion.domain.model.RotationPattern
import com.collegecompanion.domain.model.Subject
import com.collegecompanion.domain.model.TimetableSlot
import java.time.LocalDate
import java.time.LocalTime
import java.time.temporal.ChronoUnit

data class TimetableOverlapWarning(
    val dayOfWeekOrDate: String,
    val firstLectureSummary: String,
    val secondLectureSummary: String,
    val overlapMinutes: Long
)

/**
 * Date-based Timetable & Academic Calendar Mapping Engine (Part 8 & Part 10).
 * - Maps recurring weekday timetable slots onto concrete calendar dates across the semester.
 * - Excludes holidays, vacations, examination periods, and non-working days.
 * - Handles Special Working Saturdays and Timetable Override Days (e.g. a Saturday or Tuesday following Monday's timetable).
 * - Handles Rotating schedules (Every Week, Odd Weeks, Even Weeks, Rotation Set A/B).
 * - Preserves existing historical attendance records keyed by unique LectureInstance IDs when regenerating future schedules.
 * - Detects overlapping lectures on both recurring weekday templates and concrete dates.
 */
object TimetableGenerator {

    fun isDateWithinEvent(date: LocalDate, event: AcademicCalendarEvent): Boolean {
        val start = runCatching { LocalDate.parse(event.startDate) }.getOrNull() ?: return false
        val end = runCatching { LocalDate.parse(event.endDate) }.getOrNull() ?: return false
        return !date.isBefore(start) && !date.isAfter(end)
    }

    fun extractHolidayAndNoClassDates(
        calendarConfig: AcademicCalendarConfig,
        events: List<AcademicCalendarEvent>
    ): Set<LocalDate> {
        val start = LocalDate.parse(calendarConfig.semesterStartDate)
        val end = LocalDate.parse(calendarConfig.semesterEndDate)
        val noClassTypes = setOf(
            CalendarEventType.HOLIDAY,
            CalendarEventType.NON_WORKING_DAY,
            CalendarEventType.VACATION,
            CalendarEventType.EXAMINATION
        )
        val result = mutableSetOf<LocalDate>()
        var cursor = start
        while (!cursor.isAfter(end)) {
            val isBlocked = events.any { ev ->
                noClassTypes.contains(ev.eventType) && isDateWithinEvent(cursor, ev)
            }
            if (isBlocked) {
                result.add(cursor)
            }
            cursor = cursor.plusDays(1)
        }
        return result
    }

    /**
     * Generates concrete LectureInstances across [semesterStartDate, semesterEndDate] while preserving
     * any existing finalized or custom LectureInstances.
     */
    fun generateSemesterInstances(
        calendarConfig: AcademicCalendarConfig,
        subjects: List<Subject>,
        timetableSlots: List<TimetableSlot>,
        calendarEvents: List<AcademicCalendarEvent>,
        existingInstances: List<LectureInstance> = emptyList(),
        regenerateFromDate: LocalDate? = null
    ): List<LectureInstance> {
        val startDate = LocalDate.parse(calendarConfig.semesterStartDate)
        val endDate = LocalDate.parse(calendarConfig.semesterEndDate)
        val subjectMap = subjects.associateBy { it.id }
        val existingById = existingInstances.associateBy { it.id }

        // Keep all historical instances prior to regenerateFromDate untouched, plus any one-time/extra/rescheduled lectures
        val preservedInstances = mutableMapOf<String, LectureInstance>()
        for (existing in existingInstances) {
            val existingDate = runCatching { LocalDate.parse(existing.date) }.getOrNull()
            val shouldPreserve = existing.isOneTimeOrExtra ||
                existing.isRescheduled ||
                existing.attendanceStatus != AttendanceStatus.PENDING ||
                (regenerateFromDate != null && existingDate != null && existingDate.isBefore(regenerateFromDate))
            if (shouldPreserve) {
                preservedInstances[existing.id] = existing
            }
        }

        val generatedMap = LinkedHashMap<String, LectureInstance>()
        preservedInstances.forEach { (id, inst) -> generatedMap[id] = inst }

        val noClassDates = extractHolidayAndNoClassDates(calendarConfig, calendarEvents)

        var cursor = startDate
        while (!cursor.isAfter(endDate)) {
            if (regenerateFromDate != null && cursor.isBefore(regenerateFromDate)) {
                cursor = cursor.plusDays(1)
                continue
            }

            // Skip holidays, vacations, examination periods, and non-working days
            if (noClassDates.contains(cursor)) {
                cursor = cursor.plusDays(1)
                continue
            }

            // Check if there is a Special Working Saturday or Timetable Override Day event for this date
            val overrideEvent = calendarEvents.firstOrNull { ev ->
                (ev.eventType == CalendarEventType.SPECIAL_WORKING_SATURDAY ||
                    ev.eventType == CalendarEventType.TIMETABLE_OVERRIDE_DAY) &&
                    isDateWithinEvent(cursor, ev)
            }

            val effectiveDayOfWeek: Int? = when {
                overrideEvent != null -> overrideEvent.followsDayOfWeek ?: cursor.dayOfWeek.value
                calendarConfig.workingDaysOfWeek.contains(cursor.dayOfWeek.value) -> cursor.dayOfWeek.value
                else -> null
            }

            if (effectiveDayOfWeek != null) {
                val weekNumberSinceStart = (ChronoUnit.DAYS.between(startDate, cursor) / 7L).toInt() + 1
                val isOddWeek = (weekNumberSinceStart % 2) == 1

                val matchingSlots = timetableSlots.filter { slot ->
                    slot.isActive &&
                        slot.dayOfWeek == effectiveDayOfWeek &&
                        matchesRotation(slot.rotationPattern, isOddWeek, overrideEvent?.rotationSetOverride)
                }.sortedBy { it.startTime }

                for (slot in matchingSlots) {
                    val subject = subjectMap[slot.subjectId] ?: continue
                    val deterministicId = "${cursor}_${slot.id}"

                    // Never overwrite an already-recorded attendance decision
                    val existing = existingById[deterministicId]
                    if (existing != null && existing.attendanceStatus != AttendanceStatus.PENDING) {
                        generatedMap[deterministicId] = existing
                        continue
                    }

                    val instance = LectureInstance(
                        id = deterministicId,
                        subjectId = subject.id,
                        subjectName = subject.name,
                        subjectCode = subject.code,
                        subjectColorHex = subject.colorHex,
                        date = cursor.toString(),
                        startTime = slot.startTime,
                        endTime = slot.endTime,
                        roomNumber = slot.roomNumber.ifBlank { subject.defaultRoom },
                        labNumber = slot.labNumber.ifBlank { subject.defaultLab },
                        building = slot.building.ifBlank { subject.defaultBuilding },
                        floor = slot.floor.ifBlank { subject.defaultFloor },
                        professor = slot.professorOverride.ifBlank { subject.professor },
                        lectureType = slot.lectureType,
                        attendanceStatus = existing?.attendanceStatus ?: AttendanceStatus.PENDING,
                        isOneTimeOrExtra = false,
                        isRescheduled = false,
                        sourceSlotId = slot.id,
                        lastUpdatedEpochMillis = existing?.lastUpdatedEpochMillis ?: 0L
                    )
                    generatedMap[deterministicId] = instance
                }
            }

            // Also generate instances for any SPECIAL_LECTURE calendar events on this date
            val specialLectures = calendarEvents.filter { ev ->
                ev.eventType == CalendarEventType.SPECIAL_LECTURE && isDateWithinEvent(cursor, ev)
            }
            for (special in specialLectures) {
                val subject = special.subjectId?.let { subjectMap[it] }
                val specialId = "special_${cursor}_${special.id}"
                if (!generatedMap.containsKey(specialId)) {
                    generatedMap[specialId] = LectureInstance(
                        id = specialId,
                        subjectId = subject?.id ?: "SPECIAL_EVENT",
                        subjectName = subject?.name ?: special.title,
                        subjectCode = subject?.code ?: "SPL",
                        subjectColorHex = subject?.colorHex ?: "#8E24AA",
                        date = cursor.toString(),
                        startTime = special.startTime ?: "10:00",
                        endTime = special.endTime ?: "11:00",
                        roomNumber = special.location,
                        professor = subject?.professor ?: "",
                        lectureType = LectureType.EXTRA,
                        attendanceStatus = AttendanceStatus.PENDING,
                        isOneTimeOrExtra = true,
                        notes = special.description
                    )
                }
            }

            cursor = cursor.plusDays(1)
        }

        return generatedMap.values.sortedWith(
            compareBy<LectureInstance> { it.date }.thenBy { it.startTime }
        )
    }

    private fun matchesRotation(
        slotRotation: RotationPattern,
        isOddWeek: Boolean,
        overrideRotation: RotationPattern?
    ): Boolean {
        return when (slotRotation) {
            RotationPattern.EVERY_WEEK -> true
            RotationPattern.ODD_WEEKS -> isOddWeek
            RotationPattern.EVEN_WEEKS -> !isOddWeek
            RotationPattern.ROTATION_SET_A -> overrideRotation == RotationPattern.ROTATION_SET_A || (overrideRotation == null && isOddWeek)
            RotationPattern.ROTATION_SET_B -> overrideRotation == RotationPattern.ROTATION_SET_B || (overrideRotation == null && !isOddWeek)
        }
    }

    /**
     * Detects overlapping lectures in recurring TimetableSlots.
     */
    fun detectSlotOverlaps(
        slots: List<TimetableSlot>,
        subjects: Map<String, Subject>
    ): List<TimetableOverlapWarning> {
        val warnings = mutableListOf<TimetableOverlapWarning>()
        val activeSlotsByDay = slots.filter { it.isActive }.groupBy { it.dayOfWeek }

        for ((day, daySlots) in activeSlotsByDay) {
            val sorted = daySlots.sortedBy { it.startTime }
            for (i in 0 until sorted.size) {
                for (j in i + 1 until sorted.size) {
                    val a = sorted[i]
                    val b = sorted[j]
                    if (!rotationsCanCoexistWithoutOverlap(a.rotationPattern, b.rotationPattern)) {
                        val overlap = calculateOverlapMinutes(a.startTime, a.endTime, b.startTime, b.endTime)
                        if (overlap > 0) {
                            val subA = subjects[a.subjectId]?.name ?: a.subjectId
                            val subB = subjects[b.subjectId]?.name ?: b.subjectId
                            warnings.add(
                                TimetableOverlapWarning(
                                    dayOfWeekOrDate = dayName(day),
                                    firstLectureSummary = "$subA (${a.startTime}-${a.endTime})",
                                    secondLectureSummary = "$subB (${b.startTime}-${b.endTime})",
                                    overlapMinutes = overlap
                                )
                            )
                        }
                    }
                }
            }
        }
        return warnings
    }

    /**
     * Detects overlapping concrete LectureInstances on any date.
     */
    fun detectInstanceOverlaps(instances: List<LectureInstance>): List<TimetableOverlapWarning> {
        val warnings = mutableListOf<TimetableOverlapWarning>()
        val byDate = instances
            .filter { it.attendanceStatus != AttendanceStatus.CANCELLED }
            .groupBy { it.date }

        for ((date, dayInstances) in byDate) {
            val sorted = dayInstances.sortedBy { it.startTime }
            for (i in 0 until sorted.size) {
                for (j in i + 1 until sorted.size) {
                    val a = sorted[i]
                    val b = sorted[j]
                    val overlap = calculateOverlapMinutes(a.startTime, a.endTime, b.startTime, b.endTime)
                    if (overlap > 0) {
                        warnings.add(
                            TimetableOverlapWarning(
                                dayOfWeekOrDate = date,
                                firstLectureSummary = "${a.subjectName} (${a.startTime}-${a.endTime})",
                                secondLectureSummary = "${b.subjectName} (${b.startTime}-${b.endTime})",
                                overlapMinutes = overlap
                            )
                        )
                    }
                }
            }
        }
        return warnings
    }

    private fun rotationsCanCoexistWithoutOverlap(r1: RotationPattern, r2: RotationPattern): Boolean {
        return (r1 == RotationPattern.ODD_WEEKS && r2 == RotationPattern.EVEN_WEEKS) ||
            (r1 == RotationPattern.EVEN_WEEKS && r2 == RotationPattern.ODD_WEEKS) ||
            (r1 == RotationPattern.ROTATION_SET_A && r2 == RotationPattern.ROTATION_SET_B) ||
            (r1 == RotationPattern.ROTATION_SET_B && r2 == RotationPattern.ROTATION_SET_A)
    }

    fun calculateOverlapMinutes(startA: String, endA: String, startB: String, endB: String): Long {
        val sA = runCatching { LocalTime.parse(startA) }.getOrNull() ?: return 0L
        val eA = runCatching { LocalTime.parse(endA) }.getOrNull() ?: return 0L
        val sB = runCatching { LocalTime.parse(startB) }.getOrNull() ?: return 0L
        val eB = runCatching { LocalTime.parse(endB) }.getOrNull() ?: return 0L

        val latestStart = if (sA.isAfter(sB)) sA else sB
        val earliestEnd = if (eA.isBefore(eB)) eA else eB
        return if (latestStart.isBefore(earliestEnd)) {
            ChronoUnit.MINUTES.between(latestStart, earliestEnd)
        } else {
            0L
        }
    }

    fun dayName(dayOfWeek: Int): String = when (dayOfWeek) {
        1 -> "Monday"
        2 -> "Tuesday"
        3 -> "Wednesday"
        4 -> "Thursday"
        5 -> "Friday"
        6 -> "Saturday"
        7 -> "Sunday"
        else -> "Day $dayOfWeek"
    }
}
