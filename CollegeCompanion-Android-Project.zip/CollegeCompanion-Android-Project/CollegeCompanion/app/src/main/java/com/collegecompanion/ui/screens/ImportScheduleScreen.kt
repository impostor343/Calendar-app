package com.collegecompanion.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.collegecompanion.data.SampleInitialDataSeeder
import com.collegecompanion.domain.engine.ImportMode
import com.collegecompanion.domain.engine.ScheduleImportExportEngine
import com.collegecompanion.ui.theme.AttendanceAmber
import com.collegecompanion.ui.theme.AttendanceGreen
import com.collegecompanion.ui.theme.AttendanceRed
import com.collegecompanion.ui.viewmodel.MainViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ImportScheduleScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val validationReport by viewModel.importValidationReport.collectAsState()

    var selectedMode by remember { mutableStateOf(ImportMode.COMBINED_SCHEDULE) }
    var isCsvFormat by remember { mutableStateOf(false) }
    var rawInputText by remember { mutableStateOf("") }
    var overwriteExistingHistory by remember { mutableStateOf(false) }

    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val content = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            if (!content.isNullOrBlank()) {
                rawInputText = content
                isCsvFormat = content.trimStart().let { !it.startsWith("{") }
                viewModel.validateImportContent(content, selectedMode, isCsvFormat)
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Text(
                    text = "Import Schedule & Academic Calendar",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        item {
            ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("1. Choose Independent Import Mode:", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ImportMode.entries.forEach { mode ->
                            FilterChip(
                                selected = selectedMode == mode,
                                onClick = {
                                    selectedMode = mode
                                    viewModel.clearImportValidation()
                                },
                                label = { Text(mode.title) }
                            )
                        }
                    }

                    Text("2. Choose File Format:", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = !isCsvFormat,
                            onClick = { isCsvFormat = false },
                            label = { Text("JSON (Primary Structured Format)") }
                        )
                        FilterChip(
                            selected = isCsvFormat,
                            onClick = { isCsvFormat = true },
                            label = { Text("CSV Timetable") }
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { openDocumentLauncher.launch(arrayOf("*/*")) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.FolderOpen, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Select File (SAF)")
                        }
                        OutlinedButton(
                            onClick = {
                                val sampleJson = ScheduleImportExportEngine.exportToJson(
                                    SampleInitialDataSeeder.buildDefaultAcademicBundle()
                                )
                                rawInputText = sampleJson
                                isCsvFormat = false
                                viewModel.validateImportContent(sampleJson, selectedMode, false)
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Load Example JSON")
                        }
                    }

                    OutlinedTextField(
                        value = rawInputText,
                        onValueChange = {
                            rawInputText = it
                            viewModel.clearImportValidation()
                        },
                        label = { Text("Paste or inspect JSON / CSV content here") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    )

                    Button(
                        onClick = {
                            viewModel.validateImportContent(rawInputText, selectedMode, isCsvFormat)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Validate & Preview Import")
                    }
                }
            }
        }

        // Validation & Preview Card
        validationReport?.let { report ->
            item {
                ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (report.isValid) Icons.Default.CheckCircle else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (report.isValid) AttendanceGreen else AttendanceRed
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (report.isValid) "Validation Passed — Ready to Import" else "Validation Failed",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (report.isValid) AttendanceGreen else AttendanceRed
                            )
                        }

                        if (report.errors.isNotEmpty()) {
                            report.errors.forEach { err ->
                                Text("• Error: $err", color = AttendanceRed, style = MaterialTheme.typography.bodySmall)
                            }
                        }

                        if (report.warnings.isNotEmpty()) {
                            report.warnings.forEach { warn ->
                                Text("• Notice: $warn", color = AttendanceAmber, style = MaterialTheme.typography.bodySmall)
                            }
                        }

                        report.bundle?.let { b ->
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Import Preview Summary:", fontWeight = FontWeight.Bold)
                                    b.calendarConfig?.let { cfg ->
                                        Text("• Semester: ${cfg.semesterName} (${cfg.semesterStartDate} to ${cfg.semesterEndDate})")
                                    }
                                    Text("• Subjects: ${b.subjects.size}")
                                    Text("• Recurring Timetable Slots: ${b.timetableSlots.size}")
                                    Text("• Academic Calendar Events / Holidays: ${b.calendarEvents.size}")
                                    Text("• Existing Finalized Attendance Records Preserved: ${report.preservedAttendanceRecordsCount}")
                                }
                            }
                        }

                        if (selectedMode == ImportMode.FULL_BACKUP_RESTORE) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = overwriteExistingHistory,
                                    onCheckedChange = { overwriteExistingHistory = it }
                                )
                                Text(
                                    text = "Replace existing database completely (check only for full clean restore)",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }

                        if (report.isValid) {
                            Button(
                                onClick = {
                                    viewModel.confirmAndApplyImport(
                                        mode = selectedMode,
                                        overwriteHistory = overwriteExistingHistory
                                    )
                                    onBack()
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Confirm & Save Import")
                            }
                        }
                    }
                }
            }
        }
    }
}
