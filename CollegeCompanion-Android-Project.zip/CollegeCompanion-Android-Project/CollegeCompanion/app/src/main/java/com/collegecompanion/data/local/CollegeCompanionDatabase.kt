package com.collegecompanion.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.collegecompanion.data.local.dao.AttendanceAuditDao
import com.collegecompanion.data.local.dao.CalendarEventDao
import com.collegecompanion.data.local.dao.LectureInstanceDao
import com.collegecompanion.data.local.dao.SubjectDao
import com.collegecompanion.data.local.dao.TimetableSlotDao
import com.collegecompanion.data.local.entity.AcademicCalendarEventEntity
import com.collegecompanion.data.local.entity.AttendanceAuditLogEntity
import com.collegecompanion.data.local.entity.BulkAbsenceOperationEntity
import com.collegecompanion.data.local.entity.LectureInstanceEntity
import com.collegecompanion.data.local.entity.SubjectEntity
import com.collegecompanion.data.local.entity.TimetableSlotEntity

@Database(
    entities = [
        SubjectEntity::class,
        TimetableSlotEntity::class,
        LectureInstanceEntity::class,
        AcademicCalendarEventEntity::class,
        AttendanceAuditLogEntity::class,
        BulkAbsenceOperationEntity::class
    ],
    version = 2,
    exportSchema = true
)
@TypeConverters(RoomConverters::class)
abstract class CollegeCompanionDatabase : RoomDatabase() {

    abstract fun subjectDao(): SubjectDao
    abstract fun timetableSlotDao(): TimetableSlotDao
    abstract fun lectureInstanceDao(): LectureInstanceDao
    abstract fun calendarEventDao(): CalendarEventDao
    abstract fun attendanceAuditDao(): AttendanceAuditDao

    companion object {
        private const val DB_NAME = "college_companion_db"

        /**
         * Explicit Room Database Migration from v1 to v2 ensuring historical attendance
         * and user customizations survive schema upgrades without destructive fallback.
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS `index_lecture_instances_date_subjectId` ON `lecture_instances` (`date`, `subjectId`)"
                )
            }
        }

        @Volatile
        private var INSTANCE: CollegeCompanionDatabase? = null

        fun getInstance(context: Context): CollegeCompanionDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    CollegeCompanionDatabase::class.java,
                    DB_NAME
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
