package com.collegecompanion.notification

import android.app.AlarmManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.collegecompanion.data.local.CollegeCompanionDatabase
import com.collegecompanion.data.preferences.PreferencesDataStore
import com.collegecompanion.data.repository.CollegeRepository
import com.collegecompanion.widget.WidgetRefreshManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Handles device boot, time/timezone changes, exact alarm permission changes, and midnight date rollovers.
 * Reschedules all upcoming lecture notifications and refreshes all Jetpack Glance home-screen widgets.
 */
class BootAndTimeChangeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val validActions = setOf(
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED,
            LectureReminderScheduler.ACTION_MIDNIGHT_DATE_ROLLOVER
        )
        if (intent.action !in validActions) return

        val pendingResult = goAsync()
        val appContext = context.applicationContext
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val database = CollegeCompanionDatabase.getInstance(appContext)
                val prefsStore = PreferencesDataStore(appContext)
                val repository = CollegeRepository(appContext, database, prefsStore)

                repository.rescheduleUpcomingReminders()
                WidgetRefreshManager.refreshAllWidgets(appContext)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
