package com.collegecompanion.domain.engine

import com.collegecompanion.domain.model.AttendanceStatus
import com.collegecompanion.domain.model.AttendanceWarningLevel
import com.collegecompanion.domain.model.LectureInstance
import com.collegecompanion.domain.model.ProjectedAttendanceResult
import com.collegecompanion.domain.model.ProjectionScenarioType
import com.collegecompanion.domain.model.Subject
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import kotlin.math.max
import kotlin.math.min

/**
 * Projected Attendance Engine implementing Part 7 specifications:
 * - Strictly separate from Current Attendance.
 * - Formula: (A + F) / (T + F + M) * 100
 *   where:
 *   A = currently attended lectures
 *   T = currently finalized lectures (attended + absent)
 *   F = future lectures projected to be attended
 *   M = future lectures projected to be missed
 * - Excludes holidays, cancelled lectures, and dates outside the active semester.
 * - Supports all 7 interactive projection scenarios without mutating actual attendance records.
 */
object ProjectedAttendanceEngine {

    /**
     * Computes projected attendance given explicit counts (A, T, F, M).
     */
    fun computeProjectedPercentage(
        currentAttended: Int,
        currentFinalized: Int,
        futureAttended: Int,
        futureMissed: Int
    ): Double {
        val denominator = currentFinalized + futureAttended + futureMissed
        if (denominator <= 0) return 100.0
        val numerator = currentAttended + futureAttended
        val raw = (numerator.toDouble() / denominator.toDouble()) * 100.0
        return BigDecimal.valueOf(raw).setScale(2, RoundingMode.HALF_UP).toDouble()
    }

    /**
     * Filters valid future scheduled lectures in the active semester (date > currentDate and <= semesterEndDate),
     * excluding holidays and cancelled lectures, sorted chronologically.
     */
    fun getValidFutureLectures(
        instances: List<LectureInstance>,
        currentDate: LocalDate,
        semesterStartDate: LocalDate,
        semesterEndDate: LocalDate,
        holidayDates: Set<LocalDate> = emptySet(),
        subjectIdFilter: String? = null
    ): List<LectureInstance> {
        return instances.filter { instance ->
            if (subjectIdFilter != null && instance.subjectId != subjectIdFilter) return@filter false
            if (instance.attendanceStatus == AttendanceStatus.CANCELLED) return@filter false
            val date = runCatching { LocalDate.parse(instance.date) }.getOrNull() ?: return@filter false
            val withinSemester = !date.isBefore(semesterStartDate) && !date.isAfter(semesterEndDate)
            val isFuture = date.isAfter(currentDate)
            val notHoliday = !holidayDates.contains(date)
            withinSemester && isFuture && notHoliday
        }.sortedWith(compareBy<LectureInstance> { it.date }.thenBy { it.startTime })
    }

    /**
     * Resolves (F, M) for any of the 7 required projection scenarios.
     *
     * @param scenario The selected ProjectionScenarioType (Scenarios 1..7)
     * @param futureLectures Chronologically sorted list of valid future lectures
     * @param customCount Used by Scenario 5 (miss K upcoming lectures) or Scenario 7 (attend N upcoming lectures)
     * @param specificMissedLectureIds Used by Scenario 6 (set of future lecture IDs projected to be missed)
     * @param evaluateImmediateHorizonOnly When true for Scenarios 2..5, projects right after those next K missed lectures (F=0, M=K);
     *                                     when false (default semester projection), assumes remaining future lectures are attended (F = totalFuture - K, M = K).
     */
    fun resolveFutureCounts(
        scenario: ProjectionScenarioType,
        futureLectures: List<LectureInstance>,
        customCount: Int = 1,
        specificMissedLectureIds: Set<String> = emptySet(),
        evaluateImmediateHorizonOnly: Boolean = false
    ): Pair<Int, Int> {
        val totalFuture = futureLectures.size
        if (totalFuture == 0) return 0 to 0

        return when (scenario) {
            ProjectionScenarioType.ATTEND_ALL -> {
                totalFuture to 0
            }
            ProjectionScenarioType.MISS_NEXT_1 -> {
                val m = min(1, totalFuture)
                val f = if (evaluateImmediateHorizonOnly) 0 else (totalFuture - m)
                f to m
            }
            ProjectionScenarioType.MISS_NEXT_2 -> {
                val m = min(2, totalFuture)
                val f = if (evaluateImmediateHorizonOnly) 0 else (totalFuture - m)
                f to m
            }
            ProjectionScenarioType.MISS_NEXT_3 -> {
                val m = min(3, totalFuture)
                val f = if (evaluateImmediateHorizonOnly) 0 else (totalFuture - m)
                f to m
            }
            ProjectionScenarioType.MISS_CUSTOM_COUNT -> {
                val m = customCount.coerceIn(0, totalFuture)
                val f = if (evaluateImmediateHorizonOnly) 0 else (totalFuture - m)
                f to m
            }
            ProjectionScenarioType.SELECT_SPECIFIC_FUTURE -> {
                val missedCount = futureLectures.count { specificMissedLectureIds.contains(it.id) }
                val attendedCount = totalFuture - missedCount
                attendedCount to missedCount
            }
            ProjectionScenarioType.ATTEND_SELECTED_COUNT -> {
                val f = customCount.coerceIn(0, totalFuture)
                val m = totalFuture - f
                f to m
            }
        }
    }

    fun simulateSubjectProjection(
        subject: Subject,
        allInstances: List<LectureInstance>,
        currentDate: LocalDate,
        semesterStartDate: LocalDate,
        semesterEndDate: LocalDate,
        holidayDates: Set<LocalDate> = emptySet(),
        scenario: ProjectionScenarioType = ProjectionScenarioType.ATTEND_ALL,
        customCount: Int = 1,
        specificMissedLectureIds: Set<String> = emptySet(),
        evaluateImmediateHorizonOnly: Boolean = false,
        globalRequiredPercentage: Double = 70.0,
        globalWarningPercentage: Double = 75.0
    ): ProjectedAttendanceResult {
        val currentSummary = AttendanceEngine.calculateSubjectAttendance(
            subject = subject,
            instances = allInstances,
            semesterStartDate = semesterStartDate,
            semesterEndDate = semesterEndDate,
            currentDate = currentDate,
            holidayDates = holidayDates,
            globalRequiredPercentage = globalRequiredPercentage,
            globalWarningPercentage = globalWarningPercentage
        )

        val futureLectures = getValidFutureLectures(
            instances = allInstances,
            currentDate = currentDate,
            semesterStartDate = semesterStartDate,
            semesterEndDate = semesterEndDate,
            holidayDates = holidayDates,
            subjectIdFilter = subject.id
        )

        val (f, m) = resolveFutureCounts(
            scenario = scenario,
            futureLectures = futureLectures,
            customCount = customCount,
            specificMissedLectureIds = specificMissedLectureIds,
            evaluateImmediateHorizonOnly = evaluateImmediateHorizonOnly
        )

        val projectedPercentage = computeProjectedPercentage(
            currentAttended = currentSummary.attendedCount,
            currentFinalized = currentSummary.totalFinalizedCount,
            futureAttended = f,
            futureMissed = m
        )

        val projectedAttendedTotal = currentSummary.attendedCount + f
        val projectedAbsentTotal = currentSummary.absentCount + m
        val required = currentSummary.requiredPercentage
        val projectedSafeAbsences = AttendanceEngine.calculateSafeAbsences(
            attended = projectedAttendedTotal,
            absent = projectedAbsentTotal,
            requiredPercentage = required
        )
        val warningLevel = AttendanceEngine.resolveWarningLevel(
            attended = projectedAttendedTotal,
            absent = projectedAbsentTotal,
            requiredPercentage = required,
            warningThresholdPercentage = currentSummary.warningThresholdPercentage
        )

        return ProjectedAttendanceResult(
            subjectId = subject.id,
            label = subject.name,
            currentAttended = currentSummary.attendedCount,
            currentFinalized = currentSummary.totalFinalizedCount,
            currentPercentage = currentSummary.currentPercentage,
            futureTotalScheduled = futureLectures.size,
            futureProjectedAttended = f,
            futureProjectedMissed = m,
            projectedPercentage = projectedPercentage,
            requiredPercentage = required,
            currentSafeAbsences = currentSummary.safeAbsences,
            projectedSafeAbsences = projectedSafeAbsences,
            dropsBelowThreshold = warningLevel == AttendanceWarningLevel.CRITICAL,
            warningLevel = warningLevel
        )
    }

    fun simulateOverallProjection(
        subjects: List<Subject>,
        allInstances: List<LectureInstance>,
        currentDate: LocalDate,
        semesterStartDate: LocalDate,
        semesterEndDate: LocalDate,
        holidayDates: Set<LocalDate> = emptySet(),
        scenario: ProjectionScenarioType = ProjectionScenarioType.ATTEND_ALL,
        customCount: Int = 1,
        specificMissedLectureIds: Set<String> = emptySet(),
        evaluateImmediateHorizonOnly: Boolean = false,
        globalRequiredPercentage: Double = 70.0,
        globalWarningPercentage: Double = 75.0
    ): ProjectedAttendanceResult {
        val overallCurrent = AttendanceEngine.calculateOverallAttendance(
            subjects = subjects,
            instances = allInstances,
            semesterStartDate = semesterStartDate,
            semesterEndDate = semesterEndDate,
            currentDate = currentDate,
            holidayDates = holidayDates,
            globalRequiredPercentage = globalRequiredPercentage,
            globalWarningPercentage = globalWarningPercentage
        )

        val validSubjectIds = subjects.map { it.id }.toSet()
        val futureLectures = getValidFutureLectures(
            instances = allInstances.filter { validSubjectIds.contains(it.subjectId) },
            currentDate = currentDate,
            semesterStartDate = semesterStartDate,
            semesterEndDate = semesterEndDate,
            holidayDates = holidayDates,
            subjectIdFilter = null
        )

        val (f, m) = resolveFutureCounts(
            scenario = scenario,
            futureLectures = futureLectures,
            customCount = customCount,
            specificMissedLectureIds = specificMissedLectureIds,
            evaluateImmediateHorizonOnly = evaluateImmediateHorizonOnly
        )

        val projectedPercentage = computeProjectedPercentage(
            currentAttended = overallCurrent.totalAttended,
            currentFinalized = overallCurrent.totalFinalized,
            futureAttended = f,
            futureMissed = m
        )

        val projectedAttendedTotal = overallCurrent.totalAttended + f
        val projectedAbsentTotal = overallCurrent.totalAbsent + m
        val projectedSafeAbsences = AttendanceEngine.calculateSafeAbsences(
            attended = projectedAttendedTotal,
            absent = projectedAbsentTotal,
            requiredPercentage = globalRequiredPercentage
        )
        val warningLevel = AttendanceEngine.resolveWarningLevel(
            attended = projectedAttendedTotal,
            absent = projectedAbsentTotal,
            requiredPercentage = globalRequiredPercentage,
            warningThresholdPercentage = globalWarningPercentage
        )

        return ProjectedAttendanceResult(
            subjectId = null,
            label = "Overall Semester Projection",
            currentAttended = overallCurrent.totalAttended,
            currentFinalized = overallCurrent.totalFinalized,
            currentPercentage = overallCurrent.currentPercentage,
            futureTotalScheduled = futureLectures.size,
            futureProjectedAttended = f,
            futureProjectedMissed = m,
            projectedPercentage = projectedPercentage,
            requiredPercentage = globalRequiredPercentage,
            currentSafeAbsences = overallCurrent.overallSafeAbsences,
            projectedSafeAbsences = projectedSafeAbsences,
            dropsBelowThreshold = warningLevel == AttendanceWarningLevel.CRITICAL,
            warningLevel = warningLevel
        )
    }
}
