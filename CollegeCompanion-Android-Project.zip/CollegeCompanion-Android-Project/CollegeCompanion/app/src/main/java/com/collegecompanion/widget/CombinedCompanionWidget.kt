package com.collegecompanion.widget

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.lazy.LazyColumn
import androidx.glance.appwidget.lazy.items
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.collegecompanion.MainActivity
import com.collegecompanion.domain.model.AttendanceWarningLevel

/**
 * Widget C: Combined Timetable & Attendance (Part 4 & Part 7.E).
 * Combines:
 * - Today's timetable & COMPLETE ABSENT button
 * - Individual lecture ATTENDED / ABSENT controls
 * - Bottom dashboard displaying CURRENT Attendance, PROJECTED Attendance (clearly labeled), and Safe Absences.
 */
class CombinedCompanionWidget : GlanceAppWidget() {

    override val sizeMode: SizeMode = SizeMode.Responsive(
        setOf(
            DpSize(280.dp, 220.dp),
            DpSize(340.dp, 300.dp),
            DpSize(400.dp, 380.dp)
        )
    )

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val snapshot = WidgetSnapshotLoader.loadSnapshot(context)
        provideContent {
            GlanceTheme {
                CombinedCompanionWidgetContent(context = context, snapshot = snapshot)
            }
        }
    }
}

@Composable
fun CombinedCompanionWidgetContent(
    context: Context,
    snapshot: WidgetDataSnapshot
) {
    val containerBg = ColorProvider(Color(0xFF0F172A))
    val headerBg = ColorProvider(Color(0xFF1E293B))
    val blueCardBg = ColorProvider(Color(0xFF1E3A8A))
    val textWhite = ColorProvider(Color(0xFFF8FAFC))
    val textMuted = ColorProvider(Color(0xFF94A3B8))

    val completeAbsentIntent = Intent(context, CompleteDayAbsentActivity::class.java).apply {
        putExtra(CompleteDayAbsentActivity.EXTRA_TARGET_DATE, snapshot.currentDate.toString())
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }
    val openAppIntent = Intent(context, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(containerBg)
            .cornerRadius(22.dp)
            .padding(12.dp)
    ) {
        // Header Row
        Row(
            modifier = GlanceModifier
                .fillMaxWidth()
                .background(headerBg)
                .cornerRadius(14.dp)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = GlanceModifier
                    .defaultWeight()
                    .clickable(actionStartActivity(openAppIntent))
            ) {
                Text(
                    text = "${snapshot.dayOfWeekShort}, ${snapshot.dayOfMonthNumber} • Timetable & Attendance",
                    style = TextStyle(color = textWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "${snapshot.todayLectures.size} lecture(s) today",
                    style = TextStyle(color = textMuted, fontSize = 10.sp)
                )
            }
            if (!snapshot.isHolidayToday && snapshot.todayLectures.isNotEmpty()) {
                Box(
                    modifier = GlanceModifier
                        .background(ColorProvider(Color(0xFFB91C1C)))
                        .cornerRadius(8.dp)
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                        .clickable(actionStartActivity(completeAbsentIntent))
                ) {
                    Text(
                        text = "COMPLETE ABSENT",
                        style = TextStyle(color = textWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    )
                }
            }
        }

        Spacer(modifier = GlanceModifier.height(8.dp))

        // Lectures Area
        if (snapshot.todayLectures.isEmpty()) {
            Box(
                modifier = GlanceModifier
                    .fillMaxWidth()
                    .defaultWeight()
                    .background(headerBg)
                    .cornerRadius(14.dp)
                    .padding(16.dp)
                    .clickable(actionStartActivity(openAppIntent)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (snapshot.isHolidayToday) {
                        snapshot.holidayTitle ?: "Holiday — Nothing scheduled"
                    } else {
                        "Nothing scheduled"
                    },
                    style = TextStyle(color = textMuted, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                )
            }
        } else {
            LazyColumn(
                modifier = GlanceModifier
                    .fillMaxWidth()
                    .defaultWeight()
            ) {
                items(snapshot.todayLectures, itemId = { it.id.hashCode().toLong() }) { lecture ->
                    Column(modifier = GlanceModifier.fillMaxWidth().padding(bottom = 8.dp)) {
                        WidgetLectureCard(lecture = lecture, blueCardBg = blueCardBg)
                    }
                }
            }
        }

        Spacer(modifier = GlanceModifier.height(6.dp))

        // Bottom Dual Attendance Footer (Current vs Projected clearly labeled + Safe Absences)
        val att = snapshot.overallAttendance
        val proj = snapshot.projectedAttendance
        val currentColor = when (att.warningLevel) {
            AttendanceWarningLevel.CRITICAL -> ColorProvider(Color(0xFFEF4444))
            AttendanceWarningLevel.WARNING -> ColorProvider(Color(0xFFF59E0B))
            AttendanceWarningLevel.COMFORTABLE -> ColorProvider(Color(0xFF22C55E))
            AttendanceWarningLevel.NEUTRAL -> ColorProvider(Color(0xFF60A5FA))
        }

        Row(
            modifier = GlanceModifier
                .fillMaxWidth()
                .background(headerBg)
                .cornerRadius(14.dp)
                .padding(horizontal = 12.dp, vertical = 8.dp)
                .clickable(actionStartActivity(openAppIntent)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = GlanceModifier.defaultWeight()) {
                Text(
                    text = "Current (Actual): ${String.format("%.2f", att.currentPercentage)}%",
                    style = TextStyle(color = currentColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Projected (If Attend All): ${String.format("%.2f", proj.projectedPercentage)}%",
                    style = TextStyle(color = textMuted, fontSize = 10.sp)
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "Safe Absences: ${att.overallSafeAbsences}",
                    style = TextStyle(color = textWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "${att.totalAttended}/${att.totalFinalized} finalized",
                    style = TextStyle(color = textMuted, fontSize = 10.sp)
                )
            }
        }
    }
}

class CombinedCompanionWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = CombinedCompanionWidget()
}
