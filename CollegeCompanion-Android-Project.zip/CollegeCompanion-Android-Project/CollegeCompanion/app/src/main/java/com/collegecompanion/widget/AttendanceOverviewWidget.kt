package com.collegecompanion.widget

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.lazy.LazyColumn
import androidx.glance.appwidget.lazy.items
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.collegecompanion.MainActivity
import com.collegecompanion.domain.model.AttendanceWarningLevel

/**
 * Widget B: Attendance Overview (Part 4).
 * Displays:
 * - Overall attendance percentage
 * - Attended lectures, Absent lectures, Safe absences, Attendance threshold
 * - Red alert styling when attendance falls below the required percentage
 * - Individual subject percentages & safe/recovery counts
 */
class AttendanceOverviewWidget : GlanceAppWidget() {

    override val sizeMode: SizeMode = SizeMode.Responsive(
        setOf(
            DpSize(180.dp, 140.dp),
            DpSize(260.dp, 220.dp),
            DpSize(340.dp, 320.dp)
        )
    )

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val snapshot = WidgetSnapshotLoader.loadSnapshot(context)
        provideContent {
            GlanceTheme {
                AttendanceOverviewWidgetContent(context = context, snapshot = snapshot)
            }
        }
    }
}

@Composable
fun AttendanceOverviewWidgetContent(
    context: Context,
    snapshot: WidgetDataSnapshot
) {
    val att = snapshot.overallAttendance
    val isBelowThreshold = att.warningLevel == AttendanceWarningLevel.CRITICAL

    val rootBg = if (isBelowThreshold) {
        ColorProvider(Color(0xFF450A0A)) // Red alert background when overall < threshold
    } else {
        ColorProvider(Color(0xFF0F172A))
    }
    val cardBg = if (isBelowThreshold) {
        ColorProvider(Color(0xFF7F1D1D))
    } else {
        ColorProvider(Color(0xFF1E293B))
    }
    val textWhite = ColorProvider(Color(0xFFF8FAFC))
    val textMuted = ColorProvider(Color(0xFFCBD5E1))

    val pctColor = when (att.warningLevel) {
        AttendanceWarningLevel.CRITICAL -> ColorProvider(Color(0xFFFCA5A5))
        AttendanceWarningLevel.WARNING -> ColorProvider(Color(0xFFFCD34D))
        AttendanceWarningLevel.COMFORTABLE -> ColorProvider(Color(0xFF4ADE80))
        AttendanceWarningLevel.NEUTRAL -> ColorProvider(Color(0xFF60A5FA))
    }

    val openAttendanceIntent = Intent(context, MainActivity::class.java).apply {
        putExtra("initial_tab", "attendance")
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(rootBg)
            .cornerRadius(22.dp)
            .padding(12.dp)
            .clickable(actionStartActivity(openAttendanceIntent))
    ) {
        // Header Summary Card
        Column(
            modifier = GlanceModifier
                .fillMaxWidth()
                .background(cardBg)
                .cornerRadius(16.dp)
                .padding(12.dp)
        ) {
            Row(
                modifier = GlanceModifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = GlanceModifier.defaultWeight()) {
                    Text(
                        text = "CURRENT ATTENDANCE",
                        style = TextStyle(color = textMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "${String.format("%.2f", att.currentPercentage)}%",
                        style = TextStyle(color = pctColor, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Target: ${att.globalRequiredPercentage.toInt()}%",
                        style = TextStyle(color = textWhite, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    )
                    Text(
                        text = if (att.overallRecoveryLecturesNeeded > 0) {
                            "Need +${att.overallRecoveryLecturesNeeded} to recover"
                        } else {
                            "Safe Absences: ${att.overallSafeAbsences}"
                        },
                        style = TextStyle(color = pctColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    )
                }
            }

            Spacer(modifier = GlanceModifier.height(6.dp))

            Row(modifier = GlanceModifier.fillMaxWidth()) {
                Text(
                    text = "Attended: ${att.totalAttended}  •  Absent: ${att.totalAbsent}  •  Pending: ${att.totalPendingPast}",
                    style = TextStyle(color = textMuted, fontSize = 11.sp)
                )
            }

            if (att.subjectsBelowThresholdCount > 0) {
                Spacer(modifier = GlanceModifier.height(4.dp))
                Text(
                    text = "⚠ ${att.subjectsBelowThresholdCount} subject(s) below ${att.globalRequiredPercentage.toInt()}% threshold",
                    style = TextStyle(
                        color = ColorProvider(Color(0xFFFCA5A5)),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        Spacer(modifier = GlanceModifier.height(8.dp))

        // Individual Subject Rows
        LazyColumn(
            modifier = GlanceModifier
                .fillMaxWidth()
                .defaultWeight()
        ) {
            items(att.subjectSummaries, itemId = { it.subject.id.hashCode().toLong() }) { subSummary ->
                val subBelow = subSummary.warningLevel == AttendanceWarningLevel.CRITICAL
                val rowBg = if (subBelow) {
                    ColorProvider(Color(0xFF7F1D1D))
                } else {
                    ColorProvider(Color(0xFF1E293B))
                }
                val subPctColor = when (subSummary.warningLevel) {
                    AttendanceWarningLevel.CRITICAL -> ColorProvider(Color(0xFFF87171))
                    AttendanceWarningLevel.WARNING -> ColorProvider(Color(0xFFFBBF24))
                    AttendanceWarningLevel.COMFORTABLE -> ColorProvider(Color(0xFF4ADE80))
                    AttendanceWarningLevel.NEUTRAL -> textWhite
                }

                Column(modifier = GlanceModifier.fillMaxWidth().padding(bottom = 6.dp)) {
                    Row(
                        modifier = GlanceModifier
                            .fillMaxWidth()
                            .background(rowBg)
                            .cornerRadius(12.dp)
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = GlanceModifier.defaultWeight()) {
                            Text(
                                text = subSummary.subject.name,
                                style = TextStyle(color = textWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "${subSummary.attendedCount}/${subSummary.totalFinalizedCount} • " +
                                    if (subSummary.recoveryLecturesNeeded > 0) {
                                        "Recover: +${subSummary.recoveryLecturesNeeded}"
                                    } else {
                                        "Safe: ${subSummary.safeAbsences}"
                                    },
                                style = TextStyle(color = textMuted, fontSize = 10.sp)
                            )
                        }
                        Text(
                            text = "${String.format("%.1f", subSummary.currentPercentage)}%",
                            style = TextStyle(color = subPctColor, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }
    }
}

class AttendanceOverviewWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = AttendanceOverviewWidget()
}
