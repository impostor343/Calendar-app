package com.collegecompanion.data.repository

import android.content.Context
import androidx.room.withTransaction
import com.collegecompanion.data.local.CollegeCompanionDatabase
import com.collegecompanion.data.local.entity.AcademicCalendarEventEntity
import com.collegecompanion.data.local.entity.AttendanceAuditLogEntity
import com.collegecompanion.data.local.entity.BulkAbsenceOperationEntity
import com.collegecompanion.data.local.entity.LectureInstanceEntity
import com.collegecompanion.data.local.entity.SubjectEntity
import com.collegecompanion.data.local.entity.TimetableSlotEntity
import com.collegecompanion.data.preferences.PreferencesDataStore
import com.collegecompanion.domain.engine.AcademicScheduleBundle
import com.collegecompanion.domain.engine.ImportMode
import com.collegecompanion.domain.engine.ScheduleImportExportEngine
import com.collegecompanion.domain.engine.TimetableGenerator
import com.collegecompanion.domain.model.AcademicCalendarConfig
import com.collegecompanion.domain.model.AcademicCalendarEvent
import com.collegecompanion.domain.model.AttendanceStatus
import com.collegecompanion.domain.model.BulkAbsenceOperationRecord
import com.collegecompanion.domain.model.CalendarEventType
import com.collegecompanion.domain.model.LectureInstance
import com.collegecompanion.domain.model.PreviousLectureStatusEntry
import com.collegecompanion.domain.model.Subject
import com.collegecompanion.domain.model.TimetableSlot
import com.collegecompanion.notification.LectureReminderScheduler
import com.collegecompanion.widget.WidgetRefreshManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.time.LocalDate
import java.util.UUID

data class CompleteDayAbsentPreview(
    val date: String,
    val isHoliday: Boolean,
    val isFutureDate: Boolean,
    val applicableLectures: List<LectureInstance>,
    val previouslyAttendedLectures: List<LectureInstance>,
    val canProceed: Boolean,
    val blockingReason: String? = null
)

class CollegeRepository(
    private val appContext: Context,
    private val database: CollegeCompanionDatabase,
    val preferencesDataStore: PreferencesDataStore
) {
    private val subjectDao = database.subjectDao()
    private val slotDao = database.timetableSlotDao()
    private val instanceDao = database.lectureInstanceDao()
    private val eventDao = database.calendarEventDao()
    private val auditDao = database.attendanceAuditDao()

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    val subjectsFlow: Flow<List<Subject>> = subjectDao.observeAllSubjects().map { list ->
        list.map { it.toDomain() }
    }

    val timetableSlotsFlow: Flow<List<TimetableSlot>> = slotDao.observeAllSlots().map { list ->
        list.map { it.toDomain() }
    }

    val lectureInstancesFlow: Flow<List<LectureInstance>> = instanceDao.observeAllInstances().map { list ->
        list.map { it.toDomain() }
    }

    val calendarEventsFlow: Flow<List<AcademicCalendarEvent>> = eventDao.observeAllEvents().map { list ->
        list.map { it.toDomain() }
    }

    val auditLogFlow = auditDao.observeRecentAuditLogs()

    val bulkOperationsFlow: Flow<List<BulkAbsenceOperationRecord>> =
        auditDao.observeBulkOperations().map { list ->
            list.map { entity ->
                BulkAbsenceOperationRecord(
                    operationId = entity.operationId,
                    targetDate = entity.targetDate,
                    timestampEpochMillis = entity.timestampEpochMillis,
                    affectedLectures = runCatching {
                        json.decodeFromString<List<PreviousLectureStatusEntry>>(entity.affectedLecturesJson)
                    }.getOrDefault(emptyList()),
                    wasUndone = entity.wasUndone
                )
            }
        }

    fun observeInstancesForDate(date: String): Flow<List<LectureInstance>> =
        instanceDao.observeInstancesForDate(date).map { list -> list.map { it.toDomain() } }

    /**
     * Marks or updates the attendance status of a single LectureInstance transactionally.
     * Prevents duplicate audit entries if the status is already identical (idempotent on rapid double-clicks),
     * persists the change to Room, refreshes all Jetpack Glance home-screen widgets, and updates reminders.
     */
    suspend fun markLectureAttendance(
        lectureInstanceId: String,
        newStatus: AttendanceStatus,
        source: String = "APP"
    ): Boolean {
        var changed = false
        database.withTransaction {
            val existing = instanceDao.getInstanceById(lectureInstanceId) ?: return@withTransaction
            if (existing.attendanceStatus == newStatus) {
                // Idempotent duplicate click protection
                return@withTransaction
            }
            val now = System.currentTimeMillis()
            val updated = existing.copy(
                attendanceStatus = newStatus,
                lastUpdatedEpochMillis = now
            )
            instanceDao.upsertInstance(updated)
            auditDao.insertAuditLog(
                AttendanceAuditLogEntity(
                    lectureInstanceId = existing.id,
                    subjectId = existing.subjectId,
                    subjectName = existing.subjectName,
                    lectureDate = existing.date,
                    startTime = existing.startTime,
                    previousStatus = existing.attendanceStatus,
                    newStatus = newStatus,
                    source = source,
                    timestampEpochMillis = now
                )
            )
            changed = true
        }
        if (changed) {
            WidgetRefreshManager.refreshAllWidgets(appContext)
            rescheduleUpcomingReminders()
        }
        return changed
    }

    /**
     * Builds a preview for the "COMPLETE ABSENT" bulk action on a given date (Part 5.B).
     * Verifies:
     * - Target date is not in the future (cannot bulk-mark future dates absent).
     * - Target date is not a holiday.
     * - Cancelled lectures are excluded.
     * - Identifies any lectures currently marked ATTENDED so the user can be explicitly warned before overwriting.
     */
    suspend fun previewCompleteDayAbsent(
        targetDate: LocalDate,
        currentLocalDate: LocalDate = LocalDate.now()
    ): CompleteDayAbsentPreview {
        val dateStr = targetDate.toString()
        val prefs = preferencesDataStore.getPreferencesSnapshot()
        val calendarConfig = AcademicCalendarConfig(
            semesterName = prefs.semesterName,
            semesterStartDate = prefs.semesterStartDate,
            semesterEndDate = prefs.semesterEndDate,
            workingDaysOfWeek = prefs.workingDaysOfWeek
        )
        val events = eventDao.getAllEvents().map { it.toDomain() }
        val holidays = TimetableGenerator.extractHolidayAndNoClassDates(calendarConfig, events)

        val isFuture = targetDate.isAfter(currentLocalDate)
        val isHoliday = holidays.contains(targetDate)

        val dayInstances = instanceDao.getInstancesForDate(dateStr).map { it.toDomain() }
        val applicable = dayInstances.filter { it.attendanceStatus != AttendanceStatus.CANCELLED }
        val previouslyAttended = applicable.filter { it.attendanceStatus == AttendanceStatus.ATTENDED }

        val blockingReason = when {
            isFuture -> "Cannot mark complete-day absence for a future date ($dateStr)."
            isHoliday -> "$dateStr is a holiday or non-working day."
            applicable.isEmpty() -> "No active lectures scheduled on $dateStr."
            else -> null
        }

        return CompleteDayAbsentPreview(
            date = dateStr,
            isHoliday = isHoliday,
            isFutureDate = isFuture,
            applicableLectures = applicable,
            previouslyAttendedLectures = previouslyAttended,
            canProceed = blockingReason == null,
            blockingReason = blockingReason
        )
    }

    /**
     * Executes the "COMPLETE ABSENT" bulk operation transactionally (Part 5.B).
     * - Does not modify future lectures, cancelled lectures, or holidays.
     * - If pressed repeatedly when all applicable lectures are already ABSENT, does not create duplicate records.
     * - Saves a BulkAbsenceOperationEntity snapshot so the user can undo the entire operation in one tap.
     */
    suspend fun executeCompleteDayAbsent(
        targetDate: LocalDate,
        currentLocalDate: LocalDate = LocalDate.now()
    ): String? {
        val preview = previewCompleteDayAbsent(targetDate, currentLocalDate)
        if (!preview.canProceed) return null

        // Prevent duplicate bulk records if every applicable lecture is already ABSENT
        val lecturesNeedingChange = preview.applicableLectures.filter {
            it.attendanceStatus != AttendanceStatus.ABSENT
        }
        if (lecturesNeedingChange.isEmpty()) {
            return null
        }

        val operationId = "bulk_${targetDate}_${UUID.randomUUID().toString().take(8)}"
        val now = System.currentTimeMillis()
        val previousEntries = mutableListOf<PreviousLectureStatusEntry>()

        database.withTransaction {
            for (lecture in lecturesNeedingChange) {
                previousEntries.add(
                    PreviousLectureStatusEntry(
                        lectureInstanceId = lecture.id,
                        subjectName = lecture.subjectName,
                        startTime = lecture.startTime,
                        previousStatus = lecture.attendanceStatus,
                        newStatus = AttendanceStatus.ABSENT
                    )
                )
                val updated = LectureInstanceEntity.fromDomain(
                    lecture.copy(
                        attendanceStatus = AttendanceStatus.ABSENT,
                        lastUpdatedEpochMillis = now
                    )
                )
                instanceDao.upsertInstance(updated)
                auditDao.insertAuditLog(
                    AttendanceAuditLogEntity(
                        lectureInstanceId = lecture.id,
                        subjectId = lecture.subjectId,
                        subjectName = lecture.subjectName,
                        lectureDate = lecture.date,
                        startTime = lecture.startTime,
                        previousStatus = lecture.attendanceStatus,
                        newStatus = AttendanceStatus.ABSENT,
                        source = "BULK_COMPLETE_ABSENT",
                        timestampEpochMillis = now
                    )
                )
            }

            auditDao.upsertBulkOperation(
                BulkAbsenceOperationEntity(
                    operationId = operationId,
                    targetDate = targetDate.toString(),
                    timestampEpochMillis = now,
                    affectedLecturesJson = json.encodeToString(previousEntries),
                    wasUndone = false
                )
            )
        }

        WidgetRefreshManager.refreshAllWidgets(appContext)
        rescheduleUpcomingReminders()
        return operationId
    }

    /**
     * Undoes a previously executed bulk absence operation transactionally, restoring each affected
     * lecture's exact prior attendance status.
     */
    suspend fun undoBulkAbsenceOperation(operationId: String): Boolean {
        var undone = false
        database.withTransaction {
            val op = auditDao.getBulkOperationById(operationId) ?: return@withTransaction
            if (op.wasUndone) return@withTransaction

            val entries = runCatching {
                json.decodeFromString<List<PreviousLectureStatusEntry>>(op.affectedLecturesJson)
            }.getOrDefault(emptyList())

            val now = System.currentTimeMillis()
            for (entry in entries) {
                val inst = instanceDao.getInstanceById(entry.lectureInstanceId) ?: continue
                instanceDao.upsertInstance(
                    inst.copy(
                        attendanceStatus = entry.previousStatus,
                        lastUpdatedEpochMillis = now
                    )
                )
                auditDao.insertAuditLog(
                    AttendanceAuditLogEntity(
                        lectureInstanceId = inst.id,
                        subjectId = inst.subjectId,
                        subjectName = inst.subjectName,
                        lectureDate = inst.date,
                        startTime = inst.startTime,
                        previousStatus = inst.attendanceStatus,
                        newStatus = entry.previousStatus,
                        source = "UNDO_BULK",
                        timestampEpochMillis = now
                    )
                )
            }

            auditDao.upsertBulkOperation(op.copy(wasUndone = true))
            undone = true
        }

        if (undone) {
            WidgetRefreshManager.refreshAllWidgets(appContext)
            rescheduleUpcomingReminders()
        }
        return undone
    }

    /**
     * Upserts a Subject and updates pending/future lecture instances while preserving finalized history.
     */
    suspend fun saveSubject(subject: Subject) {
        database.withTransaction {
            subjectDao.upsertSubject(SubjectEntity.fromDomain(subject))
            regenerateSchedulePreservingHistory()
        }
        WidgetRefreshManager.refreshAllWidgets(appContext)
        rescheduleUpcomingReminders()
    }

    suspend fun deleteSubject(subjectId: String) {
        database.withTransaction {
            subjectDao.deleteSubjectById(subjectId)
            val slots = slotDao.getAllSlots().filter { it.subjectId == subjectId }
            slots.forEach { slotDao.deleteSlotById(it.id) }
        }
        WidgetRefreshManager.refreshAllWidgets(appContext)
        rescheduleUpcomingReminders()
    }

    suspend fun saveTimetableSlot(slot: TimetableSlot, regenerateFrom: LocalDate = LocalDate.now()) {
        database.withTransaction {
            slotDao.upsertSlot(TimetableSlotEntity.fromDomain(slot))
            regenerateSchedulePreservingHistory(regenerateFromDate = regenerateFrom)
        }
        WidgetRefreshManager.refreshAllWidgets(appContext)
        rescheduleUpcomingReminders()
    }

    suspend fun deleteTimetableSlot(slotId: String, regenerateFrom: LocalDate = LocalDate.now()) {
        database.withTransaction {
            slotDao.deleteSlotById(slotId)
            instanceDao.deletePendingGeneratedInstancesFrom(regenerateFrom.toString())
            regenerateSchedulePreservingHistory(regenerateFromDate = regenerateFrom)
        }
        WidgetRefreshManager.refreshAllWidgets(appContext)
        rescheduleUpcomingReminders()
    }

    suspend fun saveOneTimeOrRescheduledLecture(instance: LectureInstance) {
        instanceDao.upsertInstance(LectureInstanceEntity.fromDomain(instance))
        WidgetRefreshManager.refreshAllWidgets(appContext)
        rescheduleUpcomingReminders()
    }

    suspend fun saveCalendarEvent(event: AcademicCalendarEvent) {
        database.withTransaction {
            eventDao.upsertEvent(AcademicCalendarEventEntity.fromDomain(event))
            regenerateSchedulePreservingHistory()
        }
        WidgetRefreshManager.refreshAllWidgets(appContext)
        rescheduleUpcomingReminders()
    }

    suspend fun deleteCalendarEvent(eventId: String) {
        database.withTransaction {
            eventDao.deleteEventById(eventId)
            regenerateSchedulePreservingHistory()
        }
        WidgetRefreshManager.refreshAllWidgets(appContext)
        rescheduleUpcomingReminders()
    }

    /**
     * Regenerates semester LectureInstances from recurring TimetableSlots & AcademicCalendarEvents
     * while strictly preserving all finalized attendance records (ATTENDED, ABSENT, CANCELLED) and custom one-time lectures.
     */
    suspend fun regenerateSchedulePreservingHistory(regenerateFromDate: LocalDate? = null) {
        val prefs = preferencesDataStore.getPreferencesSnapshot()
        val calendarConfig = AcademicCalendarConfig(
            semesterName = prefs.semesterName,
            semesterStartDate = prefs.semesterStartDate,
            semesterEndDate = prefs.semesterEndDate,
            workingDaysOfWeek = prefs.workingDaysOfWeek
        )
        val subjects = subjectDao.getAllSubjects().map { it.toDomain() }
        val slots = slotDao.getAllSlots().map { it.toDomain() }
        val events = eventDao.getAllEvents().map { it.toDomain() }
        val existingInstances = instanceDao.getAllInstances().map { it.toDomain() }

        if (regenerateFromDate != null) {
            instanceDao.deletePendingGeneratedInstancesFrom(regenerateFromDate.toString())
        }

        val generated = TimetableGenerator.generateSemesterInstances(
            calendarConfig = calendarConfig,
            subjects = subjects,
            timetableSlots = slots,
            calendarEvents = events,
            existingInstances = existingInstances,
            regenerateFromDate = regenerateFromDate
        )
        instanceDao.upsertInstances(generated.map { LectureInstanceEntity.fromDomain(it) })
    }

    /**
     * Applies a validated AcademicScheduleBundle (Timetable Only, Calendar Only, Combined, or Full Backup).
     * Never silently overwrites existing finalized attendance records unless explicit full restore is confirmed.
     */
    suspend fun applyValidatedImport(
        bundle: AcademicScheduleBundle,
        mode: ImportMode,
        overwriteExistingFinalizedAttendance: Boolean = false
    ) {
        database.withTransaction {
            if (mode == ImportMode.FULL_BACKUP_RESTORE && overwriteExistingFinalizedAttendance) {
                subjectDao.deleteAllSubjects()
                slotDao.deleteAllSlots()
                instanceDao.deleteAllInstances()
                eventDao.deleteAllEvents()
            }

            bundle.calendarConfig?.let { cfg ->
                preferencesDataStore.updateSemesterConfig(
                    semesterName = cfg.semesterName,
                    startDate = cfg.semesterStartDate,
                    endDate = cfg.semesterEndDate,
                    workingDays = cfg.workingDaysOfWeek
                )
            }

            if (bundle.subjects.isNotEmpty()) {
                subjectDao.upsertSubjects(bundle.subjects.map { SubjectEntity.fromDomain(it) })
            }
            if (bundle.timetableSlots.isNotEmpty()) {
                slotDao.upsertSlots(bundle.timetableSlots.map { TimetableSlotEntity.fromDomain(it) })
            }
            if (bundle.calendarEvents.isNotEmpty()) {
                eventDao.upsertEvents(bundle.calendarEvents.map { AcademicCalendarEventEntity.fromDomain(it) })
            }

            if (bundle.lectureInstances.isNotEmpty()) {
                val existingById = instanceDao.getAllInstances().associateBy { it.id }
                val toUpsert = bundle.lectureInstances.mapNotNull { imported ->
                    val current = existingById[imported.id]
                    if (current != null &&
                        current.attendanceStatus != AttendanceStatus.PENDING &&
                        !overwriteExistingFinalizedAttendance
                    ) {
                        // Preserve existing finalized attendance record
                        null
                    } else {
                        LectureInstanceEntity.fromDomain(imported)
                    }
                }
                instanceDao.upsertInstances(toUpsert)
            }

            regenerateSchedulePreservingHistory()
        }

        WidgetRefreshManager.refreshAllWidgets(appContext)
        rescheduleUpcomingReminders()
    }

    /**
     * Exports the complete database state as a JSON string for backup or sharing.
     */
    suspend fun exportFullBackupJson(): String {
        val prefs = preferencesDataStore.getPreferencesSnapshot()
        val bundle = AcademicScheduleBundle(
            schemaVersion = 1,
            exportTimestampEpochMillis = System.currentTimeMillis(),
            calendarConfig = AcademicCalendarConfig(
                semesterName = prefs.semesterName,
                semesterStartDate = prefs.semesterStartDate,
                semesterEndDate = prefs.semesterEndDate,
                workingDaysOfWeek = prefs.workingDaysOfWeek
            ),
            subjects = subjectDao.getAllSubjects().map { it.toDomain() },
            timetableSlots = slotDao.getAllSlots().map { it.toDomain() },
            calendarEvents = eventDao.getAllEvents().map { it.toDomain() },
            lectureInstances = instanceDao.getAllInstances().map { it.toDomain() },
            bulkOperationsHistory = auditDao.getAllBulkOperations().map { op ->
                BulkAbsenceOperationRecord(
                    operationId = op.operationId,
                    targetDate = op.targetDate,
                    timestampEpochMillis = op.timestampEpochMillis,
                    affectedLectures = runCatching {
                        json.decodeFromString<List<PreviousLectureStatusEntry>>(op.affectedLecturesJson)
                    }.getOrDefault(emptyList()),
                    wasUndone = op.wasUndone
                )
            }
        )
        return ScheduleImportExportEngine.exportToJson(bundle)
    }

    suspend fun rescheduleUpcomingReminders() {
        val prefs = preferencesDataStore.getPreferencesSnapshot()
        val subjects = subjectDao.getAllSubjects().map { it.toDomain() }
        val today = LocalDate.now().toString()
        val instances = instanceDao.getAllInstances()
            .map { it.toDomain() }
            .filter { it.date >= today && it.attendanceStatus != AttendanceStatus.CANCELLED }

        LectureReminderScheduler.scheduleUpcomingLectures(
            context = appContext,
            preferences = prefs,
            subjectsById = subjects.associateBy { it.id },
            upcomingInstances = instances
        )
    }
}
