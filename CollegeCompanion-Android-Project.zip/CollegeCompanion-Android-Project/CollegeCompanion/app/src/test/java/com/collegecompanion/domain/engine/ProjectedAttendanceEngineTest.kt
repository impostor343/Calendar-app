package com.collegecompanion.domain.engine

import com.collegecompanion.domain.model.AttendanceStatus
import com.collegecompanion.domain.model.LectureInstance
import com.collegecompanion.domain.model.ProjectionScenarioType
import com.collegecompanion.domain.model.Subject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class ProjectedAttendanceEngineTest {

    private val subject = Subject(
        id = "sub_ds",
        code = "CS201",
        name = "Data Structures",
        customRequiredPercentage = 70.0
    )

    @Test
    fun `all 7 projection scenarios compute accurate projected percentages without mutating actual attendance`() {
        val semStart = LocalDate.of(2026, 7, 1)
        val semEnd = LocalDate.of(2026, 12, 15)
        val today = LocalDate.of(2026, 11, 1)

        // Current: 7 attended, 3 absent (T = 10, A = 7 -> 70.0%)
        val instances = mutableListOf<LectureInstance>()
        for (i in 1..7) {
            instances.add(makeInstance("past_att_$i", "2026-09-${10 + i}", AttendanceStatus.ATTENDED))
        }
        for (i in 1..3) {
            instances.add(makeInstance("past_abs_$i", "2026-09-${20 + i}", AttendanceStatus.ABSENT))
        }
        // Future: 10 upcoming lectures in November
        for (i in 1..10) {
            instances.add(makeInstance("fut_$i", "2026-11-${10 + i}", AttendanceStatus.PENDING))
        }

        // Scenario 1: Attend all 10 future -> (7 + 10) / (10 + 10) = 17/20 = 85.0%
        val s1 = ProjectedAttendanceEngine.simulateSubjectProjection(
            subject = subject,
            allInstances = instances,
            currentDate = today,
            semesterStartDate = semStart,
            semesterEndDate = semEnd,
            scenario = ProjectionScenarioType.ATTEND_ALL
        )
        assertEquals(70.0, s1.currentPercentage, 0.001)
        assertEquals(85.0, s1.projectedPercentage, 0.001)
        assertFalse(s1.dropsBelowThreshold)

        // Scenario 2: Miss next 1, attend remaining 9 -> (7 + 9) / 20 = 16/20 = 80.0%
        val s2 = ProjectedAttendanceEngine.simulateSubjectProjection(
            subject = subject,
            allInstances = instances,
            currentDate = today,
            semesterStartDate = semStart,
            semesterEndDate = semEnd,
            scenario = ProjectionScenarioType.MISS_NEXT_1
        )
        assertEquals(80.0, s2.projectedPercentage, 0.001)

        // Scenario 3: Miss next 2, attend remaining 8 -> (7 + 8) / 20 = 75.0%
        val s3 = ProjectedAttendanceEngine.simulateSubjectProjection(
            subject = subject,
            allInstances = instances,
            currentDate = today,
            semesterStartDate = semStart,
            semesterEndDate = semEnd,
            scenario = ProjectionScenarioType.MISS_NEXT_2
        )
        assertEquals(75.0, s3.projectedPercentage, 0.001)

        // Scenario 4: Miss next 3, attend remaining 7 -> (7 + 7) / 20 = 70.0%
        val s4 = ProjectedAttendanceEngine.simulateSubjectProjection(
            subject = subject,
            allInstances = instances,
            currentDate = today,
            semesterStartDate = semStart,
            semesterEndDate = semEnd,
            scenario = ProjectionScenarioType.MISS_NEXT_3
        )
        assertEquals(70.0, s4.projectedPercentage, 0.001)
        assertFalse(s4.dropsBelowThreshold)

        // Scenario 5: Miss custom 5 upcoming -> (7 + 5) / 20 = 60.0% -> drops below 70% threshold!
        val s5 = ProjectedAttendanceEngine.simulateSubjectProjection(
            subject = subject,
            allInstances = instances,
            currentDate = today,
            semesterStartDate = semStart,
            semesterEndDate = semEnd,
            scenario = ProjectionScenarioType.MISS_CUSTOM_COUNT,
            customCount = 5
        )
        assertEquals(60.0, s5.projectedPercentage, 0.001)
        assertTrue(s5.dropsBelowThreshold)

        // Scenario 6: Select 4 specific future lecture IDs to miss -> (7 + 6) / 20 = 65.0%
        val s6 = ProjectedAttendanceEngine.simulateSubjectProjection(
            subject = subject,
            allInstances = instances,
            currentDate = today,
            semesterStartDate = semStart,
            semesterEndDate = semEnd,
            scenario = ProjectionScenarioType.SELECT_SPECIFIC_FUTURE,
            specificMissedLectureIds = setOf("fut_1", "fut_2", "fut_3", "fut_4")
        )
        assertEquals(65.0, s6.projectedPercentage, 0.001)
        assertTrue(s6.dropsBelowThreshold)

        // Scenario 7: Attend 8 future lectures and miss remaining 2 -> (7 + 8) / 20 = 75.0%
        val s7 = ProjectedAttendanceEngine.simulateSubjectProjection(
            subject = subject,
            allInstances = instances,
            currentDate = today,
            semesterStartDate = semStart,
            semesterEndDate = semEnd,
            scenario = ProjectionScenarioType.ATTEND_SELECTED_COUNT,
            customCount = 8
        )
        assertEquals(75.0, s7.projectedPercentage, 0.001)
        // Verify actual current percentage remained 70.0% throughout all simulations
        assertEquals(70.0, s7.currentPercentage, 0.001)
    }

    private fun makeInstance(id: String, date: String, status: AttendanceStatus) = LectureInstance(
        id = id,
        subjectId = "sub_ds",
        subjectName = "Data Structures",
        subjectCode = "CS201",
        subjectColorHex = "#1A73E8",
        date = date,
        startTime = "09:00",
        endTime = "10:00",
        attendanceStatus = status
    )
}
