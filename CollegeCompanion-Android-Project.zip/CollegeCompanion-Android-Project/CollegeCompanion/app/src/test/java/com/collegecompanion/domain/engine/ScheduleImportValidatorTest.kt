package com.collegecompanion.domain.engine

import com.collegecompanion.data.SampleInitialDataSeeder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ScheduleImportValidatorTest {

    @Test
    fun `default sample academic bundle exports and validates cleanly across all modes`() {
        val sampleBundle = SampleInitialDataSeeder.buildDefaultAcademicBundle()
        val jsonText = ScheduleImportExportEngine.exportToJson(sampleBundle)

        val report = ScheduleImportExportEngine.validateJsonImport(
            rawJson = jsonText,
            mode = ImportMode.COMBINED_SCHEDULE
        )
        assertTrue(report.isValid)
        assertTrue(report.errors.isEmpty())
        assertEquals(4, report.bundle?.subjects?.size)
    }

    @Test
    fun `csv timetable parser creates subjects and slots and validates cleanly`() {
        val csv = """
            subjectCode,subjectName,professor,dayOfWeek,startTime,endTime,roomNumber,labNumber,building,floor,lectureType,colorHex
            CS201,Data Structures,Dr. A. Sharma,Monday,09:00,10:00,301,,Main CS Block,3rd,LECTURE,#1A73E8
            CS204,DBMS,Prof. R. Patel,Monday,11:45,12:45,204,DB-Lab-1,IT Annex,2nd,LECTURE,#00897B
        """.trimIndent()

        val report = ScheduleImportExportEngine.parseAndValidateCsvTimetable(csv)
        assertTrue(report.isValid)
        assertEquals(2, report.bundle?.subjects?.size)
        assertEquals(2, report.bundle?.timetableSlots?.size)
    }

    @Test
    fun `invalid end time before start time is rejected by import validator`() {
        val badJson = """
            {
              "schemaVersion": 1,
              "subjects": [{"id": "s1", "code": "CS101", "name": "Intro CS"}],
              "timetableSlots": [
                {"id": "slot1", "subjectId": "s1", "dayOfWeek": 1, "startTime": "11:00", "endTime": "10:00"}
              ]
            }
        """.trimIndent()

        val report = ScheduleImportExportEngine.validateJsonImport(badJson, ImportMode.TIMETABLE_ONLY)
        assertFalse(report.isValid)
        assertTrue(report.errors.any { it.contains("endTime") })
    }
}
