package com.collegecompanion.domain.engine

import com.collegecompanion.domain.model.AcademicCalendarConfig
import com.collegecompanion.domain.model.AcademicCalendarEvent
import com.collegecompanion.domain.model.AttendanceStatus
import com.collegecompanion.domain.model.CalendarEventType
import com.collegecompanion.domain.model.LectureType
import com.collegecompanion.domain.model.RotationPattern
import com.collegecompanion.domain.model.Subject
import com.collegecompanion.domain.model.TimetableSlot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class TimetableGeneratorAndConflictTest {

    private val ds = Subject(id = "sub_ds", code = "CS201", name = "Data Structures")
    private val dbms = Subject(id = "sub_dbms", code = "CS204", name = "DBMS")

    @Test
    fun `timetable mapping excludes holidays, maps special working Saturdays, and preserves finalized attendance`() {
        // Two-week window: Monday Nov 2, 2026 to Saturday Nov 14, 2026
        val config = AcademicCalendarConfig(
            semesterName = "Test Sem",
            semesterStartDate = "2026-11-02",
            semesterEndDate = "2026-11-14",
            workingDaysOfWeek = setOf(1, 2, 3, 4, 5)
        )

        val mondaySlot = TimetableSlot(
            id = "slot_mon_ds",
            subjectId = "sub_ds",
            dayOfWeek = 1,
            startTime = "09:00",
            endTime = "10:00"
        )

        val events = listOf(
            // Make Monday Nov 9 a holiday
            AcademicCalendarEvent(
                id = "ev_hol",
                title = "Festival Holiday",
                startDate = "2026-11-09",
                endDate = "2026-11-09",
                eventType = CalendarEventType.HOLIDAY
            ),
            // Make Saturday Nov 14 a Special Working Saturday following Monday (1)
            AcademicCalendarEvent(
                id = "ev_sat_mon",
                title = "Working Saturday",
                startDate = "2026-11-14",
                endDate = "2026-11-14",
                eventType = CalendarEventType.SPECIAL_WORKING_SATURDAY,
                followsDayOfWeek = 1
            )
        )

        val firstGeneration = TimetableGenerator.generateSemesterInstances(
            calendarConfig = config,
            subjects = listOf(ds),
            timetableSlots = listOf(mondaySlot),
            calendarEvents = events
        )

        // Expected dates:
        // - 2026-11-02 (Monday)
        // - 2026-11-09 is excluded (Holiday)
        // - 2026-11-14 (Saturday following Monday schedule)
        assertEquals(listOf("2026-11-02", "2026-11-14"), firstGeneration.map { it.date })

        // Mark 2026-11-02 as ATTENDED, then edit the future timetable slot time and regenerate from 2026-11-10
        val attendedFirst = firstGeneration.first().copy(attendanceStatus = AttendanceStatus.ATTENDED)
        val editedSlot = mondaySlot.copy(startTime = "10:00", endTime = "11:00")

        val regenerated = TimetableGenerator.generateSemesterInstances(
            calendarConfig = config,
            subjects = listOf(ds),
            timetableSlots = listOf(editedSlot),
            calendarEvents = events,
            existingInstances = listOf(attendedFirst),
            regenerateFromDate = LocalDate.of(2026, 11, 10)
        )

        val nov2Instance = regenerated.first { it.date == "2026-11-02" }
        val nov14Instance = regenerated.first { it.date == "2026-11-14" }

        // Historical attendance and original start time on Nov 2 are strictly preserved
        assertEquals(AttendanceStatus.ATTENDED, nov2Instance.attendanceStatus)
        assertEquals("09:00", nov2Instance.startTime)
        // Future instance on Nov 14 gets the updated time
        assertEquals("10:00", nov14Instance.startTime)
    }

    @Test
    fun `overlap detector identifies conflicting slots on same weekday and allows odd-even rotation coexistence`() {
        val subjects = mapOf(ds.id to ds, dbms.id to dbms)

        val overlappingSlots = listOf(
            TimetableSlot("s1", "sub_ds", 1, "09:00", "10:30", rotationPattern = RotationPattern.EVERY_WEEK),
            TimetableSlot("s2", "sub_dbms", 1, "10:00", "11:00", rotationPattern = RotationPattern.EVERY_WEEK)
        )
        val warnings = TimetableGenerator.detectSlotOverlaps(overlappingSlots, subjects)
        assertEquals(1, warnings.size)
        assertEquals(30L, warnings.first().overlapMinutes)

        // Odd week vs Even week at the same time do NOT overlap on any actual calendar date
        val alternatingSlots = listOf(
            TimetableSlot("s3", "sub_ds", 2, "09:00", "10:00", rotationPattern = RotationPattern.ODD_WEEKS),
            TimetableSlot("s4", "sub_dbms", 2, "09:00", "10:00", rotationPattern = RotationPattern.EVEN_WEEKS)
        )
        val altWarnings = TimetableGenerator.detectSlotOverlaps(alternatingSlots, subjects)
        assertTrue(altWarnings.isEmpty())
    }
}
