package com.collegecompanion.notification

import org.junit.Assert.assertNotEquals
import org.junit.Test

class NotificationSchedulerTest {

    @Test
    fun `multiple reminder intervals for the same lecture generate distinct AlarmManager request codes`() {
        val instanceId = "2026-11-02_slot_mon_0900_ds"
        val intervals = listOf(30, 15, 5)
        val codes = intervals.map { LectureReminderScheduler.computeRequestCode(instanceId, it) }.toSet()
        assertNotEquals(1, codes.size)
        org.junit.Assert.assertEquals(3, codes.size)
    }
}
