package com.collegecompanion.domain.engine

import com.collegecompanion.domain.model.AttendanceStatus
import com.collegecompanion.domain.model.AttendanceWarningLevel
import com.collegecompanion.domain.model.LectureInstance
import com.collegecompanion.domain.model.Subject
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class AttendanceEngineTest {

    private val dsSubject = Subject(
        id = "sub_ds",
        code = "CS201",
        name = "Data Structures",
        professor = "Dr. Sharma",
        customRequiredPercentage = 70.0
    )

    private val dbmsSubject = Subject(
        id = "sub_dbms",
        code = "CS204",
        name = "DBMS",
        professor = "Prof. Patel",
        customRequiredPercentage = 70.0
    )

    @Test
    fun `prompt specification example - 30 attended, 8 absent, 2 pending, 35 future yields 78_95 percent`() {
        val semStart = LocalDate.of(2026, 7, 1)
        val semEnd = LocalDate.of(2026, 12, 15)
        val today = LocalDate.of(2026, 11, 1)

        val instances = mutableListOf<LectureInstance>()

        // 30 attended in the past
        for (i in 1..30) {
            instances.add(
                createInstance("att_$i", "sub_ds", semStart.plusDays(i.toLong()).toString(), AttendanceStatus.ATTENDED)
            )
        }
        // 8 absent in the past
        for (i in 1..8) {
            instances.add(
                createInstance("abs_$i", "sub_ds", semStart.plusDays((40 + i).toLong()).toString(), AttendanceStatus.ABSENT)
            )
        }
        // 2 pending in the past
        for (i in 1..2) {
            instances.add(
                createInstance("pend_$i", "sub_ds", semStart.plusDays((60 + i).toLong()).toString(), AttendanceStatus.PENDING)
            )
        }
        // 35 future scheduled lectures (after Nov 1)
        for (i in 1..35) {
            instances.add(
                createInstance("fut_$i", "sub_ds", today.plusDays(i.toLong()).toString(), AttendanceStatus.PENDING)
            )
        }

        val summary = AttendanceEngine.calculateSubjectAttendance(
            subject = dsSubject,
            instances = instances,
            semesterStartDate = semStart,
            semesterEndDate = semEnd,
            currentDate = today
        )

        assertEquals(30, summary.attendedCount)
        assertEquals(8, summary.absentCount)
        assertEquals(2, summary.pendingPastCount)
        assertEquals(35, summary.futureScheduledCount)
        assertEquals(38, summary.totalFinalizedCount)
        assertEquals(78.95, summary.currentPercentage, 0.001)
        assertEquals(AttendanceWarningLevel.COMFORTABLE, summary.warningLevel)
        // floor(30 / 0.70 - 38) = floor(42.8571 - 38) = 4
        assertEquals(4, summary.safeAbsences)
        assertEquals(0, summary.recoveryLecturesNeeded)
    }

    @Test
    fun `overall attendance uses total finalized across subjects and never simple average`() {
        val semStart = LocalDate.of(2026, 7, 1)
        val semEnd = LocalDate.of(2026, 12, 15)
        val today = LocalDate.of(2026, 11, 1)

        val instances = mutableListOf<LectureInstance>()
        // Subject 1: 10 attended, 0 absent (100%)
        for (i in 1..10) {
            instances.add(createInstance("s1_$i", "sub_ds", "2026-09-01", AttendanceStatus.ATTENDED))
        }
        // Subject 2: 10 attended, 10 absent (50%)
        for (i in 1..10) {
            instances.add(createInstance("s2_att_$i", "sub_dbms", "2026-09-02", AttendanceStatus.ATTENDED))
            instances.add(createInstance("s2_abs_$i", "sub_dbms", "2026-09-03", AttendanceStatus.ABSENT))
        }

        val overall = AttendanceEngine.calculateOverallAttendance(
            subjects = listOf(dsSubject, dbmsSubject),
            instances = instances,
            semesterStartDate = semStart,
            semesterEndDate = semEnd,
            currentDate = today
        )

        // Total attended = 20, Total finalized = 30 -> 20/30 = 66.67% (NOT (100+50)/2 = 75%)
        assertEquals(20, overall.totalAttended)
        assertEquals(10, overall.totalAbsent)
        assertEquals(30, overall.totalFinalized)
        assertEquals(66.67, overall.currentPercentage, 0.001)
        assertEquals(AttendanceWarningLevel.CRITICAL, overall.warningLevel)
        assertEquals(1, overall.subjectsBelowThresholdCount)
    }

    @Test
    fun `safe absences and recovery calculations handle exact 70 percent boundary without red warning`() {
        // 7 attended, 3 absent -> exactly 70.0%
        val safeAt70 = AttendanceEngine.calculateSafeAbsences(7, 3, 70.0)
        val recoveryAt70 = AttendanceEngine.calculateRecoveryLectures(7, 3, 70.0)
        val levelAt70 = AttendanceEngine.resolveWarningLevel(7, 3, 70.0, 75.0)

        assertEquals(0, safeAt70)
        assertEquals(0, recoveryAt70)
        // Attendance exactly at 70% must NOT be CRITICAL (Red); it must be WARNING (Amber)
        assertEquals(AttendanceWarningLevel.WARNING, levelAt70)

        // 6 attended, 4 absent -> 60.0% (< 70.0%) -> Red (CRITICAL)
        // Need (6 + x) / (10 + x) >= 0.70 => 6 + x >= 7 + 0.7x => 0.3x >= 1 => x = 4 (10/14 = 71.43%)
        val safeAt60 = AttendanceEngine.calculateSafeAbsences(6, 4, 70.0)
        val recoveryAt60 = AttendanceEngine.calculateRecoveryLectures(6, 4, 70.0)
        val levelAt60 = AttendanceEngine.resolveWarningLevel(6, 4, 70.0, 75.0)

        assertEquals(0, safeAt60)
        assertEquals(4, recoveryAt60)
        assertEquals(AttendanceWarningLevel.CRITICAL, levelAt60)
    }

    @Test
    fun `holidays and cancelled lectures are excluded from denominator`() {
        val semStart = LocalDate.of(2026, 7, 1)
        val semEnd = LocalDate.of(2026, 12, 15)
        val today = LocalDate.of(2026, 11, 1)
        val holiday = LocalDate.of(2026, 8, 15)

        val instances = listOf(
            createInstance("1", "sub_ds", "2026-08-10", AttendanceStatus.ATTENDED),
            createInstance("2", "sub_ds", "2026-08-11", AttendanceStatus.CANCELLED),
            createInstance("3", "sub_ds", "2026-08-15", AttendanceStatus.ABSENT) // Falls on holiday, must be ignored
        )

        val summary = AttendanceEngine.calculateSubjectAttendance(
            subject = dsSubject,
            instances = instances,
            semesterStartDate = semStart,
            semesterEndDate = semEnd,
            currentDate = today,
            holidayDates = setOf(holiday)
        )

        assertEquals(1, summary.attendedCount)
        assertEquals(0, summary.absentCount)
        assertEquals(1, summary.cancelledCount)
        assertEquals(100.0, summary.currentPercentage, 0.001)
    }

    private fun createInstance(
        id: String,
        subjectId: String,
        date: String,
        status: AttendanceStatus
    ) = LectureInstance(
        id = id,
        subjectId = subjectId,
        subjectName = "Data Structures",
        subjectCode = "CS201",
        subjectColorHex = "#1A73E8",
        date = date,
        startTime = "09:00",
        endTime = "10:00",
        attendanceStatus = status
    )
}
