package com.collegecompanion

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.collegecompanion.data.SampleInitialDataSeeder
import com.collegecompanion.data.local.CollegeCompanionDatabase
import com.collegecompanion.data.preferences.PreferencesDataStore
import com.collegecompanion.data.repository.CollegeRepository
import com.collegecompanion.domain.engine.ImportMode
import com.collegecompanion.domain.model.AttendanceStatus
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.time.LocalDate

@RunWith(AndroidJUnit4::class)
class DatabaseAndBulkAbsenceIntegrationTest {

    private lateinit var context: Context
    private lateinit var db: CollegeCompanionDatabase
    private lateinit var repository: CollegeRepository

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, CollegeCompanionDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val prefs = PreferencesDataStore(context)
        repository = CollegeRepository(context, db, prefs)
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun completeDayAbsentMarksApplicableLecturesAndSupportsTransactionalUndo() = runBlocking {
        val bundle = SampleInitialDataSeeder.buildDefaultAcademicBundle()
        repository.applyValidatedImport(bundle, ImportMode.COMBINED_SCHEDULE)

        val targetDate = LocalDate.of(2026, 11, 2) // Monday with 4 lectures
        val currentLocalDate = LocalDate.of(2026, 11, 2)

        val initialLectures = db.lectureInstanceDao().getInstancesForDate(targetDate.toString())
        assertEquals(4, initialLectures.size)

        // Mark the first lecture ATTENDED first to verify overwrite warning detection
        repository.markLectureAttendance(initialLectures[0].id, AttendanceStatus.ATTENDED, "WIDGET")

        val preview = repository.previewCompleteDayAbsent(targetDate, currentLocalDate)
        assertTrue(preview.canProceed)
        assertEquals(1, preview.previouslyAttendedLectures.size)

        // Execute complete-day absence
        val opId = repository.executeCompleteDayAbsent(targetDate, currentLocalDate)
        assertNotNull(opId)

        val afterBulk = db.lectureInstanceDao().getInstancesForDate(targetDate.toString())
        assertTrue(afterBulk.all { it.attendanceStatus == AttendanceStatus.ABSENT })

        // Repeated press when all are already ABSENT returns null (no duplicate bulk records)
        val duplicateOpId = repository.executeCompleteDayAbsent(targetDate, currentLocalDate)
        assertNull(duplicateOpId)

        // Undo the bulk absence operation and verify the first lecture is restored to ATTENDED and others to PENDING
        val undone = repository.undoBulkAbsenceOperation(opId!!)
        assertTrue(undone)

        val afterUndo = db.lectureInstanceDao().getInstancesForDate(targetDate.toString()).associateBy { it.id }
        assertEquals(AttendanceStatus.ATTENDED, afterUndo[initialLectures[0].id]?.attendanceStatus)
        assertEquals(AttendanceStatus.PENDING, afterUndo[initialLectures[1].id]?.attendanceStatus)
    }
}
