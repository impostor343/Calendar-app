-keepattributes *Annotation*,InnerClasses,Signature
-keepclassmembers class * {
    @kotlinx.serialization.Serializable *;
}
-keep class com.collegecompanion.data.local.entity.** { *; }
-keep class com.collegecompanion.domain.model.** { *; }
-keep class com.collegecompanion.widget.** { *; }
